/**
 * `window.__hew_test` — the semantic test harness (docs/dev/DEVELOPMENT.md).
 *
 * Debug/test builds only. It lets a driver (Playwright in, or the console)
 * issue **semantic** actions and read state *by logic, not canvas pixels* — the
 * answer to "the viewport is an opaque WebGL canvas" (docs/dev/DEVELOPMENT.md). Most E2E
 * tests should drive through this rather than synthesize pointer events.
 *
 * Design:
 * - Modeling actions call the same kernel ops the tools commit (`begin_ground_
 *   sketch`/`sketch_add_segment`/`extrude_region`/`push_pull`/`boolean`/…), then
 *   reconcile the app exactly as a tool commit would, so state stays faithful.
 * - **Handles cross the boundary as decimal strings, never bigint.** u64 kernel
 *   handles and the `state_hash` exceed `Number.MAX_SAFE_INTEGER` and bigint is
 *   not structured-cloneable out of `page.evaluate`; strings are exact and
 *   portable. Args accept a string and are `BigInt()`-converted internally.
 * - Picking is pixel-free: `pickFace` casts a **world-space ray** (e.g. straight
 *   down onto a top face), so `pushPull(obj, face, …)` gets a real face handle
 *   without any screen projection.
 * - `startRecording`/`takeRecording` tie the high-level (`Scene`) and
 *   low-level (`inputRecorder`) streams into one session artifact.
 *
 * Not exposed (deliberately): `selectFace`/`selectEdge`/`hoverPoint` from the
 * sketch list — the app has no *persistent* sub-element selection (faces/edges
 * are picked transiently inside tools), and `pushPull` takes an explicit face
 * from `pickFace` instead. Object-level selection is real, via `selectObjects`.
 */

import type { Scene } from '../wasm/loader'
import type { PrintHost, PrintSetup } from '../print/printHost'
import type { PrintPageModel } from '../print/PrintDocument'
import type { PrintPlan } from '../print/printJob'
import type { ViewportApi } from '../viewport/Viewport'
import type { IsolationTarget } from '../viewport/isolation'
import { nodeKindToNumber, type NodeKind, type NodeRef } from '../panels/treeModel'
import { curveRunsView, imprintView } from './drawingView'
import {
  ctxGround,
  ctxOfFace,
  ctxOfPlane,
  ctxOfSketch,
  keyToId,
  outlinerDrawing,
  readPlaneUnits,
  type PlaneRegion,
  type PlaneUnitsScene,
} from '../tools/planeUnits'
import { addDraftLoop, addDraftSegment, runDraft } from '../tools/draftCommit'
import * as inputRecorder from '../recording/inputRecorder'
import { buildSessionRecording } from '../recording/sessionRecording'
import { arcFromChord, arcPolylineOnPlane } from '../tools/arcMath'
import { facePlaneBasis, type V3 } from '../viewport/geoHelpers'
import {
  formatLength,
  getLengthUnit,
  parseLengthToMeters,
  setLengthUnit,
  type LengthFormat,
} from '../settings/units'

type Vec3 = [number, number, number]

/** Point-in-ring for a planar ring (projected along its dominant normal axis). */
function ringContains(ring: readonly V3[], p: V3): boolean {
  let nx = 0, ny = 0, nz = 0
  for (let i = 0; i < ring.length; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length]
    nx += (a[1] - b[1]) * (a[2] + b[2])
    ny += (a[2] - b[2]) * (a[0] + b[0])
    nz += (a[0] - b[0]) * (a[1] + b[1])
  }
  const ax = Math.abs(nx) >= Math.abs(ny) && Math.abs(nx) >= Math.abs(nz) ? 0 : Math.abs(ny) >= Math.abs(nz) ? 1 : 2
  const [u, v] = ax === 0 ? [1, 2] : ax === 1 ? [0, 2] : [0, 1]
  let inside = false
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[i], b = ring[j]
    if (a[v] > p[v] !== b[v] > p[v] && p[u] < ((b[u] - a[u]) * (p[v] - a[v])) / (b[v] - a[v]) + a[u]) inside = !inside
  }
  return inside
}

export interface CameraPose {
  position: Vec3
  target: Vec3
  up?: Vec3
  fovDeg?: number
}

/** What the harness needs from the app; all live (read at call time). */
export interface HarnessDeps {
  getScene: () => Scene | null
  getViewportApi: () => ViewportApi | null
  /** View-only isolation through the app's handler (kernel hide state follows). */
  isolate: (targets: IsolationTarget[]) => number
  clearIsolation: () => void
  /** Reconcile + re-render after a mutation (the app's document-changed path). */
  reconcile: () => void
  /** Current object/group/instance selection. */
  getSelection: () => NodeRef[]
  /** Replace the selection with these object handles. */
  setSelectedObjects: (ids: bigint[]) => void
  /** Replace the selection with arbitrary nodes (objects/groups/instances). */
  setSelection: (nodes: NodeRef[]) => void
  /**
   * Reload `.hew` bytes through the app's real Open path (the same
   * `scene.load` + UI reset + viewport `notifyLoaded` re-tessellation a user's
   * File→Open runs). Returns false if the load was rejected..
   */
  loadBytes: (bytes: Uint8Array) => boolean
  /**
   * Toggle a tag path's hidden flag through the app's real Tags-panel path
   * (session hidden set + union push to renderer/kernel + persisted
   * `set_tag_hidden`) — NOT a bare scene call, which would skip the app's
   * visibility state.
   */
  toggleTagPath: (path: string[]) => void
  /** Delete a tag everywhere through the app's real Tags-panel path
   * (kernel `delete_tag` + tag-visibility resync + document-changed). */
  deleteTag: (path: string[]) => void
  /** Toggle one node's hidden flag through the app's real Outliner eye path
   * (`App.handleToggleHidden`). */
  toggleNodeHidden: (node: NodeRef) => void
  /** Whether `node`'s own key is in the app's hidden set. */
  isNodeHidden: (node: NodeRef) => boolean
  /** Re-apply tag visibility after a tag assignment
   * (`App.reconcileVisibility`) so a node given an already-hidden tag
   * hides, as it does through Object Info. Optional so headless callers
   * without tag state can omit it. */
  reconcileVisibility?: () => void
  /**
   * Print (docs/design/printing.md §12): install a recording print host +
   * page sink so a spec can drive File ▸ Print… end to end without the OS
   * dialog and inspect the composed pages. Optional so headless callers
   * without a print surface (Shop Mode boot) can omit it.
   */
  setPrintRecorder?: (recorder: PrintRecorder | null) => void
}

/** What App wires the harness's print recorder into (see App.tsx). */
export interface PrintRecorder {
  host: PrintHost
  onPages: (pages: PrintPageModel[], plan: PrintPlan) => void
  /** Records Save PDF… bytes instead of writing a file. */
  savePdf?: (bytes: Uint8Array, name: string) => Promise<boolean>
}

/** The `ImportReport` shape `scene.import_stl` returns across the boundary
 * (structured-clone-safe: numbers + string arrays). */
export interface StlImportReportJs {
  objects_created: number
  watertight: number
  leaky: number
  skipped: { name: string; reason: string }[]
  textures_missing: string[]
  warnings: string[]
}

export interface HewTestHarness {
  /** True once the kernel scene AND the viewport API are both wired — wait on
   * this before driving any harness op (camera/draw/pick need the viewport). */
  isReady(): boolean
  // modeling
  drawRectangle(p0: Vec3, p1: Vec3): { sketch: string; region: string }
  extrudeRegion(sketch: string, region: string, distance: number): string
  /** Convenience: rectangle on the ground from p0→p1, extruded `height`. */
  drawBox(p0: Vec3, p1: Vec3, height: number): string
  /** `instance` is the placement handle when the ray struck geometry reached
   *  through a component instance (definition-local `object`/`face`), or
   *  `null` for a plain/group-member hit — the same three-way split
   *  `pick_face`'s own `instance()` accessor returns. */
  pickFace(rayOrigin: Vec3, rayDir: Vec3): { object: string; face: string; instance: string | null } | null
  pushPull(object: string, face: string, distance: number): void
  boolean(op: number, a: string, b: string): string
  /**
   * Combine two tree nodes — plain solids or whole groups (`boolean_nodes`,
   * the group-ops design). `op` is 0=union, 1=subtract (a−b), 2=intersect;
   * `a`/`b` are `{kind, id}` refs with kind `'object' | 'group'`. Returns the
   * result root: a single object, or a result group of disjoint pieces.
   */
  booleanNodes(
    op: number,
    a: { kind: string; id: string },
    b: { kind: string; id: string },
  ): { kind: string; id: string }
  /**
   * Group nodes into a merge group (the same `group_nodes` call Object ▸ Group
   * commits) and return the group handle. Each ref's kind is
   * `'object' | 'group' | 'instance'`.
   */
  groupNodes(nodes: { kind: string; id: string }[]): string
  /**
   * Direct members of a group, as `{kind, id}` refs — for asserting result
   * and copy structure without the Outliner DOM.
   */
  getGroupMembers(id: string): { kind: string; id: string }[]
  /**
   * The containing group of a tree node (`node_parent`), or `null` at the
   * top level — for asserting Outliner drag-and-drop reparenting
   * (`reparent_nodes`) without the DOM. `kind` is `'object' | 'group' |
   * 'instance'`.
   */
  getNodeParent(kind: string, id: string): string | null
  /** Whether an object is currently a watertight solid (`object_solid`). */
  isObjectSolid(id: string): boolean
  /**
   * World-axis-aligned bounding box of `object`'s current mesh, as
   * `[minX,minY,minZ,maxX,maxY,maxZ]` (meters) — read from `object_mesh`'s
   * position buffer, the same source ScaleTool's gizmo box is computed from
   * on the UI side.
   */
  getObjectBounds(id: string): [number, number, number, number, number, number]
  /**
   * Deep-copy ANY tree node — object, group, or instance — offset by
   * `(dx, dy, dz)` meters: `duplicate_node` on the node's own kind, exactly
   * the Move+Alt copy commit. Returns the new root node.
   */
  copyNode(
    kind: string,
    id: string,
    dx: number,
    dy: number,
    dz: number,
  ): { kind: string; id: string }
  deleteObject(id: string): void
  /** Delete ANY tree node — object, group, or instance (undoable). Wraps
   *  `delete_node` on the node's own kind, the general form `deleteObject`
   *  predates (kept for its existing call sites). Useful for setting up an
   *  "unused definition" scenario: deleting an instance without deleting
   *  its definition. */
  deleteNode(kind: string, id: string): void
  selectObjects(ids: string[]): void
  /** Edit ▸ Select All: every visible top-level node + free sketch (or a
   * group context's direct members) — the same path ⌘A takes. */
  selectAll(): void
  setCamera(pose: CameraPose): void
  /**
   * Render the scene at two camera poses and count the pixels that differ
   * between the two frames: `differing` (any channel off by > 8/255) and
   * `hard` (> 60/255 — a high-contrast flip, e.g. a dark edge line trading
   * places with the face fill behind it). With poses a sub-pixel rotation
   * apart, `hard` must stay near zero: a spray of hard flips means the
   * depth test is resolving coplanar edge/face fragments by rounding noise
   * (the edge-shimmer defect — every repaint of an orbit's damping tail
   * re-rolls that noise). Counts, not pixels, cross the boundary — frames
   * are megabytes and the verdict is a number.
   */
  frameStability(poseA: CameraPose, poseB: CameraPose): {
    width: number
    height: number
    differing: number
    hard: number
  }
  /**
   * Show/hide the origin axes (View ▸ Axes). Docs-screenshot convenience so a
   * capture can drop the axes when they'd overshadow the modeled solids,
   * without driving the View menu through the DOM. Delegates to the same
   * `ViewportApi.setAxesVisible` the menu item calls.
   */
  setAxesVisible(visible: boolean): void
  /** Show/hide the ground grid (View ▸ Grid). Same rationale as setAxesVisible. */
  setGridVisible(visible: boolean): void
  /** Show/hide all construction guides (View ▸ Guides). */
  setGuidesVisible(visible: boolean): void

  // -------- scenes (docs/design/scenes.md) --------
  /** Adds a Scene capturing every property (`Scene.add_scene`'s full
   *  bitmask, 31 = camera|hidden nodes|hidden tags|section|display) at the
   *  viewport's CURRENT camera pose, named `name`, appended after the
   *  active Scene (or at the end if none) — the minimal fixture builder
   *  `shop-mode.spec.ts` needs to prove Shop Mode's own read-only Scenes UI
   *  (pill, Views-sheet SCENES section) against a real captured Scene,
   *  without driving the full editor `ScenesPanel` this harness
   *  deliberately doesn't otherwise expose. Returns the new Scene's stable
   *  id (decimal string — this harness's usual `bigint`-as-string
   *  convention). */
  addScene(name: string): string
  /** Whether a tag path is hidden in the document's registry — a plain
   *  read of the persisted flag, for asserting what a Scene activation
   *  restored (docs/design/scenes.md §5). */
  isTagHidden(path: string[]): boolean

  // -------- outliner (Lane D: search/visibility) --------
  /** Toggle one node's own hidden flag through the app's real Outliner eye
   *  path (`App.handleToggleHidden`: session hidden set + union push to
   *  renderer/kernel + persisted `set_node_user_hidden`) — NOT a bare scene
   *  call, mirroring `toggleTagPath` above. */
  toggleNodeHidden(node: { kind: string; id: string }): void
  /** Whether `node`'s OWN key is in the app's hidden set — does not account
   *  for an ancestor group also being hidden (the Outliner row's "hidden by
   *  parent" dimming is a separate, DOM-visible concern); a plain read of
   *  the same `hiddenKeys` the eye icons render from. */
  isNodeHidden(node: { kind: string; id: string }): boolean
  /** Set the Outliner's text filter through its real `<input>` (native
   *  value setter + a dispatched `input` event, so React's `onChange`
   *  fires exactly as a real keystroke would) — the Outliner is plain DOM,
   *  not canvas, but state assertions here go through the harness anyway
   *  for parity with the rest of this API and to stay robust against
   *  incidental DOM-structure changes. Empty string clears the filter.
   *  Throws if the panel isn't mounted (Outliner tray section collapsed,
   *  or no document loaded). */
  setOutlinerFilter(text: string): void

  // -------- section plane (session view state, non-destructive) --------
  /** "Toggle Section Plane Active" — flips the placed section's clip on/off
   *  (Tools menu / palette). No-op when none is placed. */
  toggleSectionActive(): void
  /** The current session section (`{ origin, normal, active }`) or null —
   *  observe-only, reads the same SectionManager the tool/menu mutate. */
  getSectionState(): { origin: Vec3; normal: Vec3; active: boolean } | null
  /** Section-plane render diagnostics for a rendered object/instance: whether
   *  the widget overlay is built, the widget's own clip count (must be 0),
   *  the clip-plane count on that node's face material (-1 if not rendered),
   *  and the active clip plane's world normal + constant (null when inactive)
   *  for asserting the clip SIDE. `kind` is 'object'/'instance'; `id` decimal. */
  getSectionRenderInfo(
    kind: 'object' | 'instance',
    id: string,
  ): {
    widget: boolean
    widgetClipCount: number
    nodeClipCount: number
    clipPlane: { normal: Vec3; constant: number } | null
  }

  replay(recordingJson: string): string
  // serialization ( — round-trips the live `.hew` container through the
  // app's real save/open path). Bytes cross `page.evaluate` as a plain number[]
  // (portable + structured-cloneable); a box is tiny, so the cost is moot.
  save(): number[]
  load(bytes: number[]): void
  /** Export the current scene to binary STL bytes (mm, Z-up) through the
   * app's REAL exporter (`wasmScene.export`, `crates/mesh-export`);
   * instances flatten into the soup. `segmentsPerTurn` re-facets curved
   * walls (0 = stored facets). Null when nothing exports. `triangleCount`
   * is read back out of the binary STL header itself (byte offset 80), not
   * writer-side bookkeeping. Test-only — the round-trip verification uses
   * it. */
  exportStl(segmentsPerTurn: number): { bytes: number[]; triangleCount: number } | null
  /** Print recorder (docs/design/printing.md §12): what the dialog handed
   * to the (recording) system print host, plus page inspection. */
  print: {
    /** Arm the recording print host: from now on Print… hands its pages to
     * the recorder instead of the real system dialog, and Save PDF… keeps
     * the bytes instead of opening a save dialog. OFF by default — a dev
     * build is also what a person runs, and they want the real dialogs. */
    arm(): void
    /** Back to the real print host / save dialog. */
    disarm(): void
    /** Jobs handed to the print host so far. */
    jobs(): { setup: PrintSetup; pageCount: number; tiles: string[]; imagePx: { w: number; h: number }[]; jobTitle: string; paperMm: { w: number; h: number } }[]
    /** Bounding box of pixels darker than `threshold` (0-255, on the max
     * channel) in the LAST job's page `index` bitmap, in image pixels —
     * the scale assertion's probe. Null with no such page/pixels. */
    pageDarkBounds(index: number, threshold: number): Promise<{ x: number; y: number; w: number; h: number; imageW: number; imageH: number } | null>
    /** Dark span (first/last dark pixel) along one image row of the LAST
     * job's page `index`, at `rowFrac` of the image height (0 top … 1
     * bottom) — a probe for silhouettes between two rims. */
    rowDarkSpan(index: number, threshold: number, rowFrac: number): Promise<{ x: number; w: number; imageW: number } | null>
    /** How many `.hew-print-page` sections the print root holds right now. */
    printRootPages(): number
    /** The last Save PDF… result: byte length, the first bytes as text, the
     * suggested name, and how many `/Type /Page` objects it holds. */
    lastPdf(): { bytes: number; head: string; name: string; pages: number } | null
    /** The last Save PDF… bytes (for a spec that wants to write/validate the file). */
    lastPdfBytes(): number[] | null
  }
  /** Import binary/ASCII STL bytes through the REAL `scene.import_stl`,
   * returning the ImportReport (object/watertight/leaky/skipped/warnings).
   * Additive, exactly like File▸Import's kernel call. Test-only. */
  importStl(bytes: number[], unitScale: number): StlImportReportJs
  /** `Scene.skp_container(bytes)`: which `.skp` container the bytes are
   * (`'skp2026'`, `'skp2017'`, or `''`). Reads nothing from the document. Test-only. */
  skpContainer(bytes: number[]): string
  // recording ( high + low, one artifact)
  startRecording(): void
  stopRecording(): void
  isRecording(): boolean
  takeRecording(): string
  // queries
  getStateHash(): string
  getObjectCount(): number
  getObjectIds(): string[]
  getSelection(): { kind: string; id: string; ctx?: string; key?: string }[]
  /** The drawn, unpushed shapes an object carries on its faces, read from the
   *  object's drawing planes (`object_drawing_planes` + the object-scoped
   *  `plane_units_json`): a `sub_face` per region the drawing closes off, a
   *  `chord` per run of drawing edges that closes nothing. */
  getImprints(object: string): {
    kind: 'sub_face' | 'chord'
    id: string
    loop: [number, number, number][]
    name: string
    /** Per-edge analytic circle (loop[k]→loop[k+1]), or `null` per edge that
     *  is a plain line. */
    curves: ({ center: [number, number, number]; radius: number | null } | null)[]
  }[]
  /** The drawn circles and arcs other drawing cut into several runs on an
   *  object's faces, each with its curve key and its runs. */
  getCurveRuns(object: string): {
    id: string
    name: string
    closed: boolean
    runs: { key: string; edges: number }[]
  }[]
  /** The labels the Outliner lists under an object for its drawn shapes
   *  (one row per connected shape: "Shape", numbered when several). */
  getOutlinerShapeLabels(object: string): string[]
  getLastError(): string | null
  /**
   * The document's current movable drawing axes (tool-parity §4): the flat
   * 12-float `Scene::axes()` buffer — `[ox,oy,oz, xx,xy,xz, yx,yy,yz,
   * zx,zy,zz]` (origin, unit red/X, unit green/Y, derived unit blue/Z).
   * World identity (`[0,0,0, 1,0,0, 0,1,0, 0,0,1]`) until the Axes tool or
   * `resetAxes` moves it. Test-only accessor for E2E specs that verify a
   * draw gesture landed on a MOVED frame, not the world ground plane.
   */
  getDrawingAxes(): number[]

  /** Handles of every currently live annotation (dimension/leader text —
   * docs/design/dimensions-text.md). */
  getAnnotationIds(): string[]
  /** `"linear"` | `"radial"` | `"leader"`, or `undefined` if stale/hidden. */
  getAnnotationKind(id: string): string | undefined
  /** Whether `id` is currently `detached` (its anchor couldn't be
   * geometrically re-anchored through the last transform that touched it),
   * or `undefined` if stale/hidden. */
  getAnnotationDetached(id: string): boolean | undefined
  /** The currently RENDERED label text for `id` (the app-computed
   * measurement, or its `text_override`), or `null` if not live/rendered —
   * proves a unit-setting change actually re-labels a dimension. */
  getAnnotationLabel(id: string): string | null
  /**
   * The current world-space position of annotation `id`'s text billboard
   * (the same point the double-click-to-edit gesture projects to place the
   * in-viewport editor), or `null` if `id` isn't live/rendered. Lets a
   * pixel-precision test sample the real render-time label anchor — correct
   * for a linear dimension's 'broken' AND 'outside' gap-layout modes alike
   * — rather than guessing at the line's midpoint.
   */
  getAnnotationTextWorldPosition(id: string): Vec3 | null
  /**
   * The world-space endpoints of a LINEAR dimension's own drawn line
   * (`a + offset`, `b + offset` — the same `a1`/`b1` `SceneRenderer.
   * _buildAnnotationBase` computes), or `null` if `id` is stale/hidden or not
   * a linear dimension. A pixel-precision test convenience: lets a test that
   * drove the real DimensionTool gesture (rather than `addLinearDimension`'s
   * exact-coordinate shortcut) still know exactly where the committed line
   * should render, without duplicating the offset arithmetic itself.
   */
  getLinearDimensionEndpoints(id: string): { a1: Vec3; b1: Vec3 } | null
  /** The two snapped ANCHOR points of a linear dimension (before the offset). */
  getLinearDimensionAnchors(id: string): { a: Vec3; b: Vec3 } | null

  /**
   * Add a linear dimension directly (free anchors, no node), bypassing
   * DimensionTool's click-drag-click gesture — a pixel-precision test
   * convenience (dimensions-playtest2.md's depth/z-fighting E2E coverage
   * needs exact, deterministic annotation geometry, not whatever a
   * mouse-driven snap resolves to) mirroring `addGuideLine`'s role for
   * construction guides. `plane` is `[px,py,pz,nx,ny,nz]`. Returns the new
   * annotation's handle (decimal string).
   */
  addLinearDimension(aPoint: Vec3, bPoint: Vec3, offset: Vec3, plane: [number, number, number, number, number, number]): string

  /**
   * Add a radial dimension directly (free anchor, no node) — same rationale
   * as `addLinearDimension`. `curvePlane` is `[px,py,pz,nx,ny,nz]`. Returns
   * the new annotation's handle (decimal string).
   */
  addRadialDimension(
    anchor: Vec3,
    kind: 'radius' | 'diameter',
    center: Vec3,
    radius: number,
    curvePlane: [number, number, number, number, number, number],
    leaderDir: Vec3,
  ): string

  // -------- NEW in  --------

  /**
   * Draw a chain of line segments in a new ground sketch. Points are an ordered
   * list of positions; segments are added between consecutive pairs. Returns the
   * sketch handle (string) and all closed regions that formed (as handle strings).
   * Equivalent to what LineTool commits: begin_ground_sketch → N × sketch_add_segment.
   */
  drawLineChain(points: Vec3[]): { sketch: string; regions: string[] }

  /**
   * Draw a regular N-gon approximation of a circle in a new ground sketch.
   * `center` is the XY centroid (Z ignored), `radius` in meters, `nSegments`
   * defaults to a fixed 24 for test determinism (CircleTool itself adapts
   * the count to the radius — the true-curves design §6; pass an
   * explicit count to exercise other densities). Returns the sketch and the
   * one closed region that forms (the N-gon). Equivalent to CircleTool's
   * commit, including the analytic curve bracket.
   */
  drawCircle(center: Vec3, radius: number, nSegments?: number): { sketch: string; region: string }

  /**
   * Imprint a circle onto an existing solid face (draw-on-face), carrying the
   * circle's analytic identity so a later push-through of the imprinted disk
   * shades smooth and offsets its radius (the true-curves design, playtest
   * fix C3). `center` must lie on the face plane; `radius` in meters. Mirrors
   * CircleTool face mode (one draft on the face with a circle curve bracket). Returns the new disk
   * sub-face handle — pick nothing, push it straight through with `pushPull`.
   */
  imprintCircleOnFace(
    object: string,
    face: string,
    center: Vec3,
    radius: number,
    nSegments?: number,
  ): string

  /**
   * Offset a sketch region's whole boundary (outer loop and holes) by a
   * signed distance — negative shrinks the material, positive grows it.
   * The Offset tool's commit: ONE draft on the sketch's plane context
   * (`draft_offset_region`, one undo step). Returns the handles of the regions the
   * offset created.
   */
  offsetRegion(sketch: string, region: string, distance: number): string[]

  /**
   * Offset a solid face's outer boundary by a signed distance (negative =
   * into the face; the sub-face returned is the one inside the loop) and imprint the
   * loop — the Offset tool's face commit (one draft on the face's plane context,
   * `draft_offset_region`). Returns the new
   * sub-face handle; push/pull it to boss/recess.
   */
  offsetFace(object: string, face: string, distance: number): string

  /**
   * Draw a faceted 2-point arc in a new ground sketch. `a`/`b` are the
   * chord endpoints (z should be 0 — ground plane), `sagitta` is the signed
   * bulge distance from the chord midpoint (positive on the CCW side of a→b,
   * viewed from +Z). With `close`, also adds the chord b→a so the arc closes
   * into a region. Equivalent to ArcTool's ground commit:
   * begin_ground_sketch → N × sketch_add_segment along `arcPolylineOnPlane`.
   */
  drawArc(a: Vec3, b: Vec3, sagitta: number, close?: boolean): { sketch: string; regions: string[] }

  /**
   * Cut `face` of `object` along a faceted 2-point arc. `a`/`b` must
   * lie on the face (endpoints on its boundary for a boundary-to-boundary
   * cut); `sagitta` is signed in the face's `facePlaneBasis(normal)` (u, v)
   * frame. Equivalent to ArcTool's face commit: one draft on the face with the
   * arc polyline's segments.
   */
  drawArcOnFace(object: string, face: string, a: Vec3, b: Vec3, sagitta: number): void

  /**
   * Move `object` by a world translation (meters). Calls `transform_object` with
   * a pure-translation 3×4 affine, exactly as MoveTool commits. The handle
   * is unchanged; the document state_hash changes.
   */
  moveObject(object: string, dx: number, dy: number, dz: number): void

  /**
   * Copy `object` to a new object offset by `(dx, dy, dz)` meters. Calls
   * `duplicate_node(0, id, affine)` with a translation affine, matching the
   * "Option-drag" branch of MoveTool. Returns the new node's kind and id.
   */
  copyObject(id: string, dx: number, dy: number, dz: number): { kind: string; id: string }

  /**
   * Rotate `object` by `angleDeg` degrees around `axis` (default: Z = [0,0,1]).
   * Builds a Rodrigues rotation matrix and calls `transform_object`, matching
   * RotateTool's commit.
   */
  rotateObject(object: string, angleDeg: number, axis?: Vec3): void

  /**
   * Scale `object` by `(sx, sy, sz)` about `pivot` (world meters, non-uniform
   * allowed). Builds the same "diag(sx,sy,sz) about a world pivot" affine as
   * `nonUniformScaleAboutPivot` in `tools/transformMath.ts` and calls
   * `transform_object`, matching ScaleTool's grip-gizmo commit. The handle is
   * unchanged; the document state_hash changes.
   */
  scaleObject(object: string, sx: number, sy: number, sz: number, pivot: Vec3): void

  /**
   * Slice a watertight solid by a plane. `plane` is 6 floats `[px,py,pz,nx,ny,nz]`
   * (a point on the plane + its normal). Returns `[positiveId, negativeId]` as
   * decimal strings. Calls `slice_object` directly (SliceTool's commit).
   */
  sliceObject(
    object: string,
    plane: [number, number, number, number, number, number],
  ): [string, string]

  /**
   * Add a construction guide line through `(ox,oy,oz)` along direction
   * `(dx,dy,dz)`. Returns the guide handle as a decimal string. Matches
   * TapeMeasureTool's parallel-guide commit and ProtractorTool's angular-guide
   * commit.
   */
  addGuideLine(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number): string

  /**
   * Add a construction guide point at `(x,y,z)`. Returns the guide handle as a
   * decimal string. Matches TapeMeasureTool's point-mode commit.
   */
  addGuidePoint(x: number, y: number, z: number): string

  /** Delete one construction guide by handle string. */
  deleteGuide(id: string): void

  /** Delete all construction guides in one undo step. */
  deleteAllGuides(): void

  /** Handles of all currently visible construction guides, as decimal strings. */
  getGuideIds(): string[]

  /** `'line' | 'point'` for a guide handle, or undefined if stale/hidden. */
  getGuideKind(id: string): string | undefined

  /** A guide's geometry: `[ox,oy,oz, dx,dy,dz, from,to]` for a line (origin,
   * unit direction, then the span in meters along it; -Infinity / +Infinity
   * for an end that runs on forever), `[x,y,z]` for a point; undefined if
   * stale/hidden. */
  getGuideGeometry(id: string): number[] | undefined

  /**
   * Document-level undo (same kernel path as Cmd+Z). Calls `scene_undo()` and
   * reconciles the viewport. Throws if there is nothing to undo.
   */
  undo(): void

  /**
   * Document-level redo. Calls `scene_redo()` and reconciles the viewport.
   * Throws if there is nothing to redo.
   */
  redo(): void

  /** True if there is a document action to undo. */
  canUndo(): boolean

  /** True if there is a document action to redo. */
  canRedo(): boolean

  /**
   * Set the active display/parse length unit ( VCB). `format` is one
   * of `'m'|'cm'|'mm'|'arch'|'frac_in'|'dec_in'`. Writes through to
   * `setLengthUnit` (the same singleton the tools use) so subsequent
   * `formatLength` / `parseLength` calls reflect the new format.
   */
  setLengthUnit(format: string): void

  /** The currently active length format string (e.g. `'cm'`). */
  getLengthUnit(): string

  /**
   * Format `meters` (a kernel f64 length) using the current display unit, as
   * the VCB and status bar do. E.g. 1.5 m → "150 cm" when unit is cm.
   */
  formatLength(meters: number): string

  /**
   * Parse a typed length string to meters using the current unit ( VCB).
   * Returns `null` on empty/invalid input. E.g. "100 cm" → 1.0.
   */
  parseLength(input: string): number | null

  // -------- materials --------

  /**
   * Add a solid-color material to the palette and return its handle (decimal
   * string). `r`/`g`/`b`/`a` are 0–255; `a` < 255 is translucent. Wraps
   * `add_material`. Palette additions are not individually undoable — only
   * assignment (via `paintObject`/`paintFace`) is.
   */
  addMaterial(name: string, r: number, g: number, b: number, a: number): string

  /** Rename a palette material (undoable). Wraps `set_material_name`
   *  (v1.1 assets lane). */
  renameMaterial(material: string, name: string): void

  /** Delete a palette material (undoable): unpaints every face/object-base
   *  reference, then tombstones it. Wraps `delete_material`. */
  deleteMaterial(material: string): void

  /** How many LIVE faces and object bases carry `material` — wraps
   *  `material_usage`. Zero for a stale/deleted handle. Read-only. */
  materialUsage(material: string): number

  /** Handles of palette materials nothing references — wraps
   *  `unused_materials`. Read-only. */
  unusedMaterials(): string[]

  /**
   * Set `object`'s base material — the color the whole solid (and faces grown
   * later by extrude/boolean) renders with, unless a face is explicitly painted.
   * Wraps `set_object_material`. Pass `null` to clear back to the renderer
   * default. Undoable.
   */
  paintObject(object: string, material: string | null): void

  /**
   * Paint a single `face` of `object` with `material`, overriding the object's
   * base material for that face. Wraps `paint_face`. Pass `null` for `material`
   * to reset the face to the (unpainted) default. Undoable.
   */
  paintFace(object: string, face: string, material: string | null): void

  /**
   * Read back `face`'s own material and its object's base material — wraps
   * the eyedropper's `face_material` getter (paint-tool design §1). `null`
   * in either slot is the unpainted/default sentinel; `null` for the whole
   * result means `object`/`face` is stale. Read-only, not undoable.
   */
  getFaceMaterial(object: string, face: string): { face: string | null; objectDefault: string | null } | null

  /**
   * Replace every assignment of `from` with `to` in one atomic step — wraps
   * `replace_material` (paint-tool design §2). `documentWide: true` sweeps
   * every object; `false` confines the sweep to `scopeObject`. `null` for
   * `from`/`to` is the unpainted sentinel, same convention as `paintFace`.
   * Undoable as one document action.
   */
  replaceMaterial(
    documentWide: boolean,
    scopeObject: string | null,
    from: string | null,
    to: string | null,
  ): void

  /**
   * Add a textured material to the palette and return its handle. Wraps
   * `add_texture_material`. `format`: 0 = PNG, 1 = JPEG. `worldW`/`worldH`
   * are the real-world meters one tile covers (the planar-default UV
   * divides by these — paint-tool design §3). Test-only: E2E has no file
   * upload flow, so this is the only way to get a textured material into a
   * scene under test.
   */
  addTextureMaterial(
    name: string,
    r: number,
    g: number,
    b: number,
    a: number,
    image: number[],
    format: number,
    worldW: number,
    worldH: number,
  ): string

  /**
   * `face`'s explicit UV positioning frame — wraps `face_uv_frame`
   * (paint-tool design §3). `null` if `object`/`face` is stale; `[]` if the
   * face carries no explicit frame (the planar-projection default);
   * otherwise 8 numbers `[sx, sy, sz, tx, ty, tz, u0, v0]`. Read-only, not
   * undoable.
   */
  getFaceUvFrame(object: string, face: string): number[] | null

  /**
   * Sets `face`'s UV positioning frame — wraps `set_face_uv_frame`
   * (paint-tool design §3). `null` resets to the planar-projection default;
   * otherwise exactly 8 numbers, same layout as `getFaceUvFrame`. Undoable.
   */
  setFaceUvFrame(object: string, face: string, frame: number[] | null): void

  // -------- components --------

  /**
   * Copy an instance to a sibling instance of the same definition, offset by
   * `(dx, dy, dz)` meters — `duplicate_node(2, id, affine)`, the instance arm
   * of MoveTool's Option-drag. Returns the new instance handle.
   */
  copyInstance(id: string, dx: number, dy: number, dz: number): string

  /**
   * Detach an instance onto its own private definition copy (Make Unique).
   * Returns the new definition handle. A set instance name is promoted to
   * the new definition's name; otherwise the copy is named "<def> Copy"
   * (disambiguated "<def> Copy 2", …).
   */
  makeUnique(instance: string): string

  /** Rename a node (object/group/instance); `null` clears. Undoable. */
  setNodeName(kind: string, id: string, name: string | null): void

  /** A node's own kernel name, or `null` if unnamed. */
  getNodeName(kind: string, id: string): string | null

  /** Add a tag path (root-first segments) to a node. Undoable. */
  addNodeTag(kind: string, id: string, path: string[]): void

  /** A node's tag paths, `/`-joined (e.g. `"Objects/Boxes"`). */
  getNodeTags(kind: string, id: string): string[]

  /** Rename a component definition; `null` clears. Undoable, renames every
   * instance's shared label. */
  setComponentName(component: string, name: string | null): void

  /** A component definition's name, or `null` if unnamed. */
  getComponentName(component: string): string | null

  /** The definition an instance places, or `null` if the handle is stale. */
  getInstanceDef(instance: string): string | null

  /** Every visible instance of a definition, as decimal handle strings. */
  getInstancesOf(component: string): string[]

  /**
   * The instance an open explode session was entered through (decimal
   * handle string), or `null` when no session is open — lets a spec assert
   * a double-click genuinely fell back to the K1/K2 context rather than
   * silently opening a session (`explode_session_instance`).
   */
  getExplodeSessionInstance(): string | null

  /**
   * A component definition's live member OBJECTS, as decimal handle
   * strings (component-edit-parity.md) — the ground truth for "did this
   * edit land in the shared definition (seen by every instance) or
   * escape into the world?" `component_member_objects`.
   */
  getComponentMemberObjects(component: string): string[]

  /**
   * A component definition's live, not-yet-extruded member SKETCHES, as
   * decimal handle strings (component-edit-parity.md phase K1) —
   * `component_member_sketches`. The ground truth for "did a plane-mode
   * draw inside this instance mint a DEFINITION-owned sketch, or did it
   * escape to a world one?"
   */
  getComponentMemberSketches(component: string): string[]

  /** Replace the selection with arbitrary nodes (kind + handle string; an
   *  imprint ref carries its owning `object`, a sketch sub-entity its
   *  `sketch`). */
  selectNodes(nodes: { kind: string; id: string; ctx?: string; key?: string }[]): void
  /** The drawing on a plane (`plane_units_json`) — units, their edges with
   *  stores, and regions; keys are 16-hex strings. */
  getPlaneUnits(ctx: string): {
    units: {
      key: string
      edges: { key: string; a: number[]; b: number[]; store: { kind: string; object?: number; sketch?: number }; curve: { center: number[]; radius: number | null } | null }[]
      /** Curve runs: the piece of one circle/arc/polygon a click selects. */
      curves: { key: string; curve_key: string; kind: 'circle' | 'polygon'; center: number[]; radius: number | null; edges: string[] }[]
    }[]
    regions: { key: string; outer: number[][]; holes: number[][][]; over: { object: number; face: number | null } | null; extrude: { sketch: number; region: number } | null }[]
  }
  /** The canonical plane-context string of a face / plane / the ground. */
  ctxOfFace(object: string, face: string, instance?: string): string | null
  ctxOfPlane(point: number[], normal: number[]): string | null
  ctxGround(): string
  // -------- follow me --------

  /**
   * Rotate a free-standing sketch by `angleDeg` about the world `axis`
   * through `origin` — the same `transform_sketch` bake the Move/Rotate
   * tools' sketch branch commits. Lets a driver stand a ground-drawn
   * profile up perpendicular to a path before a `followMe*` call, exactly
   * as a user would with the Rotate tool.
   */
  rotateSketch(sketch: string, angleDeg: number, axis: Vec3, origin: Vec3): void

  /** Every edge handle of `sketch` (union of its islands' edges), as
   * decimal strings — the raw material for a `followMeAlongEdges` path. */
  getSketchEdgeIds(sketch: string): string[]

  /** Every edge of `sketch` as EXACT (f64) endpoint pairs
   * `[ax,ay,az, bx,by,bz]` — unlike `getSketchLines`, which is the f32
   * render buffer. For asserting a committed length to the last digit. */
  getSketchSegmentsExact(sketch: string): number[][]

  /** Every live sketch handle, as decimal strings — lets a spec find the
   * sketch a TOOL created (the tool's cached handle is internal). */
  getSketchIds(): string[]

  /** All of `sketch`'s edges as flat endpoint pairs
   * `[ax,ay,az, bx,by,bz, ...]` — the geometry probe for asserting where a
   * sketch's lines actually stand (e.g. upright after a rotate). */
  getSketchLines(sketch: string): number[]

  /** `sketch`'s plane as `[px,py,pz, nx,ny,nz]` (point + unit normal), or
   *  `null` for a stale/hidden sketch — the probe for asserting a gesture
   *  landed on a MOVED drawing-axes frame's plane (tool-parity §4) rather
   *  than the world ground plane. */
  getSketchPlane(sketch: string): number[] | null

  /** `sketch`'s islands (connected components) with their member edges, as
   * decimal strings — the probe for asserting what one path click should
   * pick up (Follow Me grabs the clicked edge's whole island). */
  getSketchIslands(sketch: string): { island: string; edges: string[] }[]

  /** How many closed regions `sketch` currently holds — for asserting that
   * deleting a shared partition edge merges the two regions it divided. */
  getSketchRegionCount(sketch: string): number

  /** The closed regions `sketch` currently holds, as decimal strings — the
   * handles `extrudeRegion` takes (a free region left by a draft). */
  getSketchRegionIds(sketch: string): string[]

  /**
   * Follow Me along sketch edges (the follow-me design): sweeps the
   * closed profile `region` of `sketch` along the chain the `edges` of
   * `pathSketch` form. Returns the new object handle. Equivalent to
   * FollowMeTool's edge-path commit (`follow_me_along_edges`). `group`
   * births the result inside that group (design §2f) instead of
   * top-level. `stopLen` (trailing, so existing `group` callers are
   * unaffected) is the partial-sweep arc length from the seam — NEGATIVE
   * sweeps `|stopLen|` the OTHER way around a closed loop (K2 — the same
   * value FollowMeTool's drag gesture computes and passes verbatim);
   * `undefined` sweeps the full path.
   */
  followMeAlongEdges(
    sketch: string,
    region: string,
    pathSketch: string,
    edges: string[],
    group?: string,
    stopLen?: number,
  ): string

  /**
   * Follow Me around a solid face's outer boundary loop (molding). Returns
   * the new object handle. Equivalent to FollowMeTool's face-path commit
   * (`follow_me_around_face`). `group` births the result inside that group
   * (design §2f) instead of top-level.
   */
  followMeAroundFace(sketch: string, region: string, object: string, face: string, group?: string): string

  /**
   * Follow Me around a face reached THROUGH a component instance (design
   * §2e): the definition face's loop rides the instance's pose into world
   * space. Equivalent to FollowMeTool's instanced-face-path commit
   * (`follow_me_around_instance_face`).
   */
  followMeAroundInstanceFace(
    sketch: string,
    region: string,
    instance: string,
    pathObject: string,
    pathFace: string,
  ): string

  /**
   * `followMeAroundFace` that MERGES the swept molding with the path's own
   * solid in one gesture and one undo step (design §3b) — Subtract when the
   * sweep overlaps the solid's interior, Union when it only rides the
   * surface, decided by the kernel itself. Equivalent to FollowMeTool's
   * Ctrl/Cmd-click commit (`follow_me_merged_around_face`).
   */
  followMeMergedAroundFace(sketch: string, region: string, pathObject: string, pathFace: string): string

  /**
   * Follow Me with a solid FACE as the profile (design §3a), along a chain
   * of sketch edges: the face's boundary (holes become tunnels) sweeps into
   * a NEW object; the source solid is untouched unless the profile face
   * belongs to the path's own solid, which auto-merges (design §3b) — see
   * `followMeFaceAroundFace`. Equivalent to FollowMeTool's face-profile
   * commit (`follow_me_face_along_edges`).
   */
  followMeFaceAlongEdges(
    profileObject: string,
    profileFace: string,
    pathSketch: string,
    edges: string[],
  ): string

  /**
   * Follow Me with a solid FACE as the profile around another face's outer
   * boundary loop — `followMeFaceAlongEdges`'s face-path sibling
   * (`follow_me_face_around_face`). Auto-merges with the path's own solid
   * when the profile face belongs to it (design §3b) — no separate call for
   * that case, the kernel decides from object identity alone.
   */
  followMeFaceAroundFace(
    profileObject: string,
    profileFace: string,
    pathObject: string,
    pathFace: string,
  ): string

  // -------- tags --------

  /**
   * Toggle a tag path's hidden flag through the app's real Tags-panel eye
   * path — session hidden set, renderer/kernel union push, and the
   * persisted `set_tag_hidden` flag together.
   */
  toggleTagHidden(path: string[]): void

  /**
   * Delete a tag everywhere through the app's real Tags-panel delete path
   * (undoable kernel `delete_tag` + tag-visibility resync).
   */
  deleteTag(path: string[]): void

  // -------- components & instances --------

  /**
   * Fold objects into a shared component definition plus an identity-posed
   * instance (Object ▸ Make Component, without the selection side effect —
   * the placement renders batched, not materialized). Returns the instance
   * and definition handles as decimal strings.
   */
  makeComponent(objectIds: string[]): { instance: string; component: string }

  /**
   * Stamp another instance of `component`, translated by `(dx, dy, dz)`
   * meters. Returns the new instance handle as a decimal string.
   */
  placeInstance(component: string, dx: number, dy: number, dz: number): string

  /** Handles of all currently live component definitions — wraps
   *  `component_ids` (v1.1 assets lane). Read-only. */
  getComponentIds(): string[]

  /** Rename a component definition (undoable). Wraps `set_component_name`. */
  renameComponent(component: string, name: string): void

  /** Delete a component definition together with every instance that
   *  places it, as one undo entry. Wraps `delete_definition`. */
  deleteDefinition(component: string): void

  /** How many live instances place `component` directly — wraps
   *  `definition_usage`. Read-only. */
  definitionUsage(component: string): number

  /** Handles of live definitions nothing reachable places — wraps
   *  `unused_definitions`. Read-only. */
  unusedDefinitions(): string[]

  /** Delete every unused definition and material as ONE undo entry — wraps
   *  `purge_unused`. Returns the counts actually removed. */
  purgeUnused(): { materials: number; definitions: number }

  // -------- camera --------

  /**
   * Count of animation-frame callbacks the on-demand render pump
   * (`viewport/renderScheduler.ts`, docs/design/v1.1-cycle.md Lane F —
   * "Render loop on demand") has actually run since the viewport mounted.
   * `idle.spec.ts` asserts this barely advances while nothing is happening
   * and advances-then-settles across an orbit drag.
   */
  frameCount(): number

  /** Frame all visible geometry (View ▸ Zoom Extents). */
  zoomExtents(): void

  /** The camera's current pose — the read complement of `setCamera`, for
   * asserting framing (e.g. Zoom Extents re-targeting onto an instance). */
  getCamera(): { position: Vec3; target: Vec3; fovDeg: number }

  /**
   * The camera's FULL working view (docs/design/camera.md §5) — projection,
   * fov, eye/target/up — unlike `getCamera` (always perspective-shaped,
   * reads the possibly-stale `controls.target`), this covers both
   * projections and derives `target` fresh from the live pose. The read
   * side of camera persistence.
   */
  getCameraState(): {
    projection: 'perspective' | 'parallel'
    fovDeg: number
    eye: Vec3
    target: Vec3
    up: Vec3
  }

  /** Fly's engagement, speed readout, and cursor lock (`Viewport.FlyState`)
   * — whether the hold or Camera ▸ Fly is on, and whether the cursor is
   * hidden and frozen for it. */
  getFlyState(): { mode: 'off' | 'hold' | 'latched'; speedText: string; locked: boolean; canLock: boolean }

  /**
   * Pushes the CURRENT live camera view into the document (the same
   * `Document::set_camera_state` call App's real Save/Save As run right
   * before `scene.save()`) and returns the resulting bytes — camera
   * persistence's save side, exercised end to end without needing an
   * actual OS file-save dialog in this harness.
   *
   * Also calls `scene.mark_saved()` after grabbing the bytes (Lane C, docs/
   * design/v1.1-cycle.md) — mirroring App's real save flow, which marks the
   * document clean once its write actually lands (`markSavedIfUnmoved`,
   * App.tsx) — and reconciles (`act`, not `query`) so the app's own
   * `docSession.dirty`/title-dot state picks up the new saved mark
   * immediately, exactly as it would after a real Save. So this is the
   * harness's "the document was saved" step for `at_saved_mark`/dirty-state
   * E2E coverage, not just a bytes producer.
   */
  saveWithCameraState(): number[]

  /** Project a world point to canvas-relative CSS pixels at the current
   * camera, for pointer-driven E2E that must target an on-screen widget (e.g.
   * grabbing a Scale-gizmo grip by its exact projected position instead of a
   * hard-coded pixel). `behind` true = the point is behind the camera. */
  worldToScreen(world: Vec3): { x: number; y: number; behind: boolean }
  /**
   * View-only isolation (`ViewportApi.isolate`), through the app's own handler
   * so the kernel's hide state follows exactly as it does from Model Health.
   * A target is `{kind:'object'|'group'|'instance', id}` or
   * `{kind:'member', object, instance}`. Returns how many objects are shown.
   */
  isolate(targets: ({ kind: string; id: string } | { kind: 'member'; object: string; instance: string })[]): number
  /** End isolation (Show everything). */
  clearIsolation(): void
  /** The live isolation (targets, shown count, and what is hidden/faded), or
   *  null when nothing is isolated. Ids are decimal strings. */
  getIsolation(): {
    targets: ({ kind: string; id: string } | { kind: 'member'; object: string; instance: string })[]
    hiddenObjects: string[]
    hiddenInstances: string[]
  } | null
  /**
   * Render the current camera pose and read back the color of the pixel a
   * world point projects to — for pinning *which* of two depth-coincident
   * layers wins a rendering tie (e.g. a sketch line drawn on an origin axis
   * must show the line's color, not the axis's). `null` when the point is
   * behind the camera or projects outside the canvas. Renders (via the same
   * frame capture `frameStability` uses) *before* projecting, deliberately:
   * `setCamera` leaves `camera.matrixWorld`/`matrixWorldInverse` stale until
   * the next render traversal recomputes them, so projecting first would
   * silently use the previous pose in a script that never yields to the
   * app's own render loop between `setCamera` and this call. The projected
   * CSS-pixel point is scaled to the drawing buffer's device pixels (the
   * webkit project runs at `deviceScaleFactor: 2`) and WebGL's bottom-left
   * origin is corrected here.
   */
  pixelColorAt(world: Vec3): { r: number; g: number; b: number } | null
}

declare global {
  interface Window {
    __hew_test?: HewTestHarness
  }
}

/**
 * Install `window.__hew_test`. Returns an uninstall function (for HMR / unmount).
 * Caller gates on a debug/test build.
 */
export function installTestHarness(deps: HarnessDeps): () => void {
  let lastError: string | null = null

  const scene = (): Scene => {
    const s = deps.getScene()
    if (s === null) throw new Error('__hew_test: scene not ready')
    return s
  }

  // Run a mutation, reconcile + re-tessellate on success, and track the last
  // error. When the viewport is mounted we drive its `refreshScene` (which
  // re-tessellates the new geometry to the GPU *and* reconciles the app, exactly
  // like a tool commit) — a bare `reconcile()` updates React state but leaves the
  // canvas stale, so harness geometry would never render. Headless
  // callers with no viewport fall back to a plain reconcile.
  function act<T>(fn: (s: Scene) => T): T {
    try {
      const out = fn(scene())
      const api = deps.getViewportApi()
      if (api !== null) api.refreshScene()
      else deps.reconcile()
      lastError = null
      return out
    } catch (e) {
      lastError = e instanceof Error ? e.message : String(e)
      throw e
    }
  }
  /** The drawing's smallest region over a face that contains `p` (a point on
   *  the plane `ctx`), as its listing entry — how the face-drawing helpers
   *  name the sub-face a draft just made. */
  function faceRegionAt(s: Scene, ctx: string, p: V3): PlaneRegion | null {
    const pu = readPlaneUnits(s as unknown as PlaneUnitsScene, ctx)
    if (pu === null) return null
    let best: { r: PlaneRegion; area: number } | null = null
    for (const r of pu.regions) {
      if (r.over === null || r.over.face === null) continue
      if (!ringContains(r.outer, p) || r.holes.some((h) => ringContains(h, p))) continue
      let a2 = 0
      for (let i = 0; i < r.outer.length; i++) {
        const u = r.outer[i], v = r.outer[(i + 1) % r.outer.length]
        a2 += Math.hypot(u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
      }
      if (best === null || a2 < best.area) best = { r, area: a2 }
    }
    return best === null ? null : best.r
  }

  function query<T>(fn: (s: Scene) => T): T {
    try {
      return fn(scene())
    } catch (e) {
      lastError = e instanceof Error ? e.message : String(e)
      throw e
    }
  }

  // The kernel's "no/clear material" sentinel is u64::MAX (see paint_face /
  // set_object_material in wasm-api). Map the harness's `null` to it.
  const MATERIAL_NONE = (1n << 64n) - 1n
  const materialHandle = (m: string | null): bigint => (m === null ? MATERIAL_NONE : BigInt(m))

  // Map a harness kind string to the numeric FFI kind tag; sketch kinds have
  // no kernel NodeId and must never reach a node_id-keyed wasm call.
  const kindNum = (kind: string): number => {
    const n = nodeKindToNumber(kind as NodeKind)
    if (n < 0) throw new Error(`__hew_test: '${kind}' has no kernel NodeId`)
    return n
  }

  // Add the four edges of the axis-aligned rectangle p0→p1 (on p0's z plane) to
  // `sketch`, returning the first closed region handle it forms. Bracketed in
  // one gesture (M-sketches-first-class) so a harness-drawn rectangle has the
  // same one-undo-step semantics as a tool-drawn one.
  function addRectangle(s: Scene, sketch: bigint, p0: Vec3, p1: Vec3): bigint {
    const z = p0[2]
    const corners: Vec3[] = [
      [p0[0], p0[1], z],
      [p1[0], p0[1], z],
      [p1[0], p1[1], z],
      [p0[0], p1[1], z],
    ]
    s.sketch_begin_gesture(sketch)
    try {
      for (let i = 0; i < 4; i++) {
        const a = corners[i]
        const b = corners[(i + 1) % 4]
        s.sketch_add_segment(sketch, a[0], a[1], a[2], b[0], b[1], b[2])
      }
    } finally {
      s.sketch_end_gesture(sketch)
    }
    const regions = s.sketch_regions(sketch)
    if (regions.length === 0) {
      throw new Error('drawRectangle: no closed region formed')
    }
    return regions[0]
  }

  // ---- print recorder (installed into App via deps.setPrintRecorder)
  const printJobs: ReturnType<HewTestHarness['print']['jobs']> = []
  let lastPrintPages: PrintPageModel[] = []
  let lastPrintPlan: PrintPlan | null = null
  let lastPdf: { bytes: number; head: string; name: string; pages: number } | null = null
  let lastPdfBytes: Uint8Array | null = null
  const printRecorder: PrintRecorder = {
    savePdf: async (bytes, name) => {
      lastPdfBytes = bytes
      const head = String.fromCharCode(...bytes.subarray(0, 8))
      let pages = 0
      // Count page objects in the (mostly ASCII) structure.
      const text = new TextDecoder('latin1').decode(bytes)
      pages = (text.match(/\/Type \/Page[^s]/g) ?? []).length
      lastPdf = { bytes: bytes.length, head, name, pages }
      return true
    },
    host: {
      print: async (setup) => {
        printJobs.push({
          setup,
          pageCount: lastPrintPages.length,
          tiles: lastPrintPages.map((p) => p.tile.id),
          imagePx: lastPrintPages.map((p) => ({ w: p.tile.imagePx.w, h: p.tile.imagePx.h })),
          jobTitle: lastPrintPlan?.jobTitle ?? '',
          paperMm: lastPrintPlan === null ? { w: 0, h: 0 } : { w: lastPrintPlan.layout.page.paper.w, h: lastPrintPlan.layout.page.paper.h },
        })
      },
    },
    onPages: (pages, plan) => {
      lastPrintPages = pages
      lastPrintPlan = plan
    },
  }

  const harness: HewTestHarness = {
    // Ready = kernel scene live AND the viewport API wired. Both are needed
    // before callers drive the harness: drawBox/setCamera/pickFace go through the
    // viewport (setCamera throws "viewport not ready" without it). The viewport
    // registers its API a tick after the scene becomes non-null, so gating only
    // on the scene leaves a race that a slower-mounting engine (webkit) loses —
    // `waitForFunction(isReady)` then `setCamera` flaked. Gate on both.
    isReady: () => deps.getScene() !== null && deps.getViewportApi() !== null,

    drawRectangle: (p0, p1) =>
      act((s) => {
        const sketch = s.begin_ground_sketch()
        const region = addRectangle(s, sketch, p0, p1)
        return { sketch: sketch.toString(), region: region.toString() }
      }),

    extrudeRegion: (sketch, region, distance) =>
      act((s) =>
        s.extrude_region(BigInt(sketch), BigInt(region), distance).toString(),
      ),

    drawBox: (p0, p1, height) =>
      act((s) => {
        const sketch = s.begin_ground_sketch()
        const region = addRectangle(s, sketch, p0, p1)
        return s.extrude_region(sketch, region, height).toString()
      }),

    pickFace: (o, d) =>
      query((s) => {
        // FacePickJs exposes object()/face()/instance() as methods; the
        // first two return bigint always, instance() is bigint|undefined.
        // pick_face returns undefined on a miss.
        const p = s.pick_face(o[0], o[1], o[2], d[0], d[1], d[2])
        if (!p) return null
        const instance = p.instance()
        return {
          object: p.object().toString(),
          face: p.face().toString(),
          instance: instance === undefined ? null : instance.toString(),
        }
      }),

    pushPull: (object, face, distance) => {
      act((s) => s.push_pull(BigInt(object), BigInt(face), distance))
    },

    boolean: (op, a, b) =>
      act((s) => s.boolean(op, BigInt(a), BigInt(b)).toString()),

    booleanNodes: (op, a, b) =>
      act((s) => {
        const kindNum = (k: string) => (k === 'group' ? 1 : k === 'instance' ? 2 : 0)
        const node = s.boolean_nodes(op, kindNum(a.kind), BigInt(a.id), kindNum(b.kind), BigInt(b.id))
        return { kind: node.kind, id: node.id.toString() }
      }),

    groupNodes: (nodes) =>
      act((s) => {
        const kinds = new Uint8Array(
          nodes.map((n) => (n.kind === 'group' ? 1 : n.kind === 'instance' ? 2 : 0)),
        )
        const ids = new BigUint64Array(nodes.map((n) => BigInt(n.id)))
        return s.group_nodes(kinds, ids).toString()
      }),

    getGroupMembers: (id) =>
      query((s) =>
        s.group_members(BigInt(id)).map((n) => ({ kind: n.kind, id: n.id.toString() })),
      ),

    getNodeParent: (kind, id) =>
      query((s) => {
        const kindNum = kind === 'group' ? 1 : kind === 'instance' ? 2 : 0
        const parent = s.node_parent(kindNum, BigInt(id))
        return parent === undefined ? null : parent.toString()
      }),

    isObjectSolid: (id) => query((s) => s.object_solid(BigInt(id))),

    getObjectBounds: (id) =>
      query((s) => {
        const mesh = s.object_mesh(BigInt(id))
        try {
          const pos = mesh.positions()
          if (pos.length < 3) {
            throw new Error(`getObjectBounds: object ${id} has no geometry`)
          }
          let minX = pos[0], maxX = pos[0]
          let minY = pos[1], maxY = pos[1]
          let minZ = pos[2], maxZ = pos[2]
          for (let i = 3; i < pos.length; i += 3) {
            const x = pos[i], y = pos[i + 1], z = pos[i + 2]
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
            if (z < minZ) minZ = z
            if (z > maxZ) maxZ = z
          }
          return [minX, minY, minZ, maxX, maxY, maxZ]
        } finally {
          mesh.free()
        }
      }),

    copyNode: (kind, id, dx, dy, dz) => {
      const affine = new Float64Array([1, 0, 0, dx, 0, 1, 0, dy, 0, 0, 1, dz])
      const kindNum = kind === 'group' ? 1 : kind === 'instance' ? 2 : 0
      return act((s) => {
        const node = s.duplicate_node(kindNum, BigInt(id), affine)
        return { kind: node.kind, id: node.id.toString() }
      })
    },

    deleteObject: (id) => {
      act((s) => s.delete_node(0, BigInt(id))) // kind 0 = object
    },

    deleteNode: (kind, id) => {
      act((s) => s.delete_node(nodeKindToNumber(kind as NodeKind), BigInt(id)))
    },

    selectObjects: (ids) => deps.setSelectedObjects(ids.map((id) => BigInt(id))),

    selectAll: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.selectAll()
    },

    setCamera: (pose) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.setCamera(pose.position, pose.target, pose.up ?? [0, 0, 1], pose.fovDeg ?? 45)
    },

    frameStability: (poseA, poseB) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      const capture = (pose: CameraPose) => {
        api.setCamera(pose.position, pose.target, pose.up ?? [0, 0, 1], pose.fovDeg ?? 45)
        return api.captureFrame()
      }
      const a = capture(poseA)
      const b = capture(poseB)
      if (a.width !== b.width || a.height !== b.height) {
        throw new Error('__hew_test: frame size changed between captures')
      }
      let differing = 0
      let hard = 0
      for (let p = 0; p < a.pixels.length; p += 4) {
        const d = Math.max(
          Math.abs(a.pixels[p] - b.pixels[p]),
          Math.abs(a.pixels[p + 1] - b.pixels[p + 1]),
          Math.abs(a.pixels[p + 2] - b.pixels[p + 2]),
        )
        if (d > 8) differing++
        if (d > 60) hard++
      }
      return { width: a.width, height: a.height, differing, hard }
    },

    setAxesVisible: (visible) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.setAxesVisible(visible)
    },

    setGridVisible: (visible) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.setGridVisible(visible)
    },

    setGuidesVisible: (visible) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.setGuidesVisible(visible)
    },

    addScene: (name) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      const cam = api.getCameraState()
      return act((s) => s.add_scene(name, 31, JSON.stringify(cam), undefined, undefined).toString())
    },

    isTagHidden: (path) => {
      const scene = deps.getScene()
      if (scene === null) throw new Error('__hew_test: scene not ready')
      const paths = scene.tag_meta_paths()
      const hidden = scene.tag_meta_hidden()
      const key = path.join('/')
      for (let i = 0; i < paths.length; i++) {
        if (paths[i] === key) return hidden[i] === 1
      }
      return false
    },

    toggleSectionActive: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.toggleSectionActive()
    },
    getSectionState: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.getSectionState()
    },
    getSectionRenderInfo: (kind, id) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.getSectionRenderInfo(kind, BigInt(id))
    },

    replay: (json) => act((s) => s.replay(json).toString()),

    save: () => query((s) => Array.from(s.save())),
    load: (bytes) => {
      // Route through the app's real Open path, not a bare `scene.load`, so the
      // viewport re-tessellates exactly as File→Open does. `loadBytes` reports
      // failure via its boolean (it has already toasted); surface it as both a
      // lastError and a throw, matching the `act` helper's contract.
      const ok = deps.loadBytes(new Uint8Array(bytes))
      if (!ok) {
        lastError = '__hew_test: load rejected'
        throw new Error(lastError)
      }
      lastError = null
    },

    exportStl: (segmentsPerTurn) =>
      query((s) => {
        const out = s.export('stl', segmentsPerTurn)
        if (out === undefined) return null
        // Binary STL header: 80-byte text header, then a little-endian u32
        // triangle count (crates/mesh-export's `write_binary_stl`).
        const view = new DataView(out.buffer, out.byteOffset, out.byteLength)
        const triangleCount = view.getUint32(80, true)
        return { bytes: Array.from(out), triangleCount }
      }),

    importStl: (bytes, unitScale) =>
      act((s) => s.import_stl(new Uint8Array(bytes), unitScale) as StlImportReportJs),

    skpContainer: (bytes) => {
      const scene = deps.getScene()
      if (scene === null) throw new Error('skpContainer: kernel not ready')
      const SceneClass = scene.constructor as unknown as { skp_container(b: Uint8Array): string }
      return SceneClass.skp_container(new Uint8Array(bytes))
    },

    print: {
      arm: () => deps.setPrintRecorder?.(printRecorder),
      disarm: () => deps.setPrintRecorder?.(null),
      jobs: () => printJobs.map((j) => ({ ...j })),
      rowDarkSpan: async (index, threshold, rowFrac) => {
        const page = lastPrintPages[index]
        if (page === undefined || page.imageUrl === null) return null
        const img = new Image()
        img.src = page.imageUrl
        await img.decode()
        const canvas = document.createElement('canvas')
        canvas.width = img.naturalWidth
        canvas.height = img.naturalHeight
        const ctx = canvas.getContext('2d')
        if (ctx === null) return null
        ctx.drawImage(img, 0, 0)
        const y = Math.max(0, Math.min(canvas.height - 1, Math.round(rowFrac * canvas.height)))
        const { data, width } = ctx.getImageData(0, y, canvas.width, 1)
        let minX = Infinity
        let maxX = -1
        for (let x = 0; x < width; x++) {
          const i = x * 4
          if (Math.max(data[i], data[i + 1], data[i + 2]) < threshold) {
            if (x < minX) minX = x
            if (x > maxX) maxX = x
          }
        }
        canvas.width = 0
        return maxX < 0 ? null : { x: minX, w: maxX - minX + 1, imageW: width }
      },
      pageDarkBounds: async (index, threshold) => {
        const page = lastPrintPages[index]
        if (page === undefined || page.imageUrl === null) return null
        const img = new Image()
        img.src = page.imageUrl
        await img.decode()
        const canvas = document.createElement('canvas')
        canvas.width = img.naturalWidth
        canvas.height = img.naturalHeight
        const ctx = canvas.getContext('2d')
        if (ctx === null) return null
        ctx.drawImage(img, 0, 0)
        const { data, width, height } = ctx.getImageData(0, 0, canvas.width, canvas.height)
        let minX = Infinity
        let minY = Infinity
        let maxX = -1
        let maxY = -1
        for (let y = 0; y < height; y++) {
          for (let x = 0; x < width; x++) {
            const i = (y * width + x) * 4
            const m = Math.max(data[i], data[i + 1], data[i + 2])
            if (m < threshold) {
              if (x < minX) minX = x
              if (x > maxX) maxX = x
              if (y < minY) minY = y
              if (y > maxY) maxY = y
            }
          }
        }
        canvas.width = 0
        if (maxX < 0) return { x: 0, y: 0, w: 0, h: 0, imageW: width, imageH: height }
        return { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1, imageW: width, imageH: height }
      },
      printRootPages: () => document.querySelectorAll('#hew-print-root .hew-print-page').length,
      lastPdf: () => lastPdf,
      lastPdfBytes: () => (lastPdfBytes === null ? null : Array.from(lastPdfBytes)),
    },

    startRecording: () => {
      scene().start_recording()
      inputRecorder.start()
    },
    stopRecording: () => {
      scene().stop_recording()
      inputRecorder.stop()
    },
    isRecording: () => scene().is_recording(),
    takeRecording: () =>
      buildSessionRecording(scene().take_recording(), inputRecorder.take()),

    getStateHash: () => query((s) => s.state_hash().toString()),
    getObjectCount: () => query((s) => s.object_ids().length),
    getObjectIds: () => query((s) => Array.from(s.object_ids()).map(String)),
    getSelection: () =>
      deps.getSelection().map((n) => ({
        kind: n.kind,
        id: n.id.toString(),
        ...(n.ctx !== undefined ? { ctx: n.ctx } : {}),
        ...(n.key !== undefined ? { key: n.key } : {}),
      })),
    getPlaneUnits: (ctx) => query((s) => JSON.parse(s.plane_units_json(ctx))),
    ctxOfFace: (object, face, instance) =>
      query((s) => ctxOfFace(s, BigInt(object), BigInt(face), instance === undefined ? null : BigInt(instance))),
    ctxOfPlane: (point, normal) => ctxOfPlane(point, normal),
    ctxGround: () => ctxGround(),
    getImprints: (object) =>
      query((s) => imprintView(s, BigInt(object))),
    getCurveRuns: (object) =>
      query((s) => curveRunsView(s, BigInt(object))),
    getOutlinerShapeLabels: (object) =>
      query((s) => {
        const d = outlinerDrawing(s as never, Array.from(s.object_ids()))
        return (d.byObject.get(BigInt(object).toString()) ?? []).map(
          (u) => d.labels.get(`${u.ref.kind}:${u.ref.ctx}:${u.ref.key}`) ?? '',
        )
      }),
    getLastError: () => lastError,
    getDrawingAxes: () => query((s) => Array.from(s.axes())),

    getAnnotationIds: () => query((s) => Array.from(s.annotation_ids()).map(String)),
    getAnnotationKind: (id) => query((s) => s.annotation_kind(BigInt(id))),
    getAnnotationDetached: (id) => query((s) => s.annotation_detached(BigInt(id))),
    getAnnotationLabel: (id) => deps.getViewportApi()?.getAnnotationLabel(BigInt(id)) ?? null,
    getAnnotationTextWorldPosition: (id) => deps.getViewportApi()?.getAnnotationTextWorldPosition(BigInt(id)) ?? null,
    getLinearDimensionAnchors: (id) =>
      query((s) => {
        const bid = BigInt(id)
        if (s.annotation_kind(bid) !== 'linear') return null
        const a = s.annotation_anchor_point(bid, 0)
        const b = s.annotation_anchor_point(bid, 1)
        if (a === undefined || b === undefined) return null
        return { a: [a[0], a[1], a[2]] as Vec3, b: [b[0], b[1], b[2]] as Vec3 }
      }),
    getLinearDimensionEndpoints: (id) =>
      query((s) => {
        const bid = BigInt(id)
        if (s.annotation_kind(bid) !== 'linear') return null
        const a = s.annotation_anchor_point(bid, 0)
        const b = s.annotation_anchor_point(bid, 1)
        const offset = s.annotation_offset(bid)
        if (a === undefined || b === undefined || offset === undefined) return null
        return {
          a1: [a[0] + offset[0], a[1] + offset[1], a[2] + offset[2]],
          b1: [b[0] + offset[0], b[1] + offset[1], b[2] + offset[2]],
        }
      }),

    // -------- NEW in  --------

    drawLineChain: (points) =>
      act((s) => {
        if (points.length < 2) throw new Error('drawLineChain: need at least 2 points')
        const sketch = s.begin_ground_sketch()
        const regionsAll = new Set<bigint>()
        s.sketch_begin_gesture(sketch)
        try {
          for (let i = 0; i < points.length - 1; i++) {
            const a = points[i]
            const b = points[i + 1]
            const added = s.sketch_add_segment(sketch, a[0], a[1], a[2], b[0], b[1], b[2])
            for (const r of added.regions_created()) regionsAll.add(r)
          }
        } finally {
          s.sketch_end_gesture(sketch)
        }
        return {
          sketch: sketch.toString(),
          regions: Array.from(regionsAll).map(String),
        }
      }),

    drawCircle: (center, radius, nSegments = 24) =>
      act((s) => {
        if (radius <= 0) throw new Error('drawCircle: radius must be positive')
        const sketch = s.begin_ground_sketch()
        const pts: Vec3[] = []
        for (let i = 0; i < nSegments; i++) {
          const theta = (2 * Math.PI * i) / nSegments
          pts.push([center[0] + radius * Math.cos(theta), center[1] + radius * Math.sin(theta), center[2]])
        }
        let lastRegion: bigint | null = null
        s.sketch_begin_gesture(sketch)
        try {
          // One curve chain carrying the analytic circle, exactly as
          // CircleTool commits (the true-curves design).
          s.sketch_begin_curve_with(sketch, center[0], center[1], center[2], radius)
          for (let i = 0; i < nSegments; i++) {
            const a = pts[i]
            const b = pts[(i + 1) % nSegments]
            const added = s.sketch_add_segment(sketch, a[0], a[1], a[2], b[0], b[1], b[2])
            for (const r of added.regions_created()) lastRegion = r
          }
          s.sketch_end_curve(sketch)
        } finally {
          s.sketch_end_gesture(sketch)
        }
        if (lastRegion === null) {
          // Fallback: ask the scene for any open regions
          const regions = s.sketch_regions(sketch)
          lastRegion = regions.length > 0 ? regions[0] : null
        }
        if (lastRegion === null) throw new Error('drawCircle: no region formed')
        return { sketch: sketch.toString(), region: lastRegion.toString() }
      }),

    imprintCircleOnFace: (object, face, center, radius, nSegments = 24) =>
      act((s) => {
        if (radius <= 0) throw new Error('imprintCircleOnFace: radius must be positive')
        const nrm = s.face_normal(BigInt(object), BigInt(face))
        const normal: V3 = [nrm[0], nrm[1], nrm[2]]
        const basis = facePlaneBasis(normal)
        if (basis === null) throw new Error('imprintCircleOnFace: degenerate face normal')
        const { u, v } = basis
        const loop = new Float64Array(nSegments * 3)
        for (let i = 0; i < nSegments; i++) {
          const theta = (2 * Math.PI * i) / nSegments
          const cs = Math.cos(theta) * radius
          const sn = Math.sin(theta) * radius
          loop[i * 3 + 0] = center[0] + u[0] * cs + v[0] * sn
          loop[i * 3 + 1] = center[1] + u[1] * cs + v[1] * sn
          loop[i * 3 + 2] = center[2] + u[2] * cs + v[2] * sn
        }
        const verts: V3[] = []
        for (let i = 0; i < nSegments; i++) verts.push([loop[i * 3], loop[i * 3 + 1], loop[i * 3 + 2]])
        runDraft(s, { kind: 'face', object: BigInt(object), face: BigInt(face), instance: null }, 'Circle', (d) => {
          addDraftLoop(s, d, verts, { kind: 'circle', center, radius })
        })
        const ctx = ctxOfFace(s, BigInt(object), BigInt(face), null)
        const disk = ctx === null ? null : faceRegionAt(s, ctx, center)
        if (disk === null || disk.over === null || disk.over.face === null) throw new Error('imprintCircleOnFace: no disk face formed')
        return disk.over.face.toString()
      }),

    offsetRegion: (sketch, region, distance) =>
      act((s) => {
        const sid = BigInt(sketch)
        const rid = BigInt(region)
        const ctx = ctxOfSketch(s, sid, null)
        if (ctx === null) throw new Error('UnknownSketch: no such sketch')
        const pu = readPlaneUnits(s as unknown as PlaneUnitsScene, ctx)
        const entry = pu?.regions.find((r) => r.extrude !== null && r.extrude.sketch === sid && r.extrude.region === rid)
        if (entry === undefined) throw new Error('UnknownRegion: that region is not in its sketch')
        const before = new Set(Array.from(s.sketch_regions(sid), String))
        runDraft(s, { kind: 'ctx', ctx }, 'Offset', (d) => {
          s.draft_offset_region(d, keyToId(entry.key), distance)
        })
        return Array.from(s.sketch_regions(sid), String).filter((r) => !before.has(r))
      }),

    offsetFace: (object, face, distance) =>
      act((s) => {
        const oid = BigInt(object)
        const fid = BigInt(face)
        const ctx = ctxOfFace(s, oid, fid, null)
        if (ctx === null) throw new Error('UnknownFace: no such face')
        const pu = readPlaneUnits(s as unknown as PlaneUnitsScene, ctx)
        const entry = pu?.regions.find((r) => r.over !== null && r.over.object === oid && r.over.face === fid)
        if (entry === undefined) throw new Error('UnknownFace: that face is not in its plane listing')
        const c = entry.outer.reduce<V3>((a, p) => [a[0] + p[0] / entry.outer.length, a[1] + p[1] / entry.outer.length, a[2] + p[2] / entry.outer.length], [0, 0, 0])
        runDraft(s, { kind: 'ctx', ctx }, 'Offset', (d) => {
          s.draft_offset_region(d, keyToId(entry.key), distance)
        })
        const sub = faceRegionAt(s, ctx, c)
        if (sub === null || sub.over === null || sub.over.face === null) throw new Error('offsetFace: no sub-face formed')
        return sub.over.face.toString()
      }),

    drawArc: (a, b, sagitta, close = false) =>
      act((s) => {
        const pts = arcPolylineOnPlane(a, b, sagitta, [1, 0, 0], [0, 1, 0])
        if (pts === null) throw new Error('drawArc: degenerate chord or flat sagitta')
        const arc = arcFromChord([a[0], a[1]], [b[0], b[1]], sagitta)
        const sketch = s.begin_ground_sketch()
        const regionsAll = new Set<bigint>()
        const addSeg = (p: V3, q: V3): void => {
          const added = s.sketch_add_segment(sketch, p[0], p[1], p[2], q[0], q[1], q[2])
          for (const r of added.regions_created()) regionsAll.add(r)
        }
        // The arc's facets are one curve chain carrying the analytic circle,
        // exactly as ArcTool commits; the closing chord stays a plain line.
        if (arc !== null) {
          s.sketch_begin_curve_with(sketch, arc.center[0], arc.center[1], 0, arc.radius)
        }
        for (let i = 0; i < pts.length - 1; i++) addSeg(pts[i], pts[i + 1])
        s.sketch_end_curve(sketch)
        if (close) addSeg(pts[pts.length - 1], pts[0])
        return {
          sketch: sketch.toString(),
          regions: Array.from(regionsAll).map(String),
        }
      }),

    drawArcOnFace: (object, face, a, b, sagitta) => {
      act((s) => {
        const objId = BigInt(object)
        const faceId = BigInt(face)
        const n = s.face_normal(objId, faceId)
        const basis = facePlaneBasis([n[0], n[1], n[2]])
        if (basis === null) throw new Error('drawArcOnFace: degenerate face normal')
        const pts = arcPolylineOnPlane(a, b, sagitta, basis.u, basis.v)
        if (pts === null) throw new Error('drawArcOnFace: degenerate chord or flat sagitta')
        runDraft(s, { kind: 'face', object: objId, face: faceId, instance: null }, 'Arc', (d) => {
          for (let i = 0; i < pts.length - 1; i++) addDraftSegment(s, d, pts[i], pts[i + 1])
        })
      })
    },

    moveObject: (object, dx, dy, dz) => {
      // Pure-translation 3×4 row-major affine: identity rotation + (dx,dy,dz) column.
      const affine = new Float64Array([1, 0, 0, dx, 0, 1, 0, dy, 0, 0, 1, dz])
      act((s) => s.transform_object(BigInt(object), affine))
    },

    copyObject: (id, dx, dy, dz) => {
      const affine = new Float64Array([1, 0, 0, dx, 0, 1, 0, dy, 0, 0, 1, dz])
      return act((s) => {
        const node = s.duplicate_node(0, BigInt(id), affine)
        return { kind: node.kind, id: node.id.toString() }
      })
    },

    rotateObject: (object, angleDeg, axis = [0, 0, 1]) => {
      // Rodrigues rotation matrix around a normalized axis by angleDeg degrees.
      const [ux, uy, uz] = axis
      const len = Math.hypot(ux, uy, uz)
      if (len < 1e-12) throw new Error('rotateObject: axis must be non-zero')
      const ax = ux / len, ay = uy / len, az = uz / len
      const theta = (angleDeg * Math.PI) / 180
      const c = Math.cos(theta), s_ = Math.sin(theta), t = 1 - c
      // Row-major 3×4 affine; translation column is zero.
      const affine = new Float64Array([
        t * ax * ax + c,       t * ax * ay - s_ * az, t * ax * az + s_ * ay, 0,
        t * ay * ax + s_ * az, t * ay * ay + c,       t * ay * az - s_ * ax, 0,
        t * az * ax - s_ * ay, t * az * ay + s_ * ax, t * az * az + c,       0,
      ])
      act((s) => s.transform_object(BigInt(object), affine))
    },

    scaleObject: (object, sx, sy, sz, pivot) => {
      // diag(sx,sy,sz) about `pivot`: translation = pivot componentwise
      // (1 - s) — matches `nonUniformScaleAboutPivot` in tools/transformMath.ts.
      const [px, py, pz] = pivot
      const affine = new Float64Array([
        sx, 0, 0, px * (1 - sx),
        0, sy, 0, py * (1 - sy),
        0, 0, sz, pz * (1 - sz),
      ])
      act((s) => s.transform_object(BigInt(object), affine))
    },

    sliceObject: (object, plane) =>
      act((s) => {
        const ids = s.slice_object(BigInt(object), new Float64Array(plane))
        return [ids[0].toString(), ids[1].toString()] as [string, string]
      }),

    addLinearDimension: (aPoint, bPoint, offset, plane) =>
      act((s) =>
        s
          .add_linear_dimension(
            -1, 0n, new Float64Array(aPoint),
            -1, 0n, new Float64Array(bPoint),
            new Float64Array(offset),
            new Float64Array(plane),
            undefined,
          )
          .toString(),
      ),

    addRadialDimension: (anchor, kind, center, radius, curvePlane, leaderDir) =>
      act((s) =>
        s
          .add_radial_dimension(
            -1, 0n, new Float64Array(anchor),
            kind,
            new Float64Array(center),
            radius,
            new Float64Array(curvePlane),
            new Float64Array(leaderDir),
            undefined,
          )
          .toString(),
      ),

    addGuideLine: (ox, oy, oz, dx, dy, dz) =>
      act((s) => s.add_guide_line(ox, oy, oz, dx, dy, dz).toString()),

    addGuidePoint: (x, y, z) =>
      act((s) => s.add_guide_point(x, y, z).toString()),

    deleteGuide: (id) => {
      act((s) => s.delete_guide(BigInt(id)))
    },

    deleteAllGuides: () => {
      act((s) => s.delete_all_guides())
    },

    getGuideIds: () => query((s) => Array.from(s.guide_ids()).map(String)),

    getGuideKind: (id) => query((s) => s.guide_kind(BigInt(id))),

    getGuideGeometry: (id) =>
      query((s) => {
        const g = s.guide_geometry(BigInt(id))
        return g !== undefined ? Array.from(g) : undefined
      }),

    // Undo/redo route through the viewport's runUndo/runRedo — the shared
    // choke point that fires post-history reconciliation (onHistoryChanged →
    // tag visibility + pick/inference exclusion) — so a harness-driven undo
    // behaves exactly like the menu, palette, and keyboard paths. runUndo is
    // deliberately a silent no-op when there is nothing to undo, so the
    // harness's documented throw-on-nothing contract is checked up front.
    // Headless callers (no viewport) fall back to the bare kernel call.
    undo: () => {
      const api = deps.getViewportApi()
      if (api === null) {
        act((s) => s.scene_undo().free())
        return
      }
      if (!scene().can_scene_undo()) throw new Error('__hew_test: nothing to undo')
      api.runUndo()
    },

    redo: () => {
      const api = deps.getViewportApi()
      if (api === null) {
        act((s) => s.scene_redo().free())
        return
      }
      if (!scene().can_scene_redo()) throw new Error('__hew_test: nothing to redo')
      api.runRedo()
    },

    canUndo: () => query((s) => s.can_scene_undo()),
    canRedo: () => query((s) => s.can_scene_redo()),

    setLengthUnit: (format) => setLengthUnit(format as LengthFormat),
    getLengthUnit: () => getLengthUnit(),
    formatLength: (meters) => formatLength(meters),
    parseLength: (input) => parseLengthToMeters(input),

    // -------- materials --------

    addMaterial: (name, r, g, b, a) =>
      act((s) => s.add_material(name, r, g, b, a).toString()),

    renameMaterial: (material, name) => {
      act((s) => s.set_material_name(BigInt(material), name))
    },

    deleteMaterial: (material) => {
      act((s) => s.delete_material(BigInt(material)))
    },

    materialUsage: (material) => query((s) => s.material_usage(BigInt(material))),

    unusedMaterials: () => query((s) => Array.from(s.unused_materials()).map((id) => id.toString())),

    paintObject: (object, material) => {
      act((s) => s.set_object_material(BigInt(object), materialHandle(material)))
    },

    paintFace: (object, face, material) => {
      act((s) => s.paint_face(BigInt(object), BigInt(face), materialHandle(material)))
    },

    getFaceMaterial: (object, face) =>
      query((s) => {
        const info = s.face_material(BigInt(object), BigInt(face))
        if (info === undefined) return null
        try {
          const own = info.face()
          const base = info.object_default()
          return {
            face: own === MATERIAL_NONE ? null : own.toString(),
            objectDefault: base === MATERIAL_NONE ? null : base.toString(),
          }
        } finally {
          info.free()
        }
      }),

    replaceMaterial: (documentWide, scopeObject, from, to) => {
      act((s) =>
        s.replace_material(
          documentWide,
          scopeObject === null ? MATERIAL_NONE : BigInt(scopeObject),
          materialHandle(from),
          materialHandle(to),
        ),
      )
    },

    addTextureMaterial: (name, r, g, b, a, image, format, worldW, worldH) =>
      act((s) =>
        s
          .add_texture_material(name, r, g, b, a, new Uint8Array(image), format, worldW, worldH)
          .toString(),
      ),

    getFaceUvFrame: (object, face) =>
      query((s) => {
        const frame = s.face_uv_frame(BigInt(object), BigInt(face))
        return frame === undefined ? null : Array.from(frame)
      }),

    setFaceUvFrame: (object, face, frame) => {
      act((s) =>
        s.set_face_uv_frame(BigInt(object), BigInt(face), frame === null ? undefined : new Float64Array(frame)),
      )
    },

    // -------- follow me --------

    rotateSketch: (sketch, angleDeg, axis, origin) => {
      // Rodrigues rotation about `axis` through `origin`:
      // affine = T(origin) · R · T(−origin), i.e. translation = origin − R·origin.
      const [ux, uy, uz] = axis
      const len = Math.hypot(ux, uy, uz)
      if (len < 1e-12) throw new Error('rotateSketch: axis must be non-zero')
      const ax = ux / len, ay = uy / len, az = uz / len
      const theta = (angleDeg * Math.PI) / 180
      const c = Math.cos(theta), s_ = Math.sin(theta), t = 1 - c
      const r = [
        t * ax * ax + c,       t * ax * ay - s_ * az, t * ax * az + s_ * ay,
        t * ay * ax + s_ * az, t * ay * ay + c,       t * ay * az - s_ * ax,
        t * az * ax - s_ * ay, t * az * ay + s_ * ax, t * az * az + c,
      ]
      const [px, py, pz] = origin
      const tx = px - (r[0] * px + r[1] * py + r[2] * pz)
      const ty = py - (r[3] * px + r[4] * py + r[5] * pz)
      const tz = pz - (r[6] * px + r[7] * py + r[8] * pz)
      const affine = new Float64Array([
        r[0], r[1], r[2], tx,
        r[3], r[4], r[5], ty,
        r[6], r[7], r[8], tz,
      ])
      act((s) => s.transform_sketch(BigInt(sketch), affine))
    },

    getSketchIds: () => query((s) => Array.from(s.sketch_ids(), (id) => id.toString())),

    getSketchLines: (sketch) => query((s) => Array.from(s.sketch_lines(BigInt(sketch)))),
    getSketchPlane: (sketch) =>
      query((s) => {
        const p = s.sketch_plane(BigInt(sketch))
        return p === undefined ? null : Array.from(p)
      }),

    getSketchEdgeIds: (sketch) =>
      query((s) => {
        const out: string[] = []
        for (const island of s.sketch_island_ids(BigInt(sketch))) {
          for (const edge of s.sketch_island_edges(BigInt(sketch), island)) {
            out.push(edge.toString())
          }
        }
        return out
      }),

    getSketchSegmentsExact: (sketch) =>
      query((s) => {
        const out: number[][] = []
        for (const island of s.sketch_island_ids(BigInt(sketch))) {
          for (const edge of s.sketch_island_edges(BigInt(sketch), island)) {
            const e = s.sketch_edge_endpoints(BigInt(sketch), edge)
            if (e !== undefined) out.push(Array.from(e))
          }
        }
        return out
      }),

    getSketchIslands: (sketch) =>
      query((s) =>
        Array.from(s.sketch_island_ids(BigInt(sketch)), (island) => ({
          island: island.toString(),
          edges: Array.from(s.sketch_island_edges(BigInt(sketch), island), (e) => e.toString()),
        })),
      ),

    getSketchRegionCount: (sketch) => query((s) => s.sketch_regions(BigInt(sketch)).length),

    getSketchRegionIds: (sketch) => query((s) => Array.from(s.sketch_regions(BigInt(sketch)), String)),

    followMeAlongEdges: (sketch, region, pathSketch, edges, group, stopLen) =>
      act((s) =>
        s
          .follow_me_along_edges(
            BigInt(sketch),
            BigInt(region),
            BigInt(pathSketch),
            new BigUint64Array(edges.map((e) => BigInt(e))),
            stopLen,
            group === undefined ? undefined : BigInt(group),
          )
          .toString(),
      ),

    followMeAroundFace: (sketch, region, object, face, group) =>
      act((s) =>
        s
          .follow_me_around_face(
            BigInt(sketch),
            BigInt(region),
            BigInt(object),
            BigInt(face),
            undefined,
            group === undefined ? undefined : BigInt(group),
          )
          .toString(),
      ),

    followMeAroundInstanceFace: (sketch, region, instance, pathObject, pathFace) =>
      act((s) =>
        s
          .follow_me_around_instance_face(
            BigInt(sketch),
            BigInt(region),
            BigInt(instance),
            BigInt(pathObject),
            BigInt(pathFace),
          )
          .toString(),
      ),

    followMeMergedAroundFace: (sketch, region, pathObject, pathFace) =>
      act((s) =>
        s
          .follow_me_merged_around_face(BigInt(sketch), BigInt(region), BigInt(pathObject), BigInt(pathFace))
          .toString(),
      ),

    followMeFaceAlongEdges: (profileObject, profileFace, pathSketch, edges) =>
      act((s) =>
        s
          .follow_me_face_along_edges(
            BigInt(profileObject),
            BigInt(profileFace),
            BigInt(pathSketch),
            new BigUint64Array(edges.map((e) => BigInt(e))),
          )
          .toString(),
      ),

    followMeFaceAroundFace: (profileObject, profileFace, pathObject, pathFace) =>
      act((s) =>
        s
          .follow_me_face_around_face(
            BigInt(profileObject),
            BigInt(profileFace),
            BigInt(pathObject),
            BigInt(pathFace),
          )
          .toString(),
      ),

    // -------- components --------

    copyInstance: (id, dx, dy, dz) => {
      const affine = new Float64Array([1, 0, 0, dx, 0, 1, 0, dy, 0, 0, 1, dz])
      return act((s) => s.duplicate_node(2, BigInt(id), affine).id.toString())
    },

    makeUnique: (instance) =>
      act((s) => s.make_unique(BigInt(instance)).toString()),

    setNodeName: (kind, id, name) => {
      act((s) => s.set_node_name(kindNum(kind), BigInt(id), name ?? undefined))
    },

    getNodeName: (kind, id) =>
      query((s) => {
        const i = BigInt(id)
        const name =
          kind === 'object' ? s.object_name(i) :
          kind === 'group' ? s.group_name(i) :
          s.instance_name(i)
        return name ?? null
      }),

    addNodeTag: (kind, id, path) => {
      act((s) => s.add_node_tag(kindNum(kind), BigInt(id), path))
      deps.reconcileVisibility?.()
    },

    getNodeTags: (kind, id) =>
      query((s) => Array.from(s.node_tags(kindNum(kind), BigInt(id)))),

    setComponentName: (component, name) => {
      act((s) => s.set_component_name(BigInt(component), name ?? undefined))
    },

    getComponentName: (component) =>
      query((s) => s.component_name(BigInt(component)) ?? null),

    getInstanceDef: (instance) =>
      query((s) => s.instance_def(BigInt(instance))?.toString() ?? null),

    getInstancesOf: (component) =>
      query((s) => Array.from(s.instances_of(BigInt(component))).map(String)),

    getExplodeSessionInstance: () =>
      query((s) => {
        const i = s.explode_session_instance()
        return i === undefined ? null : String(i)
      }),

    getComponentMemberObjects: (component) =>
      query((s) => Array.from(s.component_member_objects(BigInt(component))).map(String)),

    getComponentMemberSketches: (component) =>
      query((s) => Array.from(s.component_member_sketches(BigInt(component))).map(String)),

    selectNodes: (nodes) =>
      deps.setSelection(
        nodes.map((n) => ({
          kind: n.kind as NodeKind,
          id: n.key !== undefined ? BigInt('0x' + n.key) : BigInt(n.id),
          ...(n.ctx !== undefined ? { ctx: n.ctx } : {}),
          ...(n.key !== undefined ? { key: n.key } : {}),
        })),
      ),

    // -------- tags --------

    toggleTagHidden: (path) => deps.toggleTagPath(path),

    deleteTag: (path) => deps.deleteTag(path),

    // -------- outliner (Lane D) --------

    toggleNodeHidden: (node) =>
      deps.toggleNodeHidden({ kind: node.kind as NodeKind, id: BigInt(node.id) }),

    isNodeHidden: (node) =>
      deps.isNodeHidden({ kind: node.kind as NodeKind, id: BigInt(node.id) }),

    setOutlinerFilter: (text) => {
      const input = document.querySelector<HTMLInputElement>('input[aria-label="Filter outliner"]')
      if (input === null) throw new Error('__hew_test: outliner filter input not mounted')
      // React tracks the DOM input's value through its own instrumented
      // setter, so a plain `input.value = text` assignment is invisible to
      // its onChange — go through the native HTMLInputElement setter
      // (bypassing React's override) and THEN dispatch a real `input`
      // event, exactly as a keystroke would.
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set
      setter?.call(input, text)
      input.dispatchEvent(new Event('input', { bubbles: true }))
    },

    // -------- components & instances --------

    makeComponent: (objectIds) =>
      act((s) => {
        const kinds = new Uint8Array(objectIds.length) // all zeros = object
        const ids = new BigUint64Array(objectIds.map((id) => BigInt(id)))
        const instance = s.make_component(kinds, ids)
        const component = s.instance_def(instance)
        if (component === undefined) throw new Error('makeComponent: instance has no definition')
        return { instance: instance.toString(), component: component.toString() }
      }),

    placeInstance: (component, dx, dy, dz) =>
      act((s) => {
        const affine = new Float64Array([1, 0, 0, dx, 0, 1, 0, dy, 0, 0, 1, dz])
        return s.place_instance(BigInt(component), affine).toString()
      }),

    getComponentIds: () => query((s) => Array.from(s.component_ids()).map((id) => id.toString())),

    renameComponent: (component, name) => {
      act((s) => s.set_component_name(BigInt(component), name))
    },

    deleteDefinition: (component) => {
      act((s) => s.delete_definition(BigInt(component)))
    },

    definitionUsage: (component) => query((s) => s.definition_usage(BigInt(component))),

    unusedDefinitions: () => query((s) => Array.from(s.unused_definitions()).map((id) => id.toString())),

    purgeUnused: () =>
      act((s) => {
        const report = s.purge_unused()
        return { materials: report.materials(), definitions: report.definitions() }
      }),

    // -------- camera --------

    frameCount: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.frameCount()
    },

    zoomExtents: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      api.zoomExtents()
    },

    getCamera: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.getCamera()
    },

    getCameraState: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.getCameraState()
    },

    getFlyState: () => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.getFlyState()
    },

    saveWithCameraState: () =>
      act((s) => {
        const api = deps.getViewportApi()
        if (api === null) throw new Error('__hew_test: viewport not ready')
        const state = api.getCameraState()
        s.set_camera_state(
          state.projection,
          state.fovDeg,
          state.parallelHeight,
          new Float64Array(state.eye),
          new Float64Array(state.target),
          new Float64Array(state.up),
        )
        const bytes = Array.from(s.save())
        // Mirrors App's real save flow marking the document clean once its
        // write lands (Lane C) — see this method's own doc comment. `act`
        // (not `query`) so the reconcile that follows recomputes
        // `docSession.dirty` from the fresh saved mark right away.
        s.mark_saved()
        return bytes
      }),

    worldToScreen: (world) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      return api.worldToScreen(world)
    },

    isolate: (targets) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      const parsed: IsolationTarget[] = targets.map((t) =>
        t.kind === 'member'
          ? { kind: 'member', object: BigInt((t as { object: string }).object), instance: BigInt((t as { instance: string }).instance) }
          : { kind: (t as { kind: string }).kind as NodeKind, id: BigInt((t as { id: string }).id) },
      )
      return deps.isolate(parsed)
    },

    clearIsolation: () => deps.clearIsolation(),

    getIsolation: () => {
      const api = deps.getViewportApi()
      const targets = api?.getIsolation() ?? null
      if (api === null || targets === null) return null
      const hidden = api.getEffectiveHiddenIds()
      return {
        targets: targets.map((t) =>
          t.kind === 'member'
            ? { kind: 'member' as const, object: t.object.toString(), instance: t.instance.toString() }
            : { kind: t.kind, id: t.id.toString() },
        ),
        hiddenObjects: hidden.objects.map(String),
        hiddenInstances: hidden.instances.map(String),
      }
    },

    pixelColorAt: (world) => {
      const api = deps.getViewportApi()
      if (api === null) throw new Error('__hew_test: viewport not ready')
      // Render BEFORE projecting: `setCamera` sets position/target/fov but
      // (like three.js generally) leaves `camera.matrixWorld` /
      // `matrixWorldInverse` stale until the next actual render traversal
      // recomputes them — `worldToScreen` (`Vector3.project`) reads that
      // cached inverse, so calling it right after `setCamera` with no
      // intervening render (the normal rAF loop always provides one before
      // real input lands, but a synchronous test script does not) silently
      // projects through the PREVIOUS camera pose. `captureFrame` renders,
      // which refreshes the camera matrices as a side effect; projecting
      // after it is what makes this method correct standalone.
      const frame = api.captureFrame()
      const proj = api.worldToScreen(world)
      if (proj.behind) return null
      // proj.x/y are CSS pixels; the buffer is device pixels. Scale by the
      // renderer's actual pixel ratio (buffer over CSS size) rather than
      // devicePixelRatio, which the software-GL profile caps. floor, not
      // round: pixel index i covers [i, i+1) — floor is the standard
      // coordinate-to-index conversion (round would bias half a pixel off).
      const sx = frame.cssWidth > 0 ? frame.width / frame.cssWidth : 1
      const sy = frame.cssHeight > 0 ? frame.height / frame.cssHeight : 1
      const x = Math.floor(proj.x * sx)
      // WebGL readPixels is bottom-left-origin; worldToScreen is top-left
      // (CSS/DOM convention) — flip here so callers stay in screen space.
      const y = frame.height - 1 - Math.floor(proj.y * sy)
      if (x < 0 || y < 0 || x >= frame.width || y >= frame.height) return null
      const idx = (y * frame.width + x) * 4
      return { r: frame.pixels[idx], g: frame.pixels[idx + 1], b: frame.pixels[idx + 2] }
    },
  }

  window.__hew_test = harness
  return () => {
    if (window.__hew_test === harness) delete window.__hew_test
  }
}

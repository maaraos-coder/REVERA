/**
 * Component tests for CommandPalette.
 *
 * jsdom provides a real localStorage, so palette/recency.ts needs no mocking
 * here (unlike its own recency.test.ts, which runs under the 'node' env).
 */
import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { CommandPalette } from './CommandPalette'
import { clearRecent, recordRun } from './recency'
import { paletteEntries } from './registry'

beforeEach(() => {
  clearRecent()
})

describe('CommandPalette', () => {
  it('renders nothing when closed', () => {
    const { container } = render(<CommandPalette open={false} onClose={vi.fn()} onRun={vi.fn()} />)
    expect(container.firstChild).toBeNull()
  })

  it('renders the search dialog when open', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    expect(screen.getByRole('dialog', { name: /command palette/i })).toBeInTheDocument()
    expect(screen.getByPlaceholderText(/search tools, actions, help/i)).toBeInTheDocument()
  })

  it('shows tool results grouped under "Tools" by default (empty query)', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    expect(screen.getByText('Tools')).toBeInTheDocument()
    expect(screen.getByText('Select')).toBeInTheDocument()
  })

  it('typing narrows the results to matches', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'rotate' } })
    expect(screen.getByText('Rotate')).toBeInTheDocument()
    expect(screen.queryByText('Select')).not.toBeInTheDocument()
  })

  it('opens pre-filled when initialQuery is set (Help > Search handoff)', () => {
    const { rerender } = render(
      <CommandPalette open={false} onClose={vi.fn()} onRun={vi.fn()} initialQuery="rotate" />,
    )
    rerender(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} initialQuery="rotate" />)
    expect(screen.getByPlaceholderText(/search tools, actions, help/i)).toHaveValue('rotate')
    expect(screen.getByText('Rotate')).toBeInTheDocument()
    expect(screen.queryByText('Select')).not.toBeInTheDocument()
  })

  it('a later open with an empty initialQuery resets to the clean slate', () => {
    const { rerender } = render(
      <CommandPalette open={false} onClose={vi.fn()} onRun={vi.fn()} initialQuery="rotate" />,
    )
    rerender(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} initialQuery="rotate" />)
    rerender(<CommandPalette open={false} onClose={vi.fn()} onRun={vi.fn()} initialQuery="" />)
    rerender(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} initialQuery="" />)
    expect(screen.getByPlaceholderText(/search tools, actions, help/i)).toHaveValue('')
  })

  it('shows a "no matches" message for a query that matches nothing', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'zzz-nope' } })
    expect(screen.getByText(/no matches/i)).toBeInTheDocument()
  })

  it('searches dynamic Model entries alongside static ones and runs their jump id', () => {
    const onRun = vi.fn()
    const extraEntries = [
      {
        id: 'jump-tag:["Projector"]',
        label: 'Tag: Projector',
        description: 'Reveal this tag in the Tags panel.',
        group: 'Model' as const,
        synonyms: ['Projector'],
      },
      {
        id: 'jump-node:instance:7',
        label: 'Component: Panasonic Projector',
        description: 'Select it and reveal it in the Outliner.',
        group: 'Model' as const,
        synonyms: ['Panasonic Projector'],
      },
    ]
    render(<CommandPalette open onClose={vi.fn()} onRun={onRun} extraEntries={extraEntries} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'pr' } })
    // Static tool still matches ("pr" → Protractor) AND both Model entries do.
    expect(screen.getByText('Protractor')).toBeInTheDocument()
    expect(screen.getByText('Model')).toBeInTheDocument()
    expect(screen.getByText('Tag: Projector')).toBeInTheDocument()
    expect(screen.getByText('Component: Panasonic Projector')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Tag: Projector'))
    expect(onRun).toHaveBeenCalledWith('jump-tag:["Projector"]')
  })

  it('Escape calls onClose', () => {
    const onClose = vi.fn()
    render(<CommandPalette open onClose={onClose} onRun={vi.fn()} />)
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' })
    expect(onClose).toHaveBeenCalledOnce()
  })

  it('stops Escape from bubbling to window (so it does not also fire the Viewport handler)', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    const windowKeyDown = vi.fn()
    window.addEventListener('keydown', windowKeyDown)
    try {
      fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' })
      expect(windowKeyDown).not.toHaveBeenCalled()
    } finally {
      window.removeEventListener('keydown', windowKeyDown)
    }
  })

  it('Enter runs the first (auto-selected) result and closes', () => {
    const onClose = vi.fn()
    const onRun = vi.fn()
    render(<CommandPalette open onClose={onClose} onRun={onRun} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'rotate' } })
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Enter' })
    expect(onRun).toHaveBeenCalledWith('tool-rotate')
    expect(onClose).toHaveBeenCalledOnce()
  })

  it('ArrowDown moves the selection before Enter runs it', () => {
    const onRun = vi.fn()
    render(<CommandPalette open onClose={vi.fn()} onRun={onRun} />)
    // Empty-query order starts with the default suggestions: Select, Push/Pull, Save, Undo.
    const dialog = screen.getByRole('dialog')
    fireEvent.keyDown(dialog, { key: 'ArrowDown' })
    fireEvent.keyDown(dialog, { key: 'Enter' })
    expect(onRun).toHaveBeenCalledWith('tool-pushpull')
  })

  it('clicking a result runs it and closes', () => {
    const onClose = vi.fn()
    const onRun = vi.fn()
    render(<CommandPalette open onClose={onClose} onRun={onRun} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'rotate' } })
    fireEvent.click(screen.getByText('Rotate'))
    expect(onRun).toHaveBeenCalledWith('tool-rotate')
    expect(onClose).toHaveBeenCalledOnce()
  })

  it('clicking the backdrop calls onClose', () => {
    const onClose = vi.fn()
    render(<CommandPalette open onClose={onClose} onRun={vi.fn()} />)
    fireEvent.mouseDown(screen.getByRole('dialog').parentElement!)
    expect(onClose).toHaveBeenCalledOnce()
  })

  it('resets the query when reopened', () => {
    const { rerender } = render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'rotate' } })
    rerender(<CommandPalette open={false} onClose={vi.fn()} onRun={vi.fn()} />)
    rerender(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    expect(screen.getByPlaceholderText(/search tools, actions, help/i)).toHaveValue('')
  })

  it('hover only selects once the pointer has actually moved', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    const rows = screen.getAllByRole('option')
    expect(rows[0]).toHaveAttribute('aria-selected', 'true')
    // A re-fired mouseenter under a still pointer must not steal the selection.
    fireEvent.mouseEnter(rows[2])
    expect(rows[0]).toHaveAttribute('aria-selected', 'true')
    // A real move does.
    fireEvent.mouseMove(rows[2], { clientX: 10, clientY: 20 })
    expect(rows[2]).toHaveAttribute('aria-selected', 'true')
    // The same position again (layout shifted a row under it) does not.
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'ArrowUp' })
    expect(rows[1]).toHaveAttribute('aria-selected', 'true')
    fireEvent.mouseMove(rows[2], { clientX: 10, clientY: 20 })
    expect(rows[1]).toHaveAttribute('aria-selected', 'true')
  })

  it('keeps focus in the search field when dead space in the dialog is pressed', () => {
    render(<CommandPalette open onClose={vi.fn()} onRun={vi.fn()} />)
    const dialog = screen.getByRole('dialog')
    // fireEvent returns false when the event's default was prevented.
    expect(fireEvent.mouseDown(dialog)).toBe(false)
    expect(fireEvent.mouseDown(screen.getByPlaceholderText(/search tools, actions, help/i))).toBe(true)
  })

  it('Enter runs the highlighted row even when a recent Action outranks the Tools drawn above it', () => {
    // A recent run lifts "Parallel Projection" (an Action, drawn under Tools)
    // to the top of the ranking, so ranked order != on-screen order.
    recordRun('toggle-parallel-projection')
    const onRun = vi.fn()
    render(<CommandPalette open onClose={vi.fn()} onRun={onRun} />)
    fireEvent.change(screen.getByPlaceholderText(/search tools, actions, help/i), { target: { value: 'para' } })
    const dialog = screen.getByRole('dialog')
    const count = screen.getAllByRole('option').length
    expect(count).toBeGreaterThan(2)
    for (let i = 0; i < count; i += 1) {
      const selected = screen.getAllByRole('option').find((r) => r.getAttribute('aria-selected') === 'true')!
      onRun.mockClear()
      fireEvent.keyDown(dialog, { key: 'Enter' })
      const ran = paletteEntries().find((e) => e.id === onRun.mock.calls[0]?.[0])
      expect(ran, `row ${i}`).toBeDefined()
      expect(selected.textContent ?? '').toContain(ran!.label)
      if (i < count - 1) fireEvent.keyDown(dialog, { key: 'ArrowDown' })
    }
  })
})

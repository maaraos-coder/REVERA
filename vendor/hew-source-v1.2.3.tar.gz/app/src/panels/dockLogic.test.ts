import { describe, it, expect } from 'vitest'
import { deriveDockContext, dockVerbsFor, dockChipLabel, isDockVerbEnabled } from './dockLogic'
import type { NodeRef } from './treeModel'

const obj = (id: bigint): NodeRef => ({ kind: 'object', id })
const group = (id: bigint): NodeRef => ({ kind: 'group', id })
const instance = (id: bigint): NodeRef => ({ kind: 'instance', id })
const sketch = (id: bigint): NodeRef => ({ kind: 'sketch', id })

describe('deriveDockContext', () => {
  it('is "empty" when nothing is selected and no guide is selected', () => {
    expect(deriveDockContext([], null)).toBe('empty')
  })

  it('is null when a guide is selected, regardless of node selection', () => {
    expect(deriveDockContext([], 5n)).toBeNull()
    expect(deriveDockContext([obj(1n)], 5n)).toBeNull()
  })

  it('is "object" for a single selected Object', () => {
    expect(deriveDockContext([obj(1n)], null)).toBe('object')
  })

  it('is "group" for a single selected Group', () => {
    expect(deriveDockContext([group(1n)], null)).toBe('group')
  })

  it('is "instance" for a single selected Instance', () => {
    expect(deriveDockContext([instance(1n)], null)).toBe('instance')
  })

  // Contract change ("sketches are first-class interactable"): a
  // selected sketch used to return null (no dock at all) — it now gets a
  // dedicated 'sketch' context with its own curated verb set, since sketches
  // gained real Push/Pull/Move/Rotate/Scale/Erase behavior.
  it('is "sketch" for a single selected free-standing sketch', () => {
    expect(deriveDockContext([sketch(1n)], null)).toBe('sketch')
  })

  it('is "sketch" for a single selected sketch LINE too (same verbs, finer selection)', () => {
    expect(
      deriveDockContext([{ kind: 'draft-edge', id: 4n, ctx: '{"plane":[0,0,0,0,0,1]}', key: '0000000000000004' }], null),
    ).toBe('sketch')
  })

  it('is "multi" for more than one selected node, regardless of kind mix', () => {
    expect(deriveDockContext([obj(1n), obj(2n)], null)).toBe('multi')
    expect(deriveDockContext([obj(1n), group(2n), instance(3n)], null)).toBe('multi')
  })

  it('is "multi" for a sketch mixed into a multi-selection (multi rules unchanged)', () => {
    expect(deriveDockContext([obj(1n), sketch(2n)], null)).toBe('multi')
  })
})

describe('dockVerbsFor', () => {
  it('empty: primary Rectangle, then Line, Circle, Arc, 3D Text', () => {
    const verbs = dockVerbsFor('empty')
    expect(verbs.map((v) => v.id)).toEqual([
      'tool-rectangle',
      'tool-line',
      'tool-circle',
      'tool-arc',
      'draw-3d-text',
    ])
  })

  // Deliberate contract change (selection-UX overhaul): the Object and Group
  // rows gained Make Component and the Multi row gained Group, so the two
  // structural commands are one click from the selection that enables them.
  // Library effort: Save to Library rides along, ungated, when no `gates`
  // arg is passed at all (see dockVerbsFor's early return) — the gates
  // test below covers the hidden-when-unavailable case.
  it('object: primary Push/Pull, then Move, Paint, Position Texture, Make Component, Save to Library, Erase', () => {
    const verbs = dockVerbsFor('object')
    expect(verbs.map((v) => v.id)).toEqual(['tool-pushpull', 'tool-move', 'tool-paint', 'tool-position-texture', 'edit-make-component', 'save-to-library', 'edit-delete'])
  })

  it('group: primary Edit, then Move, Scale, Make Component, Ungroup, Save to Library, Erase', () => {
    const verbs = dockVerbsFor('group')
    expect(verbs.map((v) => v.id)).toEqual(['enter-context', 'tool-move', 'tool-scale', 'edit-make-component', 'ungroup', 'save-to-library', 'edit-delete'])
  })

  it('instance: primary Edit, then Move, Scale, Make Unique, Explode, Save to Library (spec Component row)', () => {
    const verbs = dockVerbsFor('instance')
    expect(verbs.map((v) => v.id)).toEqual(['enter-context', 'tool-move', 'tool-scale', 'make-unique', 'explode-instance', 'save-to-library'])
  })

  it('multi: primary Move, then Group, Erase', () => {
    const verbs = dockVerbsFor('multi')
    expect(verbs.map((v) => v.id)).toEqual(['tool-move', 'edit-group', 'edit-delete'])
  })

  it('gates hide Group / Make Component when the selection is ineligible', () => {
    // Multi containing a sketch sub-entity: not groupable.
    expect(
      dockVerbsFor('multi', { canGroup: false, canMakeComponent: false }).map((v) => v.id),
    ).toEqual(['tool-move', 'edit-delete'])
    // Object inside an editing context (canMakeComponent is top-level-only).
    expect(
      dockVerbsFor('object', { canGroup: false, canMakeComponent: false }).map((v) => v.id),
    ).toEqual(['tool-pushpull', 'tool-move', 'tool-paint', 'tool-position-texture', 'edit-delete'])
    expect(
      dockVerbsFor('group', { canGroup: false, canMakeComponent: false }).map((v) => v.id),
    ).toEqual(['enter-context', 'tool-move', 'tool-scale', 'ungroup', 'edit-delete'])
    // Eligible selections keep the structural verbs.
    expect(
      dockVerbsFor('multi', { canGroup: true, canMakeComponent: true }).map((v) => v.id),
    ).toContain('edit-group')
    expect(
      dockVerbsFor('object', { canGroup: false, canMakeComponent: true }).map((v) => v.id),
    ).toContain('edit-make-component')
  })

  it('Save to Library is hidden when canSaveToLibrary is omitted or false, shown when true', () => {
    for (const ctx of ['object', 'group', 'instance'] as const) {
      expect(
        dockVerbsFor(ctx, { canGroup: true, canMakeComponent: true }).map((v) => v.id),
      ).not.toContain('save-to-library')
      expect(
        dockVerbsFor(ctx, { canGroup: true, canMakeComponent: true, canSaveToLibrary: false }).map((v) => v.id),
      ).not.toContain('save-to-library')
      expect(
        dockVerbsFor(ctx, { canGroup: true, canMakeComponent: true, canSaveToLibrary: true }).map((v) => v.id),
      ).toContain('save-to-library')
    }
    // Multi/empty/sketch never had the verb in their arrays to begin with.
    expect(
      dockVerbsFor('multi', { canGroup: true, canMakeComponent: true, canSaveToLibrary: true }).map((v) => v.id),
    ).not.toContain('save-to-library')
  })

  it('sketch: primary Push/Pull, then Move, Rotate, Scale, Erase', () => {
    const verbs = dockVerbsFor('sketch')
    expect(verbs.map((v) => v.id)).toEqual([
      'tool-pushpull', 'tool-move', 'tool-rotate', 'tool-scale', 'edit-delete',
    ])
  })

  it('sketch verbs reuse the exact same ids as the other rows (menuActionRef/activeToolId compatibility)', () => {
    const sketchIds = new Set(dockVerbsFor('sketch').map((v) => v.id))
    const objectIds = new Set(dockVerbsFor('object').map((v) => v.id))
    const groupIds = new Set(dockVerbsFor('group').map((v) => v.id))
    // tool-pushpull and edit-delete already exist on the Object row; tool-move
    // and tool-scale already exist on the Group/Instance rows — no new ids
    // were invented for the sketch context.
    expect(sketchIds.has('tool-pushpull')).toBe(true)
    expect(objectIds.has('tool-pushpull')).toBe(true)
    expect(sketchIds.has('edit-delete')).toBe(true)
    expect(objectIds.has('edit-delete')).toBe(true)
    expect(sketchIds.has('tool-scale')).toBe(true)
    expect(groupIds.has('tool-scale')).toBe(true)
  })

  it('every context stays within the spec cap (originally "4-6 items max, curated"; the Library effort added one more selection-only verb to Object/Group, deliberately raising the ungated ceiling to 7 — gated call sites still cap out at 6 when the library is unavailable)', () => {
    for (const ctx of ['empty', 'object', 'group', 'instance', 'multi', 'sketch'] as const) {
      expect(dockVerbsFor(ctx).length).toBeLessThanOrEqual(7)
      expect(dockVerbsFor(ctx).length).toBeGreaterThan(0)
    }
  })
})

describe('isDockVerbEnabled', () => {
  it('hover-preview (sketch not selected): only Push/Pull is enabled', () => {
    const enabled = dockVerbsFor('sketch').filter((v) => isDockVerbEnabled(v, true))
    expect(enabled.map((v) => v.id)).toEqual(['tool-pushpull'])
  })

  it('with a real selection every verb is enabled, in every context', () => {
    for (const ctx of ['empty', 'object', 'group', 'instance', 'multi', 'sketch'] as const) {
      for (const verb of dockVerbsFor(ctx)) {
        expect(isDockVerbEnabled(verb, false)).toBe(true)
      }
    }
  })
})

describe('dockChipLabel', () => {
  it('has a label for every context', () => {
    for (const ctx of ['empty', 'object', 'group', 'instance', 'multi', 'sketch'] as const) {
      expect(dockChipLabel(ctx).length).toBeGreaterThan(0)
    }
  })

  it('reads "SKETCH" for the sketch context', () => {
    expect(dockChipLabel('sketch')).toBe('SKETCH')
  })
})

/**
 *  — component tests for scene-dependent panels.
 *
 * Covers: ObjectInfoPanel, MaterialPalette, DocumentTree, TagsPanel.
 *
 * All panel components import Scene exclusively as `import type`, so the type
 * is erased at runtime and no wasm/loader mock is required — a plain JS object
 * with the right methods stands in as the Scene.
 */

import { objectBoundsFromMesh } from '../test/meshBounds'
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react'
import { describe, expect, it, vi, beforeEach } from 'vitest'
import { ObjectInfoPanel } from './ObjectInfoPanel'
import { MaterialPalette } from './MaterialPalette'
import { DocumentTree } from './DocumentTree'
import { TagsPanel } from './TagsPanel'
import type { Scene as WasmScene } from '../wasm/loader'
import { MATERIAL_SENTINEL } from '../tools/PaintTool'
import { getLengthUnit, setLengthUnit } from '../settings/units'
import type { NodeRef } from './treeModel'

// ---------------------------------------------------------------------------
// Plane-listing helpers — a drawn thing is a draft ref into a plane's
// `plane_units_json` listing (planeUnits.ts), not a sketch handle.
// ---------------------------------------------------------------------------

const hexKey = (n: number): string => n.toString(16).padStart(16, '0')
const GROUND_CTX = '{"plane":[0,0,0,0,0,1]}'
const OTHER_CTX = '{"plane":[0,0,1,0,0,1]}'
const CIRCLE_CURVE = 0xc9
const draftOf = (kind: NodeRef['kind'], ctx: string, key: number): NodeRef => ({ kind, id: BigInt(key), ctx, key: hexKey(key) })
type StoreJson = { kind: 'free'; sketch: number } | { kind: 'topology'; object: number }

/** `n` facet edges (keys 100..) of a circle, or plain line edges when
 *  `circle` is false, in one unit (key 50) of a plane. */
function planeEdgesJson(n: number, circle: boolean, z: number, store: StoreJson): { units: unknown[]; regions: unknown[] } {
  const edges = Array.from({ length: n }, (_v, i) => {
    const t0 = (2 * Math.PI * i) / n
    const t1 = (2 * Math.PI * (i + 1)) / n
    return {
      key: hexKey(100 + i),
      a: [Math.cos(t0), Math.sin(t0), z],
      b: [Math.cos(t1), Math.sin(t1), z],
      store,
      curve: circle ? { center: [0, 0, z], radius: 1 } : null,
    }
  })
  // A circle's facets form one curve RUN (the piece a click selects); a plain
  // line polygon has none.
  const curves = circle
    ? [{ key: hexKey(0xd1), curve_key: hexKey(CIRCLE_CURVE), kind: 'circle', center: [0, 0, z], radius: 1, edges: edges.map((e) => e.key) }]
    : []
  return { units: [{ key: hexKey(50), edges, curves }], regions: [] }
}
/** One free-sketch shape (unit `key`) of four plain lines on the ground. */
function freeShapeListing(key: number): { units: unknown[]; regions: unknown[] } {
  const l = planeEdgesJson(4, false, 0, { kind: 'free', sketch: 5 })
  ;(l.units[0] as { key: string }).key = hexKey(key)
  return l
}
/** A kernel pick that answers an edge's midpoint with that edge, its unit and
 *  (for a circle facet) the circle's curve key. */
function pickByMidpoint(listing: { units: { key: string; edges: { key: string; a: number[]; b: number[]; curve: unknown }[] }[] }) {
  return (_ctx: string, ray: Float64Array): string => {
    for (const u of listing.units) for (const e of u.edges) {
      if (Math.abs((e.a[0] + e.b[0]) / 2 - ray[0]) < 1e-9 && Math.abs((e.a[1] + e.b[1]) / 2 - ray[1]) < 1e-9) {
        return JSON.stringify({ edge: e.key, unit: u.key, curve: e.curve ? hexKey(CIRCLE_CURVE) : null })
      }
    }
    return 'null'
  }
}
import { BANNED_RE, readableText } from '../health/bannedWords'

// ---------------------------------------------------------------------------
// Mock Scene factory — provides only the methods the panels actually call.
// Each call-site passes overrides to customise the scene for that test.
// ---------------------------------------------------------------------------

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function makeScene(overrides: Record<string, any> = {}): WasmScene {
  const scene = {
    object_ids: () => new BigUint64Array(),
    group_ids: () => new BigUint64Array(),
    instance_ids: () => new BigUint64Array(),
    sketch_ids: () => new BigUint64Array(),
    sketch_island_ids: (sid: bigint) => new BigUint64Array([sid + 100n]),
    sketch_edge_island: () => undefined,
    sketch_edge_curve: () => undefined as bigint | undefined,
    sketch_curve_geom: () => undefined as Float64Array | undefined,
    sketch_curve_edges: () => new BigUint64Array(),
    sketch_curve_chain: () => new BigUint64Array(),
    sketch_plane: () => undefined as Float64Array | undefined,
    draft_begin_ctx: vi.fn(() => 7n),
    draft_refacet_curve: vi.fn(),
    draft_end: vi.fn(() => '{"objects":[],"sketches":[],"kept_as_sketch":[]}'),
    draft_cancel: vi.fn(),
    top_level_nodes: () => [],
    object_name: (_id: bigint) => undefined as string | undefined,
    group_name: (_id: bigint) => undefined as string | undefined,
    instance_name: (_id: bigint) => undefined as string | undefined,
    node_tags: (_kind: number, _id: bigint) => [] as string[],
    tag_meta_paths: () => [] as string[],
    tag_meta_hidden: () => new Uint8Array(),
    set_tag_hidden: vi.fn(),
    object_solid: (_id: bigint) => true,
    set_node_name: vi.fn(),
    add_node_tag: vi.fn(),
    remove_node_tag: vi.fn(),
    material_ids: () => new BigUint64Array(),
    material_info: (_id: bigint) => undefined,
    material_texture_bytes: (_id: bigint) => undefined,
    add_material: vi.fn().mockReturnValue(1n),
    add_texture_material: vi.fn(),
    set_object_material: vi.fn(),
    set_material_alpha: vi.fn(),
    // v1.1 assets lane: material/definition rename+delete, purge unused.
    set_material_name: vi.fn(),
    delete_material: vi.fn(),
    material_usage: (_id: bigint) => 0,
    unused_materials: () => new BigUint64Array(),
    component_ids: () => new BigUint64Array(),
    delete_definition: vi.fn(),
    definition_usage: (_id: bigint) => 0,
    unused_definitions: () => new BigUint64Array(),
    purge_unused: vi.fn().mockReturnValue({ materials: () => 0, definitions: () => 0 }),
    node_leaf_objects: (_kind: number, _id: bigint) => new BigUint64Array(),
    group_members: (_id: bigint) => [] as { kind: string; id: bigint }[],
    node_parent: (_kind: number, _id: bigint) => undefined as bigint | undefined,
    instance_def: (_id: bigint) => undefined as bigint | undefined,
    component_name: (_id: bigint) => undefined as string | undefined,
    instances_of: (_id: bigint) => new BigUint64Array(),
    set_component_name: vi.fn(),
    // Bounding Box row (objectBounds.worldBoundsForSelection) — default to a
    // mesh-less scene (no positions), so tests that don't care about
    // Bounding Box sees no row rather than a thrown "not a function".
    object_mesh: (_id: bigint) => ({ positions: () => new Float32Array(), free: () => {} }),
    instance_pose: (_id: bigint) => undefined as Float64Array | undefined,
    component_member_objects: (_id: bigint) => new BigUint64Array(),
    explode_session_objects: () => undefined as BigUint64Array | undefined,
    ...overrides,
  }
  // The Bounding Box row reads `object_bounds`; a mock describes its parts
  // by mesh corners, so derive the one from the other unless given.
  return {
    ...scene,
    object_bounds: overrides.object_bounds ?? objectBoundsFromMesh(scene.object_mesh as (id: bigint) => { positions(): Float32Array; free(): void }),
  } as unknown as WasmScene
}

// ---------------------------------------------------------------------------
// ObjectInfoPanel
// ---------------------------------------------------------------------------

describe('ObjectInfoPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders an empty panel (no text at all) when nothing is selected', () => {
    const { container } = render(
      <ObjectInfoPanel
        scene={makeScene()}
        docRev={0}
        selectedIds={[]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(container.textContent).toBe('')
  })

  it('shows only a quiet count line for a multi-selection', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene()}
        docRev={0}
        selectedIds={[
          { kind: 'object', id: 1n },
          { kind: 'object', id: 2n },
          { kind: 'object', id: 3n },
        ]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('3 selected')).toBeInTheDocument()
    expect(screen.queryByText(/multiple nodes selected/i)).not.toBeInTheDocument()
  })

  it('multi-selection: only tags carried by EVERY selected item show; + adds to all, × removes from all — each as one kernel batch', () => {
    const add_node_tag_many = vi.fn()
    const remove_node_tag_many = vi.fn()
    const onDocumentChanged = vi.fn()
    const onTagsChanged = vi.fn()
    const scene = makeScene({
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Hardware', 'Oak'] : id === 2n ? ['Hardware', 'Pine'] : ['Hardware']),
      add_node_tag_many,
      remove_node_tag_many,
    })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[
          { kind: 'object', id: 1n },
          { kind: 'group', id: 2n },
          { kind: 'object', id: 3n },
        ]}
        onNameChanged={onDocumentChanged}
        onGeometryChanged={vi.fn()}
        onTagsChanged={onTagsChanged}
        onSelectMany={vi.fn()}
      />,
    )
    // "Hardware" is on all three → shown; "Oak"/"Pine" are partial → not.
    expect(screen.getByText('Hardware')).toBeInTheDocument()
    expect(screen.queryByText('Oak')).not.toBeInTheDocument()
    expect(screen.queryByText('Pine')).not.toBeInTheDocument()
    expect(screen.queryByText(/\d\/3/)).not.toBeInTheDocument()

    // + → type → Enter: one add_node_tag_many over the taggable selection.
    fireEvent.click(screen.getByRole('button', { name: 'Add tag to all selected' }))
    const input = screen.getByRole('textbox', { name: 'New tag for all selected' })
    fireEvent.change(input, { target: { value: 'Walnut/Legs' } })
    fireEvent.keyDown(input, { key: 'Enter' })
    expect(add_node_tag_many).toHaveBeenCalledTimes(1)
    const [kinds, ids, segments] = add_node_tag_many.mock.calls[0]
    expect(Array.from(kinds as Uint8Array)).toEqual([0, 1, 0])
    expect(Array.from(ids as BigUint64Array)).toEqual([1n, 2n, 3n])
    expect(segments).toEqual(['Walnut', 'Legs'])
    // Tag edits take the tags path (visibility re-push + bookkeeping), not
    // the bare bookkeeping one — a hidden tag must hide its node at once.
    expect(onTagsChanged).toHaveBeenCalledTimes(1)
    expect(onDocumentChanged).not.toHaveBeenCalled()

    // × on Hardware → one remove_node_tag_many over the whole selection.
    fireEvent.click(screen.getByRole('button', { name: 'Remove tag Hardware from all selected' }))
    expect(remove_node_tag_many).toHaveBeenCalledTimes(1)
    expect(remove_node_tag_many.mock.calls[0][2]).toEqual(['Hardware'])
    expect(onTagsChanged).toHaveBeenCalledTimes(2)
    expect(onDocumentChanged).not.toHaveBeenCalled()
  })

  it('shows the type label "Object" for an object node', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_name: () => 'Arch',
          node_tags: () => [],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('Object')).toBeInTheDocument()
  })

  it('populates the name input with the kernel-supplied name', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_ids: () => new BigUint64Array([1n]),
          object_name: () => 'Bridge Deck',
          node_tags: () => [],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const input = screen.getByPlaceholderText('Object 1') as HTMLInputElement
    expect(input.value).toBe('Bridge Deck')
  })

  it('never shows "(unnamed)" — an unnamed object falls back to the Outliner default label', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_ids: () => new BigUint64Array([7n, 8n]),
          top_level_nodes: () => [
            { kind: 'object', id: 7n },
            { kind: 'object', id: 8n },
          ],
          object_name: () => undefined,
          node_tags: () => [],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 8n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    // 8n is the second top-level row → the same "Object 2" the Outliner shows.
    const input = screen.getByPlaceholderText('Object 2') as HTMLInputElement
    expect(input.value).toBe('')
    expect(screen.queryByPlaceholderText('(unnamed)')).not.toBeInTheDocument()
    expect(screen.queryByText('(unnamed)')).not.toBeInTheDocument()
  })

  it('numbers an unnamed nested object by its position in its group, like the Outliner', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          // Object 8n is globally the second object, but the FIRST member of
          // its group — the Outliner shows "Object 1", so this panel must
          // too (the flat object_ids() index would say "Object 2").
          object_ids: () => new BigUint64Array([7n, 8n]),
          top_level_nodes: () => [
            { kind: 'object', id: 7n },
            { kind: 'group', id: 20n },
          ],
          group_members: (id: bigint) =>
            id === 20n ? [{ kind: 'object', id: 8n }] : [],
          object_name: () => undefined,
          node_tags: () => [],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 8n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByPlaceholderText('Object 1')).toBeInTheDocument()
  })

  it('an unnamed instance falls back to its component definition name (Outliner parity)', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          instance_ids: () => new BigUint64Array([4n]),
          instance_name: () => undefined,
          instance_def: () => 9n,
          component_name: () => 'Door',
          node_tags: () => [],
        })}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByPlaceholderText('Door')).toBeInTheDocument()
  })

  it('shows Definition Name and Instance Name fields for an instance', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          instance_ids: () => new BigUint64Array([4n]),
          instance_name: () => 'Front Door',
          instance_def: () => 9n,
          component_name: () => 'Door',
          instances_of: () => new BigUint64Array([4n]),
          node_tags: () => [],
        })}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const defInput = screen.getByLabelText('Definition Name') as HTMLInputElement
    expect(defInput.value).toBe('Door')
    const instInput = screen.getByLabelText('Instance Name') as HTMLInputElement
    expect(instInput.value).toBe('Front Door')
  })

  it('commits a Definition Name edit through set_component_name (renames every instance)', () => {
    const scene = makeScene({
      instance_ids: () => new BigUint64Array([4n]),
      instance_name: () => undefined,
      instance_def: () => 9n,
      component_name: () => 'Door',
      instances_of: () => new BigUint64Array([4n]),
      node_tags: () => [],
    })
    const onDocumentChanged = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={onDocumentChanged}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const defInput = screen.getByLabelText('Definition Name')
    fireEvent.change(defInput, { target: { value: 'Oak Door' } })
    fireEvent.blur(defInput)
    expect((scene as any).set_component_name).toHaveBeenCalledWith(9n, 'Oak Door')
    expect(onDocumentChanged).toHaveBeenCalled()
  })

  it('shows "Component (N instances)" and the count selects every instance', () => {
    const onSelectMany = vi.fn()
    render(
      <ObjectInfoPanel
        scene={makeScene({
          instance_ids: () => new BigUint64Array([4n, 5n, 6n]),
          instance_name: () => undefined,
          instance_def: () => 9n,
          component_name: () => 'Door',
          instances_of: () => new BigUint64Array([4n, 5n, 6n]),
          node_tags: () => [],
        })}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={onSelectMany}
      />,
    )
    expect(screen.getByText('Component')).toBeInTheDocument()
    const count = screen.getByRole('button', { name: '(3 instances)' })
    fireEvent.click(count)
    expect(onSelectMany).toHaveBeenCalledWith([
      { kind: 'instance', id: 4n },
      { kind: 'instance', id: 5n },
      { kind: 'instance', id: 6n },
    ])
  })

  it('a lone instance reads "(1 instance)" — singular', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          instance_ids: () => new BigUint64Array([4n]),
          instance_name: () => undefined,
          instance_def: () => 9n,
          component_name: () => 'Door',
          instances_of: () => new BigUint64Array([4n]),
          node_tags: () => [],
        })}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByRole('button', { name: '(1 instance)' })).toBeInTheDocument()
  })

  it('does not leak uncommitted Name text across a selection change between same-valued nodes', () => {
    // Objects 1n and 2n are both unnamed — the kernel-name VALUE is identical
    // (undefined) across the selection change, so only an identity-keyed
    // reset clears the typed-but-uncommitted text.
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n, 2n]),
      top_level_nodes: () => [
        { kind: 'object', id: 1n },
        { kind: 'object', id: 2n },
      ],
      object_name: () => undefined,
      node_tags: () => [],
      object_solid: () => true,
    })
    const { rerender } = render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const inputA = screen.getByPlaceholderText('Object 1') as HTMLInputElement
    fireEvent.change(inputA, { target: { value: 'Sneaky' } })
    // Selection moves to object 2 WITHOUT a commit (no blur).
    rerender(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 2n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const inputB = screen.getByPlaceholderText('Object 2') as HTMLInputElement
    expect(inputB.value).toBe('')
    fireEvent.blur(inputB)
    expect((scene as any).set_node_name).not.toHaveBeenCalledWith(0, 2n, 'Sneaky')
  })

  it('does not leak uncommitted Definition Name text across a selection change between instances of same-valued definitions', () => {
    // Instances 4n and 5n place two DIFFERENT definitions that are both
    // unnamed — the defName VALUE is identical across the selection change.
    const scene = makeScene({
      instance_ids: () => new BigUint64Array([4n, 5n]),
      top_level_nodes: () => [
        { kind: 'instance', id: 4n },
        { kind: 'instance', id: 5n },
      ],
      instance_name: () => undefined,
      instance_def: (id: bigint) => (id === 4n ? 9n : 10n),
      component_name: () => undefined,
      instances_of: (id: bigint) => new BigUint64Array([id === 9n ? 4n : 5n]),
      node_tags: () => [],
    })
    const { rerender } = render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const defA = screen.getByLabelText('Definition Name') as HTMLInputElement
    fireEvent.change(defA, { target: { value: 'Sneaky' } })
    // Selection moves to instance 5 (of the other, equally unnamed def).
    rerender(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 5n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const defB = screen.getByLabelText('Definition Name') as HTMLInputElement
    expect(defB.value).toBe('')
    fireEvent.blur(defB)
    expect((scene as any).set_component_name).not.toHaveBeenCalledWith(10n, 'Sneaky')
  })

  it('preserves an uncommitted Definition Name edit across instances of the SAME definition', () => {
    // Instances 4n and 5n both place definition 9n. The field edits the
    // shared definition, so its identity join key is the DEFINITION —
    // switching between siblings must not wipe an in-progress edit, and the
    // eventual blur commits to the (one) definition either way.
    const scene = makeScene({
      instance_ids: () => new BigUint64Array([4n, 5n]),
      top_level_nodes: () => [
        { kind: 'instance', id: 4n },
        { kind: 'instance', id: 5n },
      ],
      instance_name: () => undefined,
      instance_def: () => 9n,
      component_name: () => undefined,
      instances_of: () => new BigUint64Array([4n, 5n]),
      node_tags: () => [],
    })
    const { rerender } = render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 4n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const defA = screen.getByLabelText('Definition Name') as HTMLInputElement
    fireEvent.change(defA, { target: { value: 'Cabinet' } })
    // Selection moves to the sibling instance of the SAME definition.
    rerender(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'instance', id: 5n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const defB = screen.getByLabelText('Definition Name') as HTMLInputElement
    expect(defB.value).toBe('Cabinet')
    fireEvent.blur(defB)
    expect((scene as any).set_component_name).toHaveBeenCalledWith(9n, 'Cabinet')
  })

  it('shows "Solid" for a watertight object', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_name: () => undefined,
          node_tags: () => [],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('Solid')).toBeInTheDocument()
  })

  /** A one-row Model Health report for object 1, as the wasm query returns it. */
  const healthJson = (verdict: Record<string, unknown>, extra: Record<string, unknown> = {}): string =>
    JSON.stringify({
      rows: [
        {
          object: '1',
          name: null,
          definition: null,
          definition_name: null,
          placements: 1,
          instances: [],
          accepted: false,
          family: null,
          verdict,
          rims: [],
          branching_vertices: 0,
          islands: 1,
          ...extra,
        },
      ],
      families: [],
      counts: {},
    })

  const renderOpen = (json: string, onShowHealth?: (id: bigint) => void) =>
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_name: () => undefined,
          node_tags: () => [],
          object_solid: () => false,
          health_report_json: () => json,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
        onShowHealth={onShowHealth}
      />,
    )

  it('says what is wrong in plain words, never "Leaky", for a non-solid object', () => {
    renderOpen(
      healthJson({ kind: 'cappable' }, { rims: [{ role: 'outer', planar: true, closed: true, cappable: true, perimeter: 4, extent: 1, edges: 4 }] }),
    )
    expect(screen.getByText('Open: 1 opening')).toBeInTheDocument()
    expect(screen.queryByText(/leaky/i)).not.toBeInTheDocument()
  })

  it('reads each kind in plain words', () => {
    const okRim = { role: 'outer', planar: true, closed: true, cappable: true, perimeter: 4, extent: 1, edges: 4 }
    const { unmount } = renderOpen(healthJson({ kind: 'flat_sheet', holes: 0 }))
    expect(screen.getByText('Flat panel')).toBeInTheDocument()
    unmount()
    const second = renderOpen(healthJson({ kind: 'bent_sheet' }))
    expect(screen.getByText('Curved sheet')).toBeInTheDocument()
    second.unmount()
    const third = renderOpen(healthJson({ kind: 'holes', planar: 2, warped: 0 }, { rims: [okRim, okRim] }))
    expect(screen.getByText('Open: 2 openings')).toBeInTheDocument()
    third.unmount()
    const fourth = renderOpen(healthJson({ kind: 'mixed' }))
    expect(screen.getByText("Open edges don't lie flat")).toBeInTheDocument()
    fourth.unmount()
    const fifth = renderOpen(healthJson({ kind: 'non_manifold' }, { branching_vertices: 2 }))
    expect(screen.getByText('Open edges branch')).toBeInTheDocument()
    fifth.unmount()
    renderOpen(
      healthJson({ kind: 'holes', planar: 1, warped: 0 }, { rims: [{ role: 'outer', planar: true, closed: true, cappable: false, sheet_edge: true, perimeter: 4, extent: 1, edges: 4 }] }),
    )
    expect(screen.getByText('Open edges run along a lip')).toBeInTheDocument()
  })

  it('uses none of the kernel words anywhere on screen, for every kind', () => {
    const okRim = { role: 'outer', planar: true, closed: true, cappable: true, perimeter: 4, extent: 1, edges: 4 }
    const badRim = { ...okRim, planar: false, cappable: false }
    const cases: Array<[Record<string, unknown>, Record<string, unknown>]> = [
      [{ kind: 'cappable' }, { rims: [okRim] }],
      [{ kind: 'holes', planar: 1, warped: 1 }, { rims: [okRim, badRim] }],
      [{ kind: 'flat_sheet', holes: 2 }, {}],
      [{ kind: 'flat_sheet', holes: 0 }, { accepted: true }],
      [{ kind: 'bent_sheet' }, {}],
      [{ kind: 'mixed' }, {}],
      [{ kind: 'non_manifold' }, {}],
      [{ kind: 'cappable' }, { family: 0 }],
    ]
    for (const [verdict, extra] of cases) {
      const { container, unmount } = renderOpen(healthJson(verdict, extra))
      const text = readableText(container)
      expect(text, JSON.stringify(verdict)).not.toMatch(BANNED_RE)
      expect(text).toMatch(/Geometry/)
      unmount()
    }
  })

  it('a kept panel reads as kept', () => {
    renderOpen(healthJson({ kind: 'flat_sheet', holes: 0 }, { accepted: true }))
    expect(screen.getByText('Flat panel (kept as is)')).toBeInTheDocument()
  })

  it('the Show link asks the app to open Model Health on this object', () => {
    const onShow = vi.fn()
    renderOpen(healthJson({ kind: 'mixed' }), onShow)
    fireEvent.click(screen.getByRole('button', { name: 'Show in list' }))
    expect(onShow).toHaveBeenCalledWith(1n)
  })

  describe('Model Health repairs', () => {
    const planarRim = { role: 'outer', planar: true, closed: true, cappable: true, perimeter: 4, extent: 1, edges: 4 }
    const renderRepair = (json: string, extra: Record<string, unknown>, onGeometryChanged = vi.fn(), onToast = vi.fn()) => {
      render(
        <ObjectInfoPanel
          scene={makeScene({
            object_name: () => undefined,
            node_tags: () => [],
            object_solid: () => false,
            health_report_json: () => json,
            ...extra,
          })}
          docRev={0}
          selectedIds={[{ kind: 'object', id: 1n }]}
          onNameChanged={vi.fn()}
          onGeometryChanged={onGeometryChanged}
          onTagsChanged={vi.fn()}
          onSelectMany={vi.fn()}
          onToast={onToast}
        />,
      )
      return { onGeometryChanged, onToast }
    }

    it('Close caps every opening and refreshes; Keep as is keeps', () => {
      const cap_rims = vi.fn(() => '{"faces":1,"closed":true,"reversed":false}')
      const set_accepted_surface = vi.fn()
      const { onGeometryChanged } = renderRepair(healthJson({ kind: 'cappable' }, { rims: [planarRim] }), { cap_rims, set_accepted_surface })
      fireEvent.click(screen.getByRole('button', { name: 'Close' }))
      expect(cap_rims).toHaveBeenCalledWith(1n, null)
      fireEvent.click(screen.getByRole('button', { name: 'Keep as is' }))
      expect(set_accepted_surface).toHaveBeenCalledWith(1n, true)
      expect(onGeometryChanged).toHaveBeenCalledTimes(2)
    })

    it('a kept object offers Don\'t keep', () => {
      const set_accepted_surface = vi.fn()
      renderRepair(healthJson({ kind: 'cappable' }, { accepted: true, rims: [planarRim] }), { set_accepted_surface })
      expect(screen.queryByRole('button', { name: 'Keep as is' })).not.toBeInTheDocument()
      fireEvent.click(screen.getByRole('button', { name: "Don't keep" }))
      expect(set_accepted_surface).toHaveBeenCalledWith(1n, false)
    })

    it("an object that can't be closed offers no Close", () => {
      renderRepair(healthJson({ kind: 'non_manifold' }), {})
      expect(screen.queryByRole('button', { name: 'Close' })).not.toBeInTheDocument()
      expect(screen.getByRole('button', { name: 'Keep as is' })).toBeInTheDocument()
    })

    it('a refusal toasts the kernel copy and does not refresh', () => {
      const cap_rims = vi.fn(() => {
        throw new Error('RimNotPlanar: not flat')
      })
      const { onGeometryChanged, onToast } = renderRepair(healthJson({ kind: 'mixed' }), { cap_rims })
      fireEvent.click(screen.getByRole('button', { name: 'Close' }))
      expect(onToast.mock.calls[0][1]).toBe('RimNotPlanar')
      expect(onGeometryChanged).not.toHaveBeenCalled()
    })
  })

  it('a solid object has no Show link', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({ object_name: () => undefined, node_tags: () => [], object_solid: () => true })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
        onShowHealth={vi.fn()}
      />,
    )
    expect(screen.getByText('Solid')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Show in list' })).not.toBeInTheDocument()
  })

  it('shows "Group" for a group node with no solid/leaky indicator', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          group_name: () => undefined,
          node_tags: () => [],
        })}
        docRev={0}
        selectedIds={[{ kind: 'group', id: 2n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('Group')).toBeInTheDocument()
    expect(screen.queryByText('Solid')).not.toBeInTheDocument()
    expect(screen.queryByText('Leaky')).not.toBeInTheDocument()
  })

  it('renders a tag chip for each existing tag on the node', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_name: () => undefined,
          // "Structure/Roof" → path ['Structure','Roof'] → chip shows "Structure / Roof"
          node_tags: () => ['Structure/Roof'],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('Structure / Roof')).toBeInTheDocument()
  })

  it('calls remove_node_tag with the path when the × chip button is clicked', () => {
    const scene = makeScene({
      object_name: () => undefined,
      node_tags: () => ['Walls'],
      object_solid: () => true,
    })
    const onDocumentChanged = vi.fn()
    const onTagsChanged = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={onDocumentChanged}
        onGeometryChanged={vi.fn()}
        onTagsChanged={onTagsChanged}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.click(screen.getByTitle('Remove tag'))
    expect((scene as any).remove_node_tag).toHaveBeenCalledWith(0, 1n, ['Walls'])
    expect(onTagsChanged).toHaveBeenCalledTimes(1)
    expect(onDocumentChanged).not.toHaveBeenCalled()
  })

  it('has no "No tags" boilerplate — empty state is just the "+" button', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          object_name: () => undefined,
          node_tags: () => [],
          object_solid: () => true,
        })}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.queryByText(/no tags/i)).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Add tag' })).toBeInTheDocument()
    // The add field is hidden until "+" is clicked.
    expect(screen.queryByPlaceholderText('Structure/Roof')).not.toBeInTheDocument()
  })

  it('clicking "+" reveals a focused tag field; Enter commits split segments and closes it', () => {
    const scene = makeScene({
      object_name: () => undefined,
      node_tags: () => [],
      object_solid: () => true,
    })
    const onDocumentChanged = vi.fn()
    const onTagsChanged = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={onDocumentChanged}
        onGeometryChanged={vi.fn()}
        onTagsChanged={onTagsChanged}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Add tag' }))
    const tagInput = screen.getByPlaceholderText('Structure/Roof')
    expect(tagInput).toHaveFocus()
    fireEvent.change(tagInput, { target: { value: 'Mech/HVAC' } })
    fireEvent.keyDown(tagInput, { key: 'Enter' })
    expect((scene as any).add_node_tag).toHaveBeenCalledWith(0, 1n, ['Mech', 'HVAC'])
    expect(onTagsChanged).toHaveBeenCalledTimes(1)
    expect(onDocumentChanged).not.toHaveBeenCalled()
    // Field closes after commit; the "+" affordance returns.
    expect(screen.queryByPlaceholderText('Structure/Roof')).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Add tag' })).toBeInTheDocument()
  })

  it('Escape cancels the tag field without committing', () => {
    const scene = makeScene({
      object_name: () => undefined,
      node_tags: () => [],
      object_solid: () => true,
    })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Add tag' }))
    const tagInput = screen.getByPlaceholderText('Structure/Roof')
    fireEvent.change(tagInput, { target: { value: 'Half-typed' } })
    fireEvent.keyDown(tagInput, { key: 'Escape' })
    expect((scene as any).add_node_tag).not.toHaveBeenCalled()
    expect(screen.queryByPlaceholderText('Structure/Roof')).not.toBeInTheDocument()
  })

  // Mirrors dialogs.test.tsx's expectEscapeStopsPropagationToWindow: a
  // dismiss-on-Escape input must not let the keydown bubble to window, or it
  // would ALSO fire the Viewport's own Escape handling (context-pop) directly
  // underneath this field — e.g. canceling the tag while editing inside a
  // group/component context must not also pop that context.
  it('stops the tag field’s Escape from bubbling to window', () => {
    const scene = makeScene({
      object_name: () => undefined,
      node_tags: () => [],
      object_solid: () => true,
    })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Add tag' }))
    const tagInput = screen.getByPlaceholderText('Structure/Roof')
    const windowKeyDown = vi.fn()
    window.addEventListener('keydown', windowKeyDown)
    try {
      fireEvent.keyDown(tagInput, { key: 'Escape', bubbles: true })
      expect(windowKeyDown).not.toHaveBeenCalled()
    } finally {
      window.removeEventListener('keydown', windowKeyDown)
    }
  })

  it('blurring the empty tag field closes it without committing', () => {
    const scene = makeScene({
      object_name: () => undefined,
      node_tags: () => [],
      object_solid: () => true,
    })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Add tag' }))
    fireEvent.blur(screen.getByPlaceholderText('Structure/Roof'))
    expect((scene as any).add_node_tag).not.toHaveBeenCalled()
    expect(screen.queryByPlaceholderText('Structure/Roof')).not.toBeInTheDocument()
  })

  it('commits the edited name to the scene on blur', () => {
    const scene = makeScene({
      object_name: () => '',
      node_tags: () => [],
      object_solid: () => true,
    })
    const onDocumentChanged = vi.fn()
    const onGeometryChanged = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'object', id: 1n }]}
        onNameChanged={onDocumentChanged}
        onGeometryChanged={onGeometryChanged}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const nameInput = screen.getByPlaceholderText('Object 1')
    fireEvent.change(nameInput, { target: { value: 'Pillar' } })
    fireEvent.blur(nameInput)
    expect((scene as any).set_node_name).toHaveBeenCalledWith(0, 1n, 'Pillar')
    expect(onDocumentChanged).toHaveBeenCalled()
    // A name changes nothing drawn — no re-tessellation.
    expect(onGeometryChanged).not.toHaveBeenCalled()
  })

  it('shows "Shape" + a "drawing" subtitle for a shape drawn only in a free sketch off the ground', () => {
    const listing = planeEdgesJson(4, false, 2, { kind: 'free', sketch: 20 })
    const ctx = '{"plane":[0,0,2,0,0,1]}'
    render(
      <ObjectInfoPanel
        scene={makeScene({ plane_units_json: () => JSON.stringify(listing) })}
        docRev={0}
        selectedIds={[draftOf('draft-island', ctx, 50)]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('Shape')).toBeInTheDocument()
    expect(screen.getByTestId('object-info-store')).toHaveTextContent('drawing')
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument()
  })

  it('shows "Sketch" + its positional label for a sketch selection, with no help boilerplate', () => {
    const scene = makeScene({
      sketch_ids: () => new BigUint64Array([10n, 20n, 30n]),
    })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[{ kind: 'sketch', id: 20n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('Sketch')).toBeInTheDocument()
    // Island 120n of sketch 20n is row index 1 in the outliner's flattened
    // island list → "Sketch 2" (1-based, matching the tree's label).
    expect(screen.getByText('Sketch 2')).toBeInTheDocument()
    // (A selected drawn SHAPE is labelled "Shape" — see the draft-ref tests.)
    // The old explanatory boilerplate is gone — just the real fields.
    expect(screen.queryByText(/naming and tags are not yet supported/i)).not.toBeInTheDocument()
    expect(screen.queryByText(/a drawn line/i)).not.toBeInTheDocument()
    // No name input (sketches aren't renameable), no crash from nodeKindToNumber.
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument()
  })

  // -------------------------------------------------------------------------
  // Bounding Box row (objectBounds.worldBoundsForSelection) — world AABB
  // extents, formatted with the same length formatter Tape Measure/typed
  // entry use.
  // -------------------------------------------------------------------------

  it('shows a Bounding Box row for a selected object, formatted in the active length unit', () => {
    const originalFormat = getLengthUnit()
    try {
      setLengthUnit('mm')
      const { container } = render(
        <ObjectInfoPanel
          scene={makeScene({
            object_name: () => 'Bracket',
            node_tags: () => [],
            object_solid: () => true,
            // A 220mm x 150mm x 100mm box (two opposite corners suffice —
            // meshWorldBounds only reads extremal coordinates).
            object_mesh: () => ({
              positions: () => new Float32Array([-0.11, -0.075, -0.05, 0.11, 0.075, 0.05]),
              free: () => {},
            }),
          })}
          docRev={0}
          selectedIds={[{ kind: 'object', id: 1n }]}
          onNameChanged={vi.fn()}
          onGeometryChanged={vi.fn()}
          onTagsChanged={vi.fn()}
          onSelectMany={vi.fn()}
        />,
      )
      expect(screen.getByText('Bounding Box')).toBeInTheDocument()
      expect(container.textContent).toContain('220 mm')
      expect(container.textContent).toContain('150 mm')
      expect(container.textContent).toContain('100 mm')
    } finally {
      setLengthUnit(originalFormat)
    }
  })

  it('shows no Bounding Box row for a mesh-less selection (a sketch)', () => {
    render(
      <ObjectInfoPanel
        scene={makeScene({
          sketch_ids: () => new BigUint64Array([10n]),
        })}
        docRev={0}
        selectedIds={[{ kind: 'sketch', id: 10n }]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.queryByText('Bounding Box')).not.toBeInTheDocument()
  })

  it('shows the union Bounding Box of a multi-selection alongside the count line', () => {
    const scene = makeScene({
      object_mesh: (id: bigint) =>
        id === 1n
          ? { positions: () => new Float32Array([0, 0, 0, 1, 1, 1]), free: () => {} }
          : { positions: () => new Float32Array([2, 2, 2, 3, 3, 3]), free: () => {} },
    })
    const { container } = render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[
          { kind: 'object', id: 1n },
          { kind: 'object', id: 2n },
        ]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.getByText('2 selected')).toBeInTheDocument()
    expect(screen.getByText('Bounding Box')).toBeInTheDocument()
    // Union extent is 3m on each axis (0 to 3) in the default 'm' format.
    expect(container.textContent).toContain('3 m')
  })

  it('renders without throwing when object_mesh throws for the selected id (no Bounding Box row)', () => {
    // `object_mesh` throws (UnknownObject) on a stale/deleted id — reproducing
    // the post-undo case where the selection still names a removed object.
    // The panel must degrade gracefully (no crash, no Bounding Box row), like
    // the mesh-less-sketch case above.
    const scene = makeScene({
      object_name: () => 'Ghost',
      node_tags: () => [],
      object_solid: () => true,
      object_mesh: () => {
        throw new Error('UnknownObject: object')
      },
    })
    expect(() =>
      render(
        <ObjectInfoPanel
          scene={scene}
          docRev={0}
          selectedIds={[{ kind: 'object', id: 1n }]}
          onNameChanged={vi.fn()}
          onGeometryChanged={vi.fn()}
          onTagsChanged={vi.fn()}
          onSelectMany={vi.fn()}
        />,
      ),
    ).not.toThrow()
    expect(screen.queryByText('Bounding Box')).not.toBeInTheDocument()
  })

  // -------------------------------------------------------------------------
  // Segments — SketchUp's Entity Info "Segments", for a drawn circle only.
  // Editing it re-facets the existing circle in place, as one draft on the
  // circle's plane.
  // -------------------------------------------------------------------------

  /** A scene whose ground plane holds one unit: a circle of `facets` edges
   *  when `circle` is true (a plain closed line polygon otherwise — its sides
   *  are its geometry, not facets of a circle). The same listing answers a
   *  second plane (OTHER_CTX) so two circles can share a curve key. */
  function curveScene(opts: {
    circle?: boolean
    facets?: number
    refacet?: (...args: unknown[]) => unknown
  } = {}) {
    const listing = planeEdgesJson(opts.facets ?? 24, opts.circle ?? true, 0, { kind: 'free', sketch: 5 })
    return makeScene({
      plane_units_json: () => JSON.stringify(listing),
      pick_plane_unit: pickByMidpoint(listing as never),
      ...(opts.refacet ? { draft_refacet_curve: opts.refacet } : {}),
    })
  }

  const CURVE_SELECTION = [draftOf('draft-curve', GROUND_CTX, CIRCLE_CURVE)]

  it('shows a drawn circle\u2019s current facet count in the Segments field', () => {
    render(
      <ObjectInfoPanel
        scene={curveScene({ circle: true, facets: 24 })}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const input = screen.getByLabelText('Segments') as HTMLInputElement
    expect(input.value).toBe('24')
  })

  it('shows no Segments field for edges with no circle \u2014 a polygon\u2019s sides are its geometry, not facets of a circle', () => {
    render(
      <ObjectInfoPanel
        scene={curveScene({ circle: false, facets: 6 })}
        docRev={0}
        selectedIds={[draftOf('draft-island', GROUND_CTX, 50)]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    expect(screen.queryByLabelText('Segments')).not.toBeInTheDocument()
    // It is still recognisably a drawn shape.
    expect(screen.getByText('Shape')).toBeInTheDocument()
  })

  it('re-facets the circle on Enter, in one draft, and re-points the selection', () => {
    const scene = curveScene({ circle: true, facets: 24 })
    const onSelectMany = vi.fn()
    const onDocumentChanged = vi.fn()
    const onGeometryChanged = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={onDocumentChanged}
        onGeometryChanged={onGeometryChanged}
        onTagsChanged={vi.fn()}
        onSelectMany={onSelectMany}
      />,
    )
    const input = screen.getByLabelText('Segments')
    fireEvent.change(input, { target: { value: '48' } })
    fireEvent.blur(input)

    expect(scene.draft_refacet_curve).toHaveBeenCalledWith(7n, BigInt(CIRCLE_CURVE), 48)
    // Bracketed as exactly one undo step: one draft on the circle's plane.
    expect(scene.draft_begin_ctx).toHaveBeenCalledWith(GROUND_CTX, 'Segments')
    expect(scene.draft_end).toHaveBeenCalledWith(7n)
    // The curve key hashes only centre and radius, so it survives the
    // rebuild: the selection is re-pointed at the same curve (was: at the
    // rebuilt chain's new representative edge).
    expect(onSelectMany).toHaveBeenCalledWith([draftOf('draft-curve', GROUND_CTX, CIRCLE_CURVE)])
    // A re-facet changes drawn geometry: the repaint path, not bare bookkeeping.
    expect(onGeometryChanged).toHaveBeenCalledTimes(1)
    expect(onDocumentChanged).not.toHaveBeenCalled()
  })

  it('Escape reverts the Segments field to the current facet count without committing', () => {
    const scene = curveScene({ circle: true, facets: 24 })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const input = screen.getByLabelText('Segments') as HTMLInputElement
    fireEvent.change(input, { target: { value: '48' } })
    fireEvent.keyDown(input, { key: 'Escape' })
    expect(input.value).toBe('24')
    expect(scene.draft_refacet_curve).not.toHaveBeenCalled()
  })

  // Mirrors dialogs.test.tsx's expectEscapeStopsPropagationToWindow: reverting
  // the Segments field on Escape must not let the keydown bubble to window,
  // or it would ALSO fire the Viewport's own Escape handling (context-pop)
  // directly underneath this field.
  it('stops the Segments field’s Escape from bubbling to window', () => {
    const scene = curveScene({ circle: true, facets: 24 })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    const input = screen.getByLabelText('Segments')
    const windowKeyDown = vi.fn()
    window.addEventListener('keydown', windowKeyDown)
    try {
      fireEvent.keyDown(input, { key: 'Escape', bubbles: true })
      expect(windowKeyDown).not.toHaveBeenCalled()
    } finally {
      window.removeEventListener('keydown', windowKeyDown)
    }
  })

  it('refuses a count below the floor visibly, without touching the kernel', () => {
    const scene = curveScene({ circle: true, facets: 24 })
    const onToast = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
        onToast={onToast}
      />,
    )
    const input = screen.getByLabelText('Segments') as HTMLInputElement
    fireEvent.change(input, { target: { value: '3' } })
    fireEvent.blur(input)

    expect(scene.draft_refacet_curve).not.toHaveBeenCalled()
    expect(scene.draft_begin_ctx).not.toHaveBeenCalled()
    expect(onToast).toHaveBeenCalledTimes(1)
    expect(onToast.mock.calls[0][1]).toBe('SegmentsBelowFloor')
    // The field springs back to the truth rather than showing a value the
    // model does not have.
    expect(input.value).toBe('24')
  })

  it('surfaces a kernel refusal as a toast and restores the field', () => {
    const scene = curveScene({
      circle: true,
      facets: 24,
      refacet: vi.fn(() => {
        throw new Error('CurveNotRefacetable: only a whole circle')
      }),
    })
    const onToast = vi.fn()
    const onSelectMany = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={onSelectMany}
        onToast={onToast}
      />,
    )
    const input = screen.getByLabelText('Segments') as HTMLInputElement
    fireEvent.change(input, { target: { value: '96' } })
    fireEvent.blur(input)

    expect(onToast).toHaveBeenCalledTimes(1)
    expect(onToast.mock.calls[0][1]).toBe('CurveNotRefacetable')
    // The draft is closed (cancelled) even on the refusal path, so the tools
    // are not left mid-gesture.
    expect(scene.draft_cancel).toHaveBeenCalledWith(7n)
    expect(onSelectMany).not.toHaveBeenCalled()
    expect(input.value).toBe('24')
  })

  it('surfaces an above-the-cap refusal from the kernel as a toast', () => {
    // The panel refuses BELOW the floor itself (no round trip), but the upper
    // bound is the kernel's alone — the panel forwards the count and must
    // surface `SegmentsAboveCap` like any other refusal rather than leaving
    // the field showing a count the model does not have.
    const scene = curveScene({
      circle: true,
      facets: 24,
      refacet: vi.fn(() => {
        throw new Error('SegmentsAboveCap: a circle allows at most 1024 segments')
      }),
    })
    const onToast = vi.fn()
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
        onToast={onToast}
      />,
    )
    const input = screen.getByLabelText('Segments') as HTMLInputElement
    fireEvent.change(input, { target: { value: '99999' } })
    fireEvent.blur(input)

    // It really was forwarded — the panel does not second-guess the cap.
    expect(scene.draft_refacet_curve).toHaveBeenCalledWith(7n, BigInt(CIRCLE_CURVE), 99999)
    expect(onToast).toHaveBeenCalledTimes(1)
    expect(onToast.mock.calls[0][1]).toBe('SegmentsAboveCap')
    expect(scene.draft_cancel).toHaveBeenCalledWith(7n)
    expect(input.value).toBe('24')
  })

  it('does not carry uncommitted text between two circles that share a curve key', () => {
    // The same curve key can be reached on two different planes (a circle's
    // key hashes only its centre and radius). If the field's identity key
    // ignored the plane, typed text would survive the selection change and
    // the next blur would commit it onto the wrong circle.
    const scene = curveScene({ circle: true, facets: 24 })
    const view = render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={[draftOf('draft-curve', GROUND_CTX, CIRCLE_CURVE)]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.change(screen.getByLabelText('Segments'), { target: { value: '64' } })

    // A DIFFERENT plane, same curve key, same facet count (24).
    view.rerender(
      <ObjectInfoPanel
        scene={scene}
        docRev={1}
        selectedIds={[draftOf('draft-curve', OTHER_CTX, CIRCLE_CURVE)]}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )

    const input = screen.getByLabelText('Segments') as HTMLInputElement
    expect(input.value).toBe('24')
    fireEvent.blur(input)
    expect(scene.draft_refacet_curve).not.toHaveBeenCalled()
  })

  it('does nothing at all when the count is unchanged', () => {
    const scene = curveScene({ circle: true, facets: 24 })
    render(
      <ObjectInfoPanel
        scene={scene}
        docRev={0}
        selectedIds={CURVE_SELECTION}
        onNameChanged={vi.fn()}
        onGeometryChanged={vi.fn()}
        onTagsChanged={vi.fn()}
        onSelectMany={vi.fn()}
      />,
    )
    fireEvent.blur(screen.getByLabelText('Segments'))
    expect(scene.draft_begin_ctx).not.toHaveBeenCalled()
    expect(scene.draft_refacet_curve).not.toHaveBeenCalled()
  })
})

// ---------------------------------------------------------------------------
// MaterialPalette
// ---------------------------------------------------------------------------

describe('MaterialPalette', () => {
  const baseProps = {
    docRev: 0,
    currentMaterialId: MATERIAL_SENTINEL,
    onSelectMaterial: vi.fn(),
    onMaterialCreated: vi.fn(),
    onDocumentChanged: vi.fn(),
    onAlphaCommitted: vi.fn(),
  }

  beforeEach(() => {
    vi.clearAllMocks()
    // jsdom does not implement scrollIntoView; polyfill (fresh mock each
    // test) so the selected-swatch scroll effect doesn't throw and its
    // calls are cleanly isolated per test.
    Element.prototype.scrollIntoView = vi.fn()
  })

  it('renders the Default swatch with title "Default (unpainted)"', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    expect(screen.getByTitle('Default (unpainted)')).toBeInTheDocument()
  })

  it('has no "Fill selected object" button (whole-object paint is Ctrl/Cmd-click)', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    expect(screen.queryByRole('button', { name: /fill selected object/i })).not.toBeInTheDocument()
  })

  it('clicking the Default swatch calls onSelectMaterial(MATERIAL_SENTINEL)', () => {
    const onSelectMaterial = vi.fn()
    render(
      <MaterialPalette {...baseProps} scene={makeScene()} onSelectMaterial={onSelectMaterial} />,
    )
    fireEvent.click(screen.getByTitle('Default (unpainted)'))
    expect(onSelectMaterial).toHaveBeenCalledWith(MATERIAL_SENTINEL)
  })

  it('the "Add color" and "Add texture" sub-panes start collapsed', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    const colorHeader = screen.getByRole('button', { name: 'Add color' })
    const textureHeader = screen.getByRole('button', { name: 'Add texture' })
    expect(colorHeader).toHaveAttribute('aria-expanded', 'false')
    expect(textureHeader).toHaveAttribute('aria-expanded', 'false')
    expect(screen.queryByRole('button', { name: /\+ add color/i })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /\+ add texture/i })).not.toBeInTheDocument()
    expect(screen.queryByPlaceholderText('Name…')).not.toBeInTheDocument()
  })

  it('expanding "Add color" reveals its body; a "+ Add color" button appears, disabled until a color is chosen', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    fireEvent.click(screen.getByRole('button', { name: 'Add color' }))
    expect(screen.getByRole('button', { name: 'Add color' })).toHaveAttribute('aria-expanded', 'true')
    const addButton = screen.getByRole('button', { name: /\+ add color/i })
    expect(addButton).toBeDisabled()
    fireEvent.change(screen.getByLabelText('Choose color'), { target: { value: '#112233' } })
    expect(addButton).not.toBeDisabled()
  })

  it('clicking "+ Add color" (after choosing a color) calls add_material, onMaterialCreated, and onDocumentChanged — but not onSelectMaterial (adding a color must not switch to the Paint tool)', () => {
    const scene = makeScene()
    const onSelectMaterial = vi.fn()
    const onMaterialCreated = vi.fn()
    const onDocumentChanged = vi.fn()
    render(
      <MaterialPalette
        {...baseProps}
        scene={scene}
        onSelectMaterial={onSelectMaterial}
        onMaterialCreated={onMaterialCreated}
        onDocumentChanged={onDocumentChanged}
      />,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Add color' }))
    fireEvent.change(screen.getByLabelText('Choose color'), { target: { value: '#112233' } })
    fireEvent.click(screen.getByRole('button', { name: /\+ add color/i }))
    expect((scene as any).add_material).toHaveBeenCalled()
    expect(onMaterialCreated).toHaveBeenCalled()
    expect(onSelectMaterial).not.toHaveBeenCalled()
    expect(onDocumentChanged).toHaveBeenCalled()
  })

  it('renders a named swatch for each material returned by the scene', () => {
    const mockInfo = {
      r: () => 255,
      g: () => 0,
      b: () => 0,
      a: () => 255,
      name: () => 'Red Paint',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={7n} />)
    expect(screen.getByTitle('Red Paint')).toBeInTheDocument()
    expect(screen.getByText('Red Paint')).toBeInTheDocument()
  })

  it('clicking a material swatch calls onSelectMaterial with its id', () => {
    const mockInfo = {
      r: () => 0,
      g: () => 128,
      b: () => 255,
      name: () => 'Sky Blue',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([3n]),
      material_info: () => mockInfo,
    })
    const onSelectMaterial = vi.fn()
    render(
      <MaterialPalette
        {...baseProps}
        scene={scene}
        onSelectMaterial={onSelectMaterial}
      />,
    )
    fireEvent.click(screen.getByTitle('Sky Blue'))
    expect(onSelectMaterial).toHaveBeenCalledWith(3n)
  })

  it('filter narrows the materials list by case-insensitive substring match on name, without hiding the Default row', () => {
    const infos: Record<string, { r: () => number; g: () => number; b: () => number; a: () => number; name: () => string; has_texture: () => boolean }> = {
      '1': { r: () => 255, g: () => 0, b: () => 0, a: () => 255, name: () => 'Red Paint', has_texture: () => false },
      '2': { r: () => 0, g: () => 128, b: () => 255, a: () => 255, name: () => 'Sky Blue', has_texture: () => false },
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([1n, 2n]),
      material_info: (id: bigint) => infos[id.toString()],
    })
    render(<MaterialPalette {...baseProps} scene={scene} />)
    expect(screen.getByTitle('Red Paint')).toBeInTheDocument()
    expect(screen.getByTitle('Sky Blue')).toBeInTheDocument()

    fireEvent.change(screen.getByLabelText('Filter materials'), { target: { value: 'BLUE' } })
    expect(screen.queryByTitle('Red Paint')).not.toBeInTheDocument()
    expect(screen.getByTitle('Sky Blue')).toBeInTheDocument()
    // The Default row is not a material — it is never filtered out.
    expect(screen.getByTitle('Default (unpainted)')).toBeInTheDocument()
  })

  it('shows "No materials match" when the filter matches nothing, and the × clears it back to the full list', () => {
    const mockInfo = { r: () => 255, g: () => 0, b: () => 0, a: () => 255, name: () => 'Red Paint', has_texture: () => false }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([1n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} />)
    fireEvent.change(screen.getByLabelText('Filter materials'), { target: { value: 'zzz' } })
    expect(screen.queryByTitle('Red Paint')).not.toBeInTheDocument()
    expect(screen.getByText('No materials match')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: 'Clear filter' }))
    expect(screen.getByTitle('Red Paint')).toBeInTheDocument()
    expect(screen.queryByText('No materials match')).not.toBeInTheDocument()
  })

  it('filtering out the selected material does not clear the selection — the opacity slider keeps showing its alpha', () => {
    const mockInfo = { r: () => 255, g: () => 0, b: () => 0, a: () => 128, name: () => 'Glass', has_texture: () => false }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={7n} />)
    fireEvent.change(screen.getByLabelText('Filter materials'), { target: { value: 'zzz' } })
    expect(screen.queryByTitle('Glass')).not.toBeInTheDocument()
    const slider = screen.getByRole('slider') as HTMLInputElement
    expect(slider).not.toBeDisabled()
    expect(slider.value).toBe('128')
  })

  it('scrolls the newly-selected swatch into view when currentMaterialId changes — the Alt-eyedropper\'s sample→select loop on a long list', () => {
    const mockInfoFor = (name: string) => ({
      r: () => 0, g: () => 0, b: () => 0, a: () => 255, name: () => name, has_texture: () => false,
    })
    const scene = makeScene({
      material_ids: () => new BigUint64Array([1n, 2n, 3n]),
      material_info: (id: bigint) => mockInfoFor(`Mat ${id}`),
    })
    const { rerender } = render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={1n} />)
    ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

    // Simulate the eyedropper landing on material 3 far down the list.
    rerender(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={3n} />)

    expect(Element.prototype.scrollIntoView).toHaveBeenCalledWith({ block: 'nearest' })
  })

  it('an eyedropper sample landing on a filtered-out swatch clears the filter so the swatch is visible and still gets scrolled to', () => {
    const mockInfoFor = (name: string) => ({
      r: () => 0, g: () => 0, b: () => 0, a: () => 255, name: () => name, has_texture: () => false,
    })
    const scene = makeScene({
      material_ids: () => new BigUint64Array([1n, 2n, 3n]),
      material_info: (id: bigint) => mockInfoFor(`Mat ${id}`),
    })
    const { rerender } = render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={1n} />)

    // Filter down to a name that hides material 3, the eyedropper's target.
    fireEvent.change(screen.getByLabelText('Filter materials'), { target: { value: 'Mat 1' } })
    expect(screen.queryByTitle('Mat 3')).not.toBeInTheDocument()
    ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

    // The eyedropper samples material 3 — hidden by the still-active filter.
    rerender(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={3n} />)

    // The filter is cleared so the sampled swatch is visible again, and the
    // scroll still lands once the row exists.
    expect(screen.getByLabelText('Filter materials')).toHaveValue('')
    expect(screen.getByTitle('Mat 3')).toBeInTheDocument()
    expect(Element.prototype.scrollIntoView).toHaveBeenCalledWith({ block: 'nearest' })
  })

  it('does not re-trigger the scroll on a re-render where the selection did not actually change', () => {
    const scene = makeScene({
      material_ids: () => new BigUint64Array([1n]),
      material_info: () => ({ r: () => 0, g: () => 0, b: () => 0, a: () => 255, name: () => 'Mat', has_texture: () => false }),
    })
    const { rerender } = render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={1n} docRev={0} />)
    ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

    // An unrelated doc-change re-render (docRev bump) with the SAME selected
    // material must not yank the scroll position.
    rerender(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={1n} docRev={1} />)

    expect(Element.prototype.scrollIntoView).not.toHaveBeenCalled()
  })

  it('opacity slider is disabled when the Default swatch is selected', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    expect(screen.getByRole('slider')).toBeDisabled()
  })

  it('opacity slider reflects the selected material\'s current alpha', () => {
    const mockInfo = {
      r: () => 255,
      g: () => 0,
      b: () => 0,
      a: () => 128,
      name: () => 'Glass',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={7n} />)
    const slider = screen.getByRole('slider') as HTMLInputElement
    expect(slider).not.toBeDisabled()
    expect(slider.value).toBe('128')
  })

  it('dragging the opacity slider previews without calling set_material_alpha', () => {
    const mockInfo = {
      r: () => 255,
      g: () => 0,
      b: () => 0,
      a: () => 255,
      name: () => 'Glass',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={7n} />)
    fireEvent.change(screen.getByRole('slider'), { target: { value: '64' } })
    expect(screen.getByText('25%')).toBeInTheDocument()
    expect((scene as any).set_material_alpha).not.toHaveBeenCalled()
  })

  it('releasing the opacity slider commits set_material_alpha and onAlphaCommitted once, and does not double-fire onDocumentChanged', () => {
    const mockInfo = {
      r: () => 255,
      g: () => 0,
      b: () => 0,
      a: () => 255,
      name: () => 'Glass',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    const onDocumentChanged = vi.fn()
    const onAlphaCommitted = vi.fn()
    render(
      <MaterialPalette
        {...baseProps}
        scene={scene}
        currentMaterialId={7n}
        onDocumentChanged={onDocumentChanged}
        onAlphaCommitted={onAlphaCommitted}
      />,
    )
    const slider = screen.getByRole('slider')
    fireEvent.change(slider, { target: { value: '64' } })
    fireEvent.blur(slider)
    expect((scene as any).set_material_alpha).toHaveBeenCalledTimes(1)
    expect((scene as any).set_material_alpha).toHaveBeenCalledWith(7n, 64)
    expect(onAlphaCommitted).toHaveBeenCalledTimes(1)
    // onAlphaCommitted (Viewport.syncMaterialOpacity) already cascades into
    // onDocumentChanged in the real app; MaterialPalette must not also call
    // it directly, or every commit double-bumps docRev.
    expect(onDocumentChanged).not.toHaveBeenCalled()
    // A second blur with no intervening change is not a new gesture.
    fireEvent.blur(slider)
    expect((scene as any).set_material_alpha).toHaveBeenCalledTimes(1)
  })

  it('displays 100%/0% only at the exact alpha extremes, not from rounding', () => {
    const mockInfo = {
      r: () => 255,
      g: () => 0,
      b: () => 0,
      a: () => 254,
      name: () => 'Glass',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} currentMaterialId={7n} />)
    // 254/255 rounds to 100% naively, but alpha=254 is not fully opaque.
    expect(screen.queryByText('100%')).not.toBeInTheDocument()
    expect(screen.getByText('99%')).toBeInTheDocument()
  })

  it('flushes an in-progress drag on unmount so the value is not silently lost', () => {
    const mockInfo = {
      r: () => 255,
      g: () => 0,
      b: () => 0,
      a: () => 255,
      name: () => 'Glass',
      has_texture: () => false,
    }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([7n]),
      material_info: () => mockInfo,
    })
    const { unmount } = render(
      <MaterialPalette {...baseProps} scene={scene} currentMaterialId={7n} />,
    )
    fireEvent.change(screen.getByRole('slider'), { target: { value: '64' } })
    expect((scene as any).set_material_alpha).not.toHaveBeenCalled()
    unmount()
    expect((scene as any).set_material_alpha).toHaveBeenCalledWith(7n, 64)
  })

  it('after a successful "+ Add color", focus moves to the Add-color Name input, not <body>', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    fireEvent.click(screen.getByRole('button', { name: 'Add color' }))
    const nameInput = screen.getByPlaceholderText('Name…')
    fireEvent.change(screen.getByLabelText('Choose color'), { target: { value: '#112233' } })
    fireEvent.click(screen.getByRole('button', { name: /\+ add color/i }))
    // The button that was just clicked disables itself immediately
    // (newColorHex resets to null) — focus must not be left on <body>.
    expect(document.activeElement).toBe(nameInput)
  })

  it('clicking the × to clear the filter returns focus to the filter input, not <body>', () => {
    const mockInfo = { r: () => 255, g: () => 0, b: () => 0, a: () => 255, name: () => 'Red Paint', has_texture: () => false }
    const scene = makeScene({
      material_ids: () => new BigUint64Array([1n]),
      material_info: () => mockInfo,
    })
    render(<MaterialPalette {...baseProps} scene={scene} />)
    const filterInput = screen.getByLabelText('Filter materials')
    fireEvent.change(filterInput, { target: { value: 'zzz' } })
    const clearButton = screen.getByRole('button', { name: 'Clear filter' })
    // The × button unmounts the instant the filter becomes empty — this is
    // exactly the click that would otherwise drop focus to <body>.
    fireEvent.click(clearButton)
    expect(document.activeElement).toBe(filterInput)
  })

  it('clicking the color chooser (with no prior change event) counts the #4488cc seed as chosen', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    fireEvent.click(screen.getByRole('button', { name: 'Add color' }))
    const addButton = screen.getByRole('button', { name: /\+ add color/i })
    const chooser = screen.getByLabelText('Choose color') as HTMLInputElement
    expect(addButton).toBeDisabled()
    // Native activation (mouse or keyboard) fires 'click' on the input, with
    // no accompanying 'input'/'change' event when the OS picker is cancelled
    // or the same value is re-picked — this is the real-browser edge case
    // that used to leave "+ Add color" permanently disabled.
    fireEvent.click(chooser)
    expect(addButton).not.toBeDisabled()
    expect(chooser.value.toLowerCase()).toBe('#4488cc')
  })

  it('onChange still refines the color after the click-activation seed is accepted', () => {
    const scene = makeScene()
    render(<MaterialPalette {...baseProps} scene={scene} />)
    fireEvent.click(screen.getByRole('button', { name: 'Add color' }))
    const chooser = screen.getByLabelText('Choose color')
    fireEvent.click(chooser)
    fireEvent.change(chooser, { target: { value: '#112233' } })
    fireEvent.click(screen.getByRole('button', { name: /\+ add color/i }))
    expect((scene as any).add_material).toHaveBeenCalledWith(
      expect.any(String),
      0x11,
      0x22,
      0x33,
      255,
    )
  })

  it('Enter in the Add-color Name field is a no-op until a color is chosen, and submits once one is', () => {
    const scene = makeScene()
    render(<MaterialPalette {...baseProps} scene={scene} />)
    fireEvent.click(screen.getByRole('button', { name: 'Add color' }))
    const nameInput = screen.getByPlaceholderText('Name…')
    fireEvent.change(nameInput, { target: { value: 'Sunset' } })
    fireEvent.keyDown(nameInput, { key: 'Enter' })
    expect((scene as any).add_material).not.toHaveBeenCalled()

    fireEvent.change(screen.getByLabelText('Choose color'), { target: { value: '#112233' } })
    fireEvent.keyDown(nameInput, { key: 'Enter' })
    expect((scene as any).add_material).toHaveBeenCalledWith('Sunset', 0x11, 0x22, 0x33, 255)
  })

  it('expanding "Add texture" reveals its body: name and file inputs appear', () => {
    render(<MaterialPalette {...baseProps} scene={makeScene()} />)
    const textureHeader = screen.getByRole('button', { name: 'Add texture' })
    expect(textureHeader).toHaveAttribute('aria-expanded', 'false')
    fireEvent.click(textureHeader)
    expect(textureHeader).toHaveAttribute('aria-expanded', 'true')
    expect(screen.getByPlaceholderText('Name…')).toBeInTheDocument()
    const fileInput = document.querySelector('input[type="file"]')
    expect(fileInput).not.toBeNull()
    expect(screen.getByRole('button', { name: /\+ add texture/i })).toBeInTheDocument()
  })

  it('collapsing and reopening "Add texture" keeps the pending file (shown filename stays truthful) and the add still succeeds', async () => {
    const scene = makeScene({ add_texture_material: vi.fn().mockReturnValue(9n) })
    const onMaterialCreated = vi.fn()
    render(
      <MaterialPalette {...baseProps} scene={scene} onMaterialCreated={onMaterialCreated} />,
    )
    const textureHeader = screen.getByRole('button', { name: 'Add texture' })
    fireEvent.click(textureHeader)

    const file = new File(['pixel-bytes'], 'brick.png', { type: 'image/png' })
    // jsdom's File does not implement arrayBuffer() (unlike browsers/Node's
    // own File) — handleAddTexture awaits it, so the test file needs it too.
    file.arrayBuffer = async () => new TextEncoder().encode('pixel-bytes').buffer
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement
    fireEvent.change(fileInput, { target: { files: [file] } })
    expect(screen.getByText('brick.png')).toBeInTheDocument()

    // Collapse — the whole sub-pane body (including the native file input)
    // unmounts here.
    fireEvent.click(textureHeader)
    expect(textureHeader).toHaveAttribute('aria-expanded', 'false')

    // Reopen — a brand-new native file input mounts, reset by the browser,
    // but the pending file lives in React state and must still be shown and
    // still be the one that gets added.
    fireEvent.click(textureHeader)
    expect(screen.getByText('brick.png')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: /\+ add texture/i }))
    await waitFor(() => expect((scene as any).add_texture_material).toHaveBeenCalled())
    expect(onMaterialCreated).toHaveBeenCalledWith(9n)
    expect(screen.queryByText(/choose an image file first/i)).not.toBeInTheDocument()
  })
})

// ---------------------------------------------------------------------------
// DocumentTree
// ---------------------------------------------------------------------------

const docTreeBase = {
  docRev: 0,
  docGeneration: 0,
  watertightMap: new Map<bigint, boolean>(),
  selectedIds: [] as { kind: 'object' | 'group' | 'instance' | 'sketch'; id: bigint }[],
  activeContext: [] as { kind: 'object' | 'group' | 'instance' | 'sketch'; id: bigint }[],
  sessionStack: [] as { node: { kind: 'object' | 'group' | 'instance' | 'sketch'; id: bigint }; label: string }[],
  sessionMembers: null as { kind: 'object' | 'group' | 'instance' | 'sketch'; id: bigint }[] | null,
  onSelect: vi.fn(),
  onEnterContext: vi.fn(),
  onExitContext: vi.fn(),
  onSetContextDepth: vi.fn(),
  hiddenKeys: new Set<string>(),
  onToggleHidden: vi.fn(),
  onSetHiddenMany: vi.fn(),
  onReparent: vi.fn(),
}

describe('DocumentTree', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    // jsdom does not implement scrollIntoView; polyfill so DocumentTree's
    // scroll-primary-selection-into-view effect doesn't throw.
    Element.prototype.scrollIntoView = vi.fn()
  })

  it('renders no placeholder text and no section headers for an empty scene', () => {
    render(<DocumentTree {...docTreeBase} scene={makeScene()} />)
    expect(screen.queryByText('(no solids yet)')).not.toBeInTheDocument()
    expect(screen.queryByText('(no sketches yet)')).not.toBeInTheDocument()
    expect(screen.queryByText(/^objects$/i)).not.toBeInTheDocument()
    expect(screen.queryByText(/^sketches$/i)).not.toBeInTheDocument()
  })

  it('renders "Model" breadcrumb AND the root Model row at the top level', () => {
    render(<DocumentTree {...docTreeBase} scene={makeScene()} />)
    // The breadcrumb's root crumb, plus the always-present, non-selectable
    // root Model row above the tree (design: Lane D).
    expect(screen.getAllByText('Model')).toHaveLength(2)
  })

  it('the root Model row is not selectable and its eye hides/shows everything', () => {
    const scene = makeScene({
      top_level_nodes: () => [
        { kind: 'object', id: 1n },
        { kind: 'object', id: 2n },
      ],
      object_ids: () => new BigUint64Array([1n, 2n]),
    })
    const onSelect = vi.fn()
    const onSetHiddenMany = vi.fn()
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true], [2n, true]])}
        onSelect={onSelect}
        onSetHiddenMany={onSetHiddenMany}
      />,
    )
    const modelRows = screen.getAllByText('Model')
    // Clicking the root row's own text does not select anything (it has no
    // click handler wired to onSelect at all).
    fireEvent.click(modelRows[1])
    expect(onSelect).not.toHaveBeenCalled()
    // Nothing hidden yet -> the control reads "Hide all children"; clicking
    // it hides every top-level node.
    fireEvent.click(screen.getByRole('button', { name: 'Hide all children' }))
    expect(onSetHiddenMany).toHaveBeenCalledWith(
      [{ kind: 'object', id: 1n }, { kind: 'object', id: 2n }],
      true,
    )
  })

  it('the Model row\'s "Show all children" clears every hidden descendant', () => {
    // A plain top-level object (no group) so only the Model row itself
    // renders a "show/hide all children" control — a nested group would
    // ALSO read "Show all children" once its one member is hidden,
    // ambiguating the query below.
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'object', id: 1n }],
      object_ids: () => new BigUint64Array([1n]),
    })
    const onSetHiddenMany = vi.fn()
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
        hiddenKeys={new Set(['object:1'])}
        onSetHiddenMany={onSetHiddenMany}
      />,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Show all children' }))
    expect(onSetHiddenMany).toHaveBeenCalledWith([{ kind: 'object', id: 1n }], false)
  })

  it('has no action buttons — booleans/group/component ops live in the menus now', () => {
    const scene = makeScene({
      top_level_nodes: () => [
        { kind: 'object', id: 1n },
        { kind: 'object', id: 2n },
      ],
      object_ids: () => new BigUint64Array([1n, 2n]),
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true], [2n, true]])}
        selectedIds={[
          { kind: 'object', id: 1n },
          { kind: 'object', id: 2n },
        ]}
      />,
    )
    for (const label of [/union/i, /subtract/i, /intersect/i, /^group$/i, /ungroup/i, /make component/i, /place copy/i, /explode/i, /make unique/i]) {
      expect(screen.queryByRole('button', { name: label })).not.toBeInTheDocument()
    }
  })

  it('auto-expands the ancestor groups of EVERY selected node, not just the primary', () => {
    // Two collapsed top-level groups, each holding one instance of the same
    // definition. Selecting both instances (the "(N instances)" click) must
    // reveal both rows — walking only selectedIds[0]'s ancestor chain leaves
    // the second group collapsed and its instance invisible.
    const scene = makeScene({
      top_level_nodes: () => [
        { kind: 'group', id: 20n },
        { kind: 'group', id: 21n },
      ],
      group_members: (id: bigint) =>
        id === 20n
          ? [{ kind: 'instance', id: 4n }]
          : id === 21n
            ? [{ kind: 'instance', id: 5n }]
            : [],
      node_parent: (kind: number, id: bigint) => {
        if (kind === 2) return id === 4n ? 20n : 21n
        return undefined // groups are top-level
      },
      instance_name: () => undefined,
      instance_def: () => 9n,
      component_name: () => 'Door',
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        selectedIds={[
          { kind: 'instance', id: 4n },
          { kind: 'instance', id: 5n },
        ]}
      />,
    )
    // Both instance rows are visible: each group in the union of the
    // selection's ancestor chains auto-expanded.
    expect(screen.getAllByText('Door')).toHaveLength(2)
  })

  it('renders an object row using its positional label when unnamed', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'object', id: 1n }],
      object_ids: () => new BigUint64Array([1n]),
      object_name: () => undefined,
      node_parent: () => undefined,
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
      />,
    )
    // resolveLabel(undefined, undefined, 'object', 0) → "Object 1"
    expect(screen.getByText('Object 1')).toBeInTheDocument()
  })

  it('uses the kernel name when the object has one', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'object', id: 1n }],
      object_ids: () => new BigUint64Array([1n]),
      object_name: () => 'Bridge Arch',
      node_parent: () => undefined,
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
      />,
    )
    expect(screen.getByText('Bridge Arch')).toBeInTheDocument()
  })

  it('rows use the UI font, not monospace', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'object', id: 1n }],
      object_ids: () => new BigUint64Array([1n]),
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
      />,
    )
    const row = screen.getByText('Object 1').closest('div') as HTMLElement
    expect(row.style.fontFamily).toBe('var(--font-family-ui)')
  })

  it('calls onSelect with the node ref when an object row is clicked', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'object', id: 1n }],
      object_ids: () => new BigUint64Array([1n]),
      object_name: () => 'Cube',
      node_parent: () => undefined,
    })
    const onSelect = vi.fn()
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
        onSelect={onSelect}
      />,
    )
    fireEvent.click(screen.getByText('Cube'))
    expect(onSelect).toHaveBeenCalledWith({ kind: 'object', id: 1n }, false)
  })

  it('renders sketches as rows in the same unified list and selects them on click', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'object', id: 1n }],
      object_ids: () => new BigUint64Array([1n]),
      sketch_ids: () => new BigUint64Array([5n]),
      sketch_plane: () => new Float64Array([0, 0, 0, 0, 0, 1]),
      plane_units_json: () => JSON.stringify(freeShapeListing(105)),
    })
    const onSelect = vi.fn()
    const { container } = render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
        onSelect={onSelect}
      />,
    )
    // Object and sketch rows share one list container (no section wrappers).
    const objectRow = screen.getByText('Object 1').closest('div')?.parentElement
    const sketchRow = screen.getByText('Sketch 1').closest('div')?.parentElement
    expect(objectRow).toBe(sketchRow)
    expect(container.querySelector('[data-node-icon="sketch"]')).not.toBeNull()
    fireEvent.click(screen.getByText('Sketch 1'))
    // Rows are SHAPES (draft-island) — the connected-shape unit — carrying
    // their plane context and the kernel's unit key.
    expect(onSelect).toHaveBeenCalledWith(draftOf('draft-island', GROUND_CTX, 105), false)
  })

  it('highlights the sketch row selected from the canvas (canvas → tree)', () => {
    const scene = makeScene({
      sketch_ids: () => new BigUint64Array([5n]),
      sketch_plane: () => new Float64Array([0, 0, 0, 0, 0, 1]),
      plane_units_json: () => JSON.stringify(freeShapeListing(105)),
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        selectedIds={[draftOf('draft-island', GROUND_CTX, 105)]}
      />,
    )
    const row = screen.getByText('Sketch 1').closest('div')
    // The primary-selection tint is applied via inline style — assert it isn't
    // the default transparent background a non-selected row would get.
    expect(row).toHaveStyle({ background: 'var(--accent-tint-18)' })
  })

  it('renders distinct type icons: solid object, leaky object, group, instance', () => {
    const scene = makeScene({
      top_level_nodes: () => [
        { kind: 'object', id: 1n },
        { kind: 'object', id: 2n },
        { kind: 'group', id: 3n },
        { kind: 'instance', id: 4n },
      ],
      object_ids: () => new BigUint64Array([1n, 2n]),
      group_ids: () => new BigUint64Array([3n]),
      instance_ids: () => new BigUint64Array([4n]),
    })
    const { container } = render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true], [2n, false]])}
      />,
    )
    expect(container.querySelector('[data-node-icon="object-solid"]')).not.toBeNull()
    expect(container.querySelector('[data-node-icon="object-leaky"]')).not.toBeNull()
    expect(container.querySelector('[data-node-icon="group"]')).not.toBeNull()
    expect(container.querySelector('[data-node-icon="instance"]')).not.toBeNull()
    // The leaky state is carried by a dashed outline on the object icon.
    const leaky = container.querySelector('[data-node-icon="object-leaky"] path')
    expect(leaky?.getAttribute('stroke-dasharray')).toBeTruthy()
    const solid = container.querySelector('[data-node-icon="object-solid"] path')
    expect(solid?.getAttribute('stroke-dasharray')).toBeNull()
  })

  it('Model Health state picks the object icon: surface (no dash), open (dashed), solid by default', () => {
    const scene = makeScene({
      top_level_nodes: () => [
        { kind: 'object', id: 1n },
        { kind: 'object', id: 2n },
        { kind: 'object', id: 3n },
      ],
      object_ids: () => new BigUint64Array([1n, 2n, 3n]),
    })
    const { container } = render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true], [2n, false], [3n, false]])}
        objectHealth={new Map<bigint, 'surface' | 'open'>([[2n, 'surface'], [3n, 'open']])}
      />,
    )
    expect(container.querySelectorAll('[data-node-icon="object-solid"]')).toHaveLength(1)
    expect(container.querySelectorAll('[data-node-icon="object-surface"]')).toHaveLength(1)
    expect(container.querySelectorAll('[data-node-icon="object-leaky"]')).toHaveLength(1)
    // A surface is a thin outline with no dash, in a neutral color.
    const surface = container.querySelector('[data-node-icon="object-surface"]')
    expect(surface?.querySelector('path')?.getAttribute('stroke-dasharray')).toBeNull()
    expect(surface).toHaveStyle({ color: 'var(--text-muted)' })
    expect(container.querySelector('[data-node-icon="object-leaky"] title')?.textContent).toBe('Open shape: not solid')
    expect(container.querySelector('[data-node-icon="object-surface"] title')?.textContent).toBe('Flat panel or curved sheet')
  })

  it('nested groups start collapsed; clicking the chevron expands them', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'group', id: 10n }],
      group_ids: () => new BigUint64Array([10n]),
      object_ids: () => new BigUint64Array([1n]),
      group_members: (id: bigint) => (id === 10n ? [{ kind: 'object', id: 1n }] : []),
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
      />,
    )
    // Collapsed by default: the member row is not mounted.
    expect(screen.queryByText('Object 1')).not.toBeInTheDocument()
    fireEvent.click(screen.getByText('▸'))
    expect(screen.getByText('Object 1')).toBeInTheDocument()
  })

  it('auto-expands the group ancestors of the primary selection', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'group', id: 10n }],
      group_ids: () => new BigUint64Array([10n]),
      object_ids: () => new BigUint64Array([1n]),
      group_members: (id: bigint) => (id === 10n ? [{ kind: 'object', id: 1n }] : []),
      node_parent: (kind: number, id: bigint) =>
        kind === 0 && id === 1n ? 10n : undefined,
    })
    render(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        watertightMap={new Map([[1n, true]])}
        selectedIds={[{ kind: 'object', id: 1n }]}
      />,
    )
    // The selected object lives inside the (default-collapsed) group — its
    // ancestor chain is force-expanded so the selection is visible.
    expect(screen.getByText('Object 1')).toBeInTheDocument()
  })

  // -------------------------------------------------------------------------
  // Explode session presentation (playtest: loose "Object N" rows with no
  // indication of what they belonged to, while the instance rows that used
  // to explain them vanished). While a session is open, the session's
  // members must be grouped under one labeled, "editing"-marked header for
  // the definition instead of appearing as unexplained top-level rows.
  // -------------------------------------------------------------------------

  describe('session (component or group)', () => {
    it('groups the session members under a frame header instead of loose top-level rows', () => {
      const scene = makeScene({
        top_level_nodes: () => [
          { kind: 'object', id: 1n },
          { kind: 'object', id: 2n },
        ],
        object_ids: () => new BigUint64Array([1n, 2n]),
      })
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true], [2n, true]])}
          sessionStack={[{ node: { kind: 'instance', id: 9n }, label: 'Box Def' }]}
          sessionMembers={[{ kind: 'object', id: 1n }, { kind: 'object', id: 2n }]}
        />,
      )
      // The frame header is labeled with the caller-supplied label and
      // carries the same "editing" chip an active context row uses. "Box
      // Def" appears twice: once as the breadcrumb crumb (design: every
      // session frame gets a crumb now), once as the tree header row.
      expect(screen.getAllByText('Box Def')).toHaveLength(2)
      expect(screen.getByText('editing')).toBeInTheDocument()
      // Members are nested underneath — and appear exactly once each, not
      // also as loose top-level rows (the playtest's duplicate-row bug).
      expect(screen.getAllByText('Object 1')).toHaveLength(1)
      expect(screen.getAllByText('Object 2')).toHaveLength(1)
    })

    it('keeps positional labels stable and unique across a mixed session/non-session set', () => {
      // Three unnamed top-level objects; the 1st and 3rd (ids 1, 3) are the
      // session's members, the 2nd (id 2) is unrelated. Nested members must
      // keep their TOP-LEVEL positional labels (Object 1 / Object 3) so the
      // surviving top-level row (Object 2) never shares a label with a
      // nested one, and no object is relabeled by the session opening
      // (delta-review finding: a fresh 0-based nested sequence rendered two
      // different objects both as "Object 2").
      const scene = makeScene({
        top_level_nodes: () => [
          { kind: 'object', id: 1n },
          { kind: 'object', id: 2n },
          { kind: 'object', id: 3n },
        ],
        object_ids: () => new BigUint64Array([1n, 2n, 3n]),
      })
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true], [2n, true], [3n, true]])}
          sessionStack={[{ node: { kind: 'instance', id: 9n }, label: 'Box Def' }]}
          sessionMembers={[{ kind: 'object', id: 1n }, { kind: 'object', id: 3n }]}
        />,
      )
      expect(screen.getAllByText('Object 1')).toHaveLength(1)
      expect(screen.getAllByText('Object 2')).toHaveLength(1)
      expect(screen.getAllByText('Object 3')).toHaveLength(1)
    })

    it('lets a session member row be clicked like any normal object row', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
        object_name: () => 'Panel',
      })
      const onSelect = vi.fn()
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'instance', id: 9n }, label: 'Box Def' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
          onSelect={onSelect}
        />,
      )
      fireEvent.click(screen.getByText('Panel'))
      expect(onSelect).toHaveBeenCalledWith({ kind: 'object', id: 1n }, false)
    })

    it('reflects mid-session object creation under the frame header (derived per docRev, not once)', () => {
      const ids: bigint[] = [1n]
      const sessionIds: bigint[] = [1n]
      const scene = makeScene({
        top_level_nodes: () => ids.map((id) => ({ kind: 'object', id })),
        object_ids: () => new BigUint64Array(ids),
      })
      const { rerender } = render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          docRev={0}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'instance', id: 9n }, label: 'Box Def' }]}
          sessionMembers={sessionIds.map((id) => ({ kind: 'object' as const, id }))}
        />,
      )
      expect(screen.getAllByText('Object 1')).toHaveLength(1)
      expect(screen.queryByText('Object 2')).not.toBeInTheDocument()

      // Simulate a new object created mid-session (e.g. Push/Pull splitting a
      // face): it joins both the document's top-level nodes AND the session's
      // live member list (the parent re-reads `ViewportApi.sessionMembers()`
      // whenever docRev changes — this rerender mirrors that).
      ids.push(2n)
      sessionIds.push(2n)
      rerender(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          docRev={1}
          watertightMap={new Map([[1n, true], [2n, true]])}
          sessionStack={[{ node: { kind: 'instance', id: 9n }, label: 'Box Def' }]}
          sessionMembers={sessionIds.map((id) => ({ kind: 'object' as const, id }))}
        />,
      )
      expect(screen.getAllByText('Object 2')).toHaveLength(1)
    })

    it('reverts to plain top-level rows once the session closes', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
      })
      const { rerender } = render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          docRev={0}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'instance', id: 9n }, label: 'Box Def' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      expect(screen.getAllByText('Box Def')).toHaveLength(2) // breadcrumb crumb + header row
      expect(screen.getByText('editing')).toBeInTheDocument()

      rerender(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          docRev={1}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[]}
          sessionMembers={null}
        />,
      )
      expect(screen.queryByText('Box Def')).not.toBeInTheDocument()
      expect(screen.queryByText('editing')).not.toBeInTheDocument()
      expect(screen.getAllByText('Object 1')).toHaveLength(1)
    })

    it('opens a GROUP session with a "Group N" fallback label and no chip duplication', () => {
      const scene = makeScene({
        top_level_nodes: () => [
          { kind: 'object', id: 1n },
          { kind: 'object', id: 2n },
        ],
        object_ids: () => new BigUint64Array([1n, 2n]),
      })
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true], [2n, true]])}
          sessionStack={[{ node: { kind: 'group', id: 20n }, label: 'Group 1' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      expect(screen.getAllByText('Group 1')).toHaveLength(2) // breadcrumb crumb + header row
      expect(screen.getAllByText('editing')).toHaveLength(1)
      // Object 1 is the group's member (nested); Object 2 is an unrelated
      // top-level sibling and still renders as its own loose row.
      expect(screen.getAllByText('Object 1')).toHaveLength(1)
      expect(screen.getAllByText('Object 2')).toHaveLength(1)
    })

    it('gives every frame on a nested session stack its own header + editing chip', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
      })
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[
            { node: { kind: 'group', id: 20n }, label: 'Outer Group' },
            { node: { kind: 'group', id: 21n }, label: 'Inner Group' },
          ]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      // Each label appears twice: once as its own breadcrumb crumb (design:
      // every session frame gets a crumb), once as its tree header row.
      expect(screen.getAllByText('Outer Group')).toHaveLength(2)
      expect(screen.getAllByText('Inner Group')).toHaveLength(2)
      // Both frame headers get the chip, not just the innermost.
      expect(screen.getAllByText('editing')).toHaveLength(2)
      // The breadcrumb reflects both frames, outermost first (plus the
      // root Model row itself, always present above the tree).
      expect(screen.getAllByText('Model')).toHaveLength(2)
    })

    // -----------------------------------------------------------------------
    // Scroll-follow (playtest: entering a component re-roots the tree, but
    // the scroll position stays where the old row was, stranding the user
    // far from the re-rooted content). The Outliner must scroll the row for
    // whatever just became relevant into view: the new frame's header on
    // open (including drilling one level deeper), the closed node's restored
    // row on close.
    // -----------------------------------------------------------------------

    it('scrolls the newly-opened frame\'s header row into view when a session opens', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }, { kind: 'group', id: 20n }],
        object_ids: () => new BigUint64Array([1n]),
        group_ids: () => new BigUint64Array([20n]),
        group_members: (id: bigint) => (id === 20n ? [{ kind: 'object', id: 2n }] : []),
      })
      const { rerender } = render(
        <DocumentTree {...docTreeBase} scene={scene} watertightMap={new Map([[1n, true]])} />,
      )
      ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

      // Double-click "Group 1" to open its session — the frame header row
      // (the "editing" row, always mounted even before its member list
      // settles) should be scrolled into view.
      rerender(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'group', id: 20n }, label: 'Group 1' }]}
          sessionMembers={[{ kind: 'object', id: 2n }]}
        />,
      )
      expect(Element.prototype.scrollIntoView).toHaveBeenCalledWith({ block: 'nearest' })
    })

    it('drilling one level deeper (a second stacked frame) also scrolls to the new frame\'s header', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
      })
      const { rerender } = render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'group', id: 20n }, label: 'Outer Group' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

      // A nested group inside the outer session opens its own frame — the
      // stack grows by one, same shape as opening the first frame.
      rerender(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[
            { node: { kind: 'group', id: 20n }, label: 'Outer Group' },
            { node: { kind: 'group', id: 21n }, label: 'Inner Group' },
          ]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      expect(Element.prototype.scrollIntoView).toHaveBeenCalledWith({ block: 'nearest' })
    })

    it('scrolls the closed node\'s row back into view once a session closes', () => {
      // The scene models the kernel's session-hide/reveal posture: while the
      // session is open, "Group 1" is hidden and its member is a bare
      // top-level row; once closed, the group reappears at top level holding
      // that member.
      let sessionOpen = true
      const scene = makeScene({
        top_level_nodes: () =>
          sessionOpen ? [{ kind: 'object', id: 1n }] : [{ kind: 'group', id: 20n }],
        group_members: (id: bigint) => (id === 20n ? [{ kind: 'object', id: 1n }] : []),
        object_ids: () => new BigUint64Array([1n]),
        group_ids: () => new BigUint64Array([20n]),
      })
      const { rerender } = render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'group', id: 20n }, label: 'Group 1' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

      sessionOpen = false
      rerender(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          // `topNodes` memoizes on `[scene, docRev]` — bump docRev so the
          // (same-identity) `scene`'s `top_level_nodes()` is re-queried and
          // picks up `sessionOpen` flipping, mirroring how a real close
          // arrives bundled with a docRev bump from App.tsx.
          docRev={1}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[]}
          sessionMembers={null}
        />,
      )
      // "Group 1" is back as a single ordinary row (no more breadcrumb crumb
      // duplicate) at its original position, and got scrolled into view.
      expect(screen.getAllByText('Group 1')).toHaveLength(1)
      expect(Element.prototype.scrollIntoView).toHaveBeenCalledWith({ block: 'nearest' })
    })

    it('does not re-trigger the session-reveal scroll on a re-render where the stack did not change', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
      })
      const { rerender } = render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'group', id: 20n }, label: 'Group 1' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      ;(Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>).mockClear()

      // An unrelated re-render (docRev bump) with a FRESH array carrying the
      // same session-stack contents — App.tsx hands down a new array
      // reference on every render, so this must be compared by content, not
      // identity — must not yank the scroll position.
      rerender(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          docRev={1}
          watertightMap={new Map([[1n, true]])}
          sessionStack={[{ node: { kind: 'group', id: 20n }, label: 'Group 1' }]}
          sessionMembers={[{ kind: 'object', id: 1n }]}
        />,
      )
      expect(Element.prototype.scrollIntoView).not.toHaveBeenCalled()
    })
  })

  // ---------------------------------------------------------------------
  // Filter (Lane D)
  // ---------------------------------------------------------------------
  describe('filter', () => {
    it('shows only matches and their ancestors, force-expanding collapsed ancestors', () => {
      const scene = makeScene({
        top_level_nodes: () => [
          { kind: 'group', id: 10n },
          { kind: 'object', id: 2n },
        ],
        group_ids: () => new BigUint64Array([10n]),
        object_ids: () => new BigUint64Array([1n, 2n]),
        group_members: (id: bigint) => (id === 10n ? [{ kind: 'object', id: 1n }] : []),
        object_name: (id: bigint) => (id === 1n ? 'Bridge Arch' : undefined),
        group_name: () => undefined,
      })
      render(<DocumentTree {...docTreeBase} scene={scene} watertightMap={new Map([[1n, true], [2n, true]])} />)
      // Before filtering: the group is collapsed, so "Bridge Arch" isn't
      // rendered yet, and the unrelated top-level object (position 1 -> "Object 2") is visible.
      expect(screen.queryByText('Bridge Arch')).not.toBeInTheDocument()
      expect(screen.getByText('Object 2')).toBeInTheDocument()
      fireEvent.change(screen.getByLabelText('Filter outliner'), { target: { value: 'bridge' } })
      // The match's ancestor group force-expands, revealing it...
      expect(screen.getByText('Bridge Arch')).toBeInTheDocument()
      // ...and the non-matching sibling object is hidden.
      expect(screen.queryByText('Object 2')).not.toBeInTheDocument()
    })

    it('shows "No objects match" for an empty result and restores everything on clear', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
      })
      render(<DocumentTree {...docTreeBase} scene={scene} watertightMap={new Map([[1n, true]])} />)
      fireEvent.change(screen.getByLabelText('Filter outliner'), { target: { value: 'nonexistent' } })
      expect(screen.getByText('No objects match')).toBeInTheDocument()
      expect(screen.queryByText('Object 1')).not.toBeInTheDocument()
      fireEvent.click(screen.getByLabelText('Clear filter'))
      expect(screen.queryByText('No objects match')).not.toBeInTheDocument()
      expect(screen.getByText('Object 1')).toBeInTheDocument()
    })

    it('does not clear the selection when a filter hides the selected row', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'object', id: 1n }],
        object_ids: () => new BigUint64Array([1n]),
      })
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          selectedIds={[{ kind: 'object', id: 1n }]}
        />,
      )
      fireEvent.change(screen.getByLabelText('Filter outliner'), { target: { value: 'nothing matches this' } })
      // The row is gone from the DOM, but nothing in DocumentTree ever
      // calls onSelect([]) or otherwise clears the caller's selection.
      expect(docTreeBase.onSelect).not.toHaveBeenCalled()
    })
  })

  // ---------------------------------------------------------------------
  // Per-container "hide/show all children" control + eye rendering fix
  // ---------------------------------------------------------------------
  describe('hide/show all children', () => {
    it('a group with no hidden members reads "Hide all children" and hides every direct child', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'group', id: 10n }],
        group_ids: () => new BigUint64Array([10n]),
        object_ids: () => new BigUint64Array([1n, 2n]),
        group_members: (id: bigint) =>
          id === 10n ? [{ kind: 'object', id: 1n }, { kind: 'object', id: 2n }] : [],
      })
      const onSetHiddenMany = vi.fn()
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true], [2n, true]])}
          onSetHiddenMany={onSetHiddenMany}
        />,
      )
      // Scoped to the group's own row: the Model row ABOVE it reads "Hide
      // all children" too (nothing anywhere is hidden yet).
      const groupRow = screen.getByText('Group 1').closest('div') as HTMLElement
      fireEvent.click(within(groupRow).getByRole('button', { name: 'Hide all children' }))
      expect(onSetHiddenMany).toHaveBeenCalledWith(
        [{ kind: 'object', id: 1n }, { kind: 'object', id: 2n }],
        true,
      )
    })

    it('a group with ANY hidden descendant (including a hidden grandchild) reads "Show all children" and clears every one', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'group', id: 10n }],
        group_ids: () => new BigUint64Array([10n, 11n]),
        object_ids: () => new BigUint64Array([1n]),
        group_members: (id: bigint) =>
          id === 10n ? [{ kind: 'group', id: 11n }] : id === 11n ? [{ kind: 'object', id: 1n }] : [],
      })
      const onSetHiddenMany = vi.fn()
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          // The grandchild (object 1), two levels down, is individually hidden.
          hiddenKeys={new Set(['object:1'])}
          onSetHiddenMany={onSetHiddenMany}
        />,
      )
      // Scoped to the outer group's own row (id 10n) — the Model row above
      // it, and the nested group's own row, both also read "Show all
      // children" here since something is hidden everywhere in this tree.
      const groupRow = screen.getByText('Group 1').closest('div') as HTMLElement
      fireEvent.click(within(groupRow).getByRole('button', { name: 'Show all children' }))
      // Clears the container's own key, the hidden grandchild, AND every
      // descendant key in between — not just the direct child (the nested
      // group).
      expect(onSetHiddenMany).toHaveBeenCalledWith(
        [{ kind: 'group', id: 10n }, { kind: 'group', id: 11n }, { kind: 'object', id: 1n }],
        false,
      )
    })

    it('a child of a hidden group renders its eye as hidden-by-parent, dimmer than a directly-hidden row', () => {
      const scene = makeScene({
        top_level_nodes: () => [{ kind: 'group', id: 10n }],
        group_ids: () => new BigUint64Array([10n]),
        object_ids: () => new BigUint64Array([1n]),
        group_members: (id: bigint) => (id === 10n ? [{ kind: 'object', id: 1n }] : []),
        node_parent: (kind: number, id: bigint) => (kind === 0 && id === 1n ? 10n : undefined),
      })
      render(
        <DocumentTree
          {...docTreeBase}
          scene={scene}
          watertightMap={new Map([[1n, true]])}
          // The GROUP is hidden by its own key; the object inside carries
          // no key of its own.
          hiddenKeys={new Set(['group:10'])}
        />,
      )
      // The group auto-expands (ancestor-of-nothing here, so force it via
      // the chevron) to reach the child row.
      fireEvent.click(screen.getByText('▸'))
      const objectRow = screen.getByText('Object 1').closest('div') as HTMLElement
      const eye = objectRow.querySelector('button[title="Show"]') as HTMLElement
      expect(eye).not.toBeNull()
      expect(eye.style.opacity).toBe('0.55')
    })
  })

  // ---------------------------------------------------------------------
  // Expand state reset on a new document (adversarial review finding 1)
  // ---------------------------------------------------------------------
  it('resets expand/collapse state on a docGeneration bump — a stale key must not alias an unrelated node in the next document', () => {
    const scene = makeScene({
      top_level_nodes: () => [{ kind: 'group', id: 10n }],
      group_ids: () => new BigUint64Array([10n]),
      object_ids: () => new BigUint64Array([1n]),
      group_members: (id: bigint) => (id === 10n ? [{ kind: 'object', id: 1n }] : []),
    })
    const { rerender } = render(
      <DocumentTree {...docTreeBase} scene={scene} watertightMap={new Map([[1n, true]])} />,
    )
    // Manually expand the group.
    fireEvent.click(screen.getByText('▸'))
    expect(screen.getByText('Object 1')).toBeInTheDocument()

    // A new document loads (File ▸ New / Open — App.tsx bumps docGeneration).
    // Handles are dense and generational PER DOCUMENT, so the fresh
    // document's group can coincidentally reuse the exact same raw id
    // (10n) the previous document's expanded group had — it must start
    // collapsed regardless, not inherit the stale `group:10` expand key.
    rerender(
      <DocumentTree
        {...docTreeBase}
        scene={scene}
        docGeneration={1}
        watertightMap={new Map([[1n, true]])}
      />,
    )
    expect(screen.queryByText('Object 1')).not.toBeInTheDocument()
  })
})

// ---------------------------------------------------------------------------
// TagsPanel
// ---------------------------------------------------------------------------

describe('TagsPanel', () => {
  const baseTagProps = {
    docRev: 0,
    hiddenTagPaths: new Set<string>(),
    onToggleTagPath: vi.fn(),
    onDeleteTag: vi.fn(),
  }

  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders nothing at all when the scene has no tagged objects', () => {
    const { container } = render(<TagsPanel {...baseTagProps} scene={makeScene()} />)
    expect(container.firstChild).toBeNull()
    expect(screen.queryByText(/no tags found/i)).not.toBeInTheDocument()
    expect(screen.queryByText(/hew_export_tags/i)).not.toBeInTheDocument()
  })

  it('clicking a tag row selects every item carrying it or a nested tag; the eye/delete buttons do not', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n, 2n, 3n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Hardware'] : id === 2n ? ['Hardware/Screws'] : ['Oak']),
    })
    const onSelectNodes = vi.fn()
    render(<TagsPanel {...baseTagProps} scene={scene} onSelectNodes={onSelectNodes} />)
    fireEvent.click(screen.getByText('Hardware'))
    expect(onSelectNodes).toHaveBeenCalledTimes(1)
    const picked = (onSelectNodes.mock.calls[0][0] as { id: bigint }[]).map((n) => n.id).sort()
    expect(picked).toEqual([1n, 2n])
    // The row is now the active (highlighted) one.
    expect(screen.getAllByTestId('tag-row').find((r) => r.textContent?.includes('Hardware'))).toHaveAttribute('data-active', 'true')
    // Eye / delete are their own controls: no selection change.
    fireEvent.click(screen.getAllByTitle('Hide tagged objects')[0])
    fireEvent.click(screen.getByRole('button', { name: 'Delete tag Oak' }))
    expect(onSelectNodes).toHaveBeenCalledTimes(1)
  })

  it('double-click renames a tag in place (last segment); Enter commits, a refusal shows inline, Escape cancels', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Hardware/Screws'] : []),
    })
    const onRenameTag = vi.fn((path: string[], next: string) => (next === 'Taken' ? 'A tag with that name already exists.' : null))
    render(<TagsPanel {...baseTagProps} scene={scene} onRenameTag={onRenameTag} />)
    fireEvent.doubleClick(screen.getByText('Screws'))
    const input = screen.getByRole('textbox', { name: 'Tag name' })
    expect((input as HTMLInputElement).value).toBe('Screws')
    fireEvent.change(input, { target: { value: 'Taken' } })
    fireEvent.keyDown(input, { key: 'Enter' })
    expect(onRenameTag).toHaveBeenCalledWith(['Hardware', 'Screws'], 'Taken')
    expect(screen.getByText('A tag with that name already exists.')).toBeInTheDocument()
    expect(screen.getByRole('textbox', { name: 'Tag name' })).toBeInTheDocument()
    fireEvent.change(input, { target: { value: 'Bolts' } })
    fireEvent.keyDown(input, { key: 'Enter' })
    expect(onRenameTag).toHaveBeenLastCalledWith(['Hardware', 'Screws'], 'Bolts')
    expect(screen.queryByRole('textbox', { name: 'Tag name' })).not.toBeInTheDocument()
    // Escape cancels without a call.
    fireEvent.doubleClick(screen.getByText('Screws'))
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Tag name' }), { key: 'Escape' })
    expect(onRenameTag).toHaveBeenCalledTimes(2)
    expect(screen.queryByRole('textbox', { name: 'Tag name' })).not.toBeInTheDocument()
  })

  it('a slow second click on the active row opens rename; a fast one does not', () => {
    vi.useFakeTimers({ toFake: ['Date'] })
    try {
      const scene = makeScene({
        object_ids: () => new BigUint64Array([1n]),
        node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Hardware'] : []),
      })
      const onRenameTag = vi.fn(() => null)
      render(<TagsPanel {...baseTagProps} scene={scene} onSelectNodes={vi.fn()} onRenameTag={onRenameTag} />)
      fireEvent.click(screen.getByText('Hardware'))
      vi.advanceTimersByTime(100)
      fireEvent.click(screen.getByText('Hardware'))
      expect(screen.queryByRole('textbox', { name: 'Tag name' })).not.toBeInTheDocument()
      vi.advanceTimersByTime(600)
      fireEvent.click(screen.getByText('Hardware'))
      expect(screen.getByRole('textbox', { name: 'Tag name' })).toBeInTheDocument()
    } finally {
      vi.useRealTimers()
    }
  })

  it('renders the root tag segment from node_tags', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Structure/Roof'] : []),
    })
    render(<TagsPanel {...baseTagProps} scene={scene} />)
    // buildTagTree builds "Structure" root with "Roof" child.
    // The root row renders node.segment = "Structure".
    expect(screen.getByText('Structure')).toBeInTheDocument()
  })

  it('calls onToggleTagPath with the tag path when the eye button is clicked', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Walls'] : []),
    })
    const onToggleTagPath = vi.fn()
    render(
      <TagsPanel
        {...baseTagProps}
        scene={scene}
        onToggleTagPath={onToggleTagPath}
      />,
    )
    fireEvent.click(screen.getAllByTitle('Hide tagged objects')[0])
    expect(onToggleTagPath).toHaveBeenCalledWith(['Walls'])
  })

  it('shows "Show tagged objects" title when the path is hidden', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Walls'] : []),
    })
    // tagPathKey(['Walls']) = JSON.stringify(['Walls']) = '["Walls"]'
    render(
      <TagsPanel
        {...baseTagProps}
        scene={scene}
        hiddenTagPaths={new Set(['["Walls"]'])}
      />,
    )
    expect(screen.getByTitle('Show tagged objects')).toBeInTheDocument()
  })

  it('renders nested child tags', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) =>
        id === 1n ? ['Structure/Roof'] : [],
    })
    render(<TagsPanel {...baseTagProps} scene={scene} />)
    // "Roof" is a child of "Structure" — both should appear in the expanded tree
    expect(screen.getByText('Roof')).toBeInTheDocument()
  })

  it('shows a registry tag path even when no node carries it (e.g. an empty imported .skp layer)', () => {
    const scene = makeScene({
      // No node is tagged at all — the tag only exists in the registry.
      tag_meta_paths: () => ['Imported/EmptyLayer'],
      tag_meta_hidden: () => new Uint8Array([0]),
    })
    render(<TagsPanel {...baseTagProps} scene={scene} />)
    expect(screen.queryByText(/no tags found/i)).not.toBeInTheDocument()
    expect(screen.getByText('Imported')).toBeInTheDocument()
    expect(screen.getByText('EmptyLayer')).toBeInTheDocument()
  })

  it('unions registry tags with node-derived tags rather than replacing them', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Walls'] : []),
      tag_meta_paths: () => ['Walls', 'EmptyLayer'],
      tag_meta_hidden: () => new Uint8Array([0, 0]),
    })
    render(<TagsPanel {...baseTagProps} scene={scene} />)
    expect(screen.getByText('Walls')).toBeInTheDocument()
    expect(screen.getByText('EmptyLayer')).toBeInTheDocument()
  })

  it('rows use the UI font, not monospace', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) => (id === 1n ? ['Walls'] : []),
    })
    render(<TagsPanel {...baseTagProps} scene={scene} />)
    const row = screen.getByText('Walls').closest('div') as HTMLElement
    expect(row.style.fontFamily).toContain('--font-family-ui')
    expect(row.style.fontFamily).not.toBe('monospace')
  })

  it('revealTag re-expands collapsed ancestors and highlights the target row', () => {
    const scene = makeScene({
      object_ids: () => new BigUint64Array([1n]),
      node_tags: (_kind: number, id: bigint) =>
        id === 1n ? ['Structure/Roof'] : [],
    })
    const { rerender } = render(<TagsPanel {...baseTagProps} scene={scene} />)
    // Collapse "Structure" so "Roof" disappears.
    fireEvent.click(screen.getByText('▾'))
    expect(screen.queryByText('Roof')).not.toBeInTheDocument()
    // A palette jump to Structure/Roof pops it back open and flags the row.
    rerender(
      <TagsPanel
        {...baseTagProps}
        scene={scene}
        revealTag={{ key: JSON.stringify(['Structure', 'Roof']), nonce: 1 }}
      />,
    )
    const roof = screen.getByText('Roof')
    expect(roof).toBeInTheDocument()
    const row = roof.closest('div') as HTMLElement
    expect(row.style.background).toContain('accent-tint-18')
    // Sibling/ancestor rows are not highlighted.
    const structureRow = screen.getByText('Structure').closest('div') as HTMLElement
    expect(structureRow.style.background).not.toContain('accent-tint-18')
  })
})

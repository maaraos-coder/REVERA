/**
 * ContextualDock — the bottom-center contextual verb bar (
 * `05_contextual_dock.md`, rescoped — see `dockLogic.ts`'s doc comment for
 * why Face/Edge/Component became Object/Group/Instance/Empty/Multi).
 *
 * Reuses the exact same `menuActionRef.current(id)` dispatch the command
 * palette and every menu item already go through — this component
 * owns no execution logic, only layout + the context->verbs derivation in
 * `dockLogic.ts`.
 *
 * Still deferred from the spec (M24 scope decision, not silently dropped):
 * the trailing "more actions" overflow affordance (would open the right-click
 * context menu, which isn't a reusable component yet). The two
 * deferrals M24 landed: context swaps cross-fade (the container is
 * keyed on the context, so a swap remounts it and replays the `.hew-dock`
 * animation, ~140ms, spec's "quick cross-fade... rather than a hard cut"),
 * and the dock fades out while the camera is being pointer-dragged (a
 * `hidden` prop, fed by Viewport.tsx's onCameraDragChange, riding the same
 * `.hew-dock` opacity transition). Reduced motion drops both (index.css).
 */

import { useState } from 'react'
import { TOOL_ICON_SVG, type ToolName } from '../tools/toolIcons'
import { InlineIcon } from './InlineIcon'
import inkEraserSvg from '@material-symbols/svg-400/outlined/ink_eraser.svg?raw'
import editSvg from '@material-symbols/svg-400/outlined/edit.svg?raw'
import groupOffSvg from '@material-symbols/svg-400/outlined/group_off.svg?raw'
import groupWorkSvg from '@material-symbols/svg-400/outlined/group_work.svg?raw'
import deployedCodeSvg from '@material-symbols/svg-400/outlined/deployed_code.svg?raw'
import contentCopySvg from '@material-symbols/svg-400/outlined/content_copy.svg?raw'
import callSplitSvg from '@material-symbols/svg-400/outlined/call_split.svg?raw'
import textFieldsSvg from '@material-symbols/svg-400/outlined/text_fields.svg?raw'
import bookmarkAddSvg from '@material-symbols/svg-400/outlined/bookmark_add.svg?raw'
import { deriveDockContext, dockVerbsFor, dockChipLabel, isDockVerbEnabled, type DockContext, type DockGates, type DockVerb } from './dockLogic'
import type { NodeRef } from './treeModel'

const NON_TOOL_ICON_SVG: Record<string, string> = {
  'edit-delete': inkEraserSvg,
  'enter-context': editSvg,
  'ungroup': groupOffSvg,
  'edit-group': groupWorkSvg,
  'edit-make-component': deployedCodeSvg,
  'make-unique': contentCopySvg,
  'explode-instance': callSplitSvg,
  'draw-3d-text': textFieldsSvg,
  'save-to-library': bookmarkAddSvg,
}

const CHIP_COLOR: Record<DockContext, string> = {
  empty: 'var(--text-section)',
  object: 'var(--axis-blue)',
  group: 'var(--axis-green)',
  instance: 'var(--axis-green)',
  multi: 'var(--text-section)',
  sketch: 'var(--axis-blue)',
}

function VerbIcon({ verb }: { verb: DockVerb }) {
  const raw = TOOL_ICON_SVG[verb.label as ToolName] ?? NON_TOOL_ICON_SVG[verb.id]
  if (raw === undefined) return null
  return <InlineIcon svg={raw} size={21} />
}

/**
 * `selected` is the ONLY thing that drives the accent styling — it's true
 * iff this verb is the actual active tool (`activeToolId` matched, from
 * `ContextualDock`'s prop). Being first in the verbs array (formerly styled
 * as "primary") no longer renders any different from the rest: a dock
 * showing Rectangle/Line/Circle/Arc must never look like Rectangle is
 * selected just because it's first — only Arc lights up while Arc is the
 * live tool.
 */
function DockItem({ verb, selected, disabled, onRun }: { verb: DockVerb; selected: boolean; disabled?: boolean; onRun: (id: string) => void }) {
  const [hovered, setHovered] = useState(false)
  const isDisabled = disabled === true
  return (
    <button
      type="button"
      aria-pressed={selected}
      aria-disabled={isDisabled}
      disabled={isDisabled}
      onClick={isDisabled ? undefined : () => onRun(verb.id)}
      onMouseEnter={isDisabled ? undefined : () => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      title={verb.label}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '4px',
        padding: '8px var(--space-6, 13px)',
        minWidth: '60px',
        border: selected ? '1px solid var(--accent-border)' : '1px solid transparent',
        borderRadius: 'var(--radius-panel-item, 11px)',
        background: selected ? 'var(--accent-tint-18)' : hovered && !isDisabled ? 'var(--surface-hover)' : 'transparent',
        color: selected ? 'var(--accent-text-strong)' : 'var(--text-secondary)',
        opacity: isDisabled ? 0.4 : 1,
        pointerEvents: isDisabled ? 'none' : undefined,
        cursor: isDisabled ? 'default' : 'pointer',
        fontFamily: 'var(--font-family-ui)',
      }}
    >
      <VerbIcon verb={verb} />
      <span
        style={{
          fontSize: 'var(--font-size-dock-label, 11px)',
          fontWeight: selected ? 600 : 400,
          whiteSpace: 'nowrap',
        }}
      >
        {verb.label}
      </span>
    </button>
  )
}

export interface ContextualDockProps {
  selectedIds: NodeRef[]
  selectedGuide: bigint | null
  onRun: (id: string) => void
  /** Fade the dock out (opacity 0 + click-through) while the camera is being
   * dragged (spec: "Hidden during pure camera navigation... reappears
   * on release"). Kept mounted so the fade can transition both ways. */
  hidden?: boolean
  /** The dock-verb id of the ACTUAL active tool (e.g. `'tool-arc'`), or
   * undefined/no-match if the active tool has no dock verb. Drives the one
   * accent-highlighted item  — replaces the old
   * "first verb always looks selected" behavior. */
  activeToolId?: string
  /** True when the cursor is hovering a live sketch's extrudable region AND
   * nothing is selected (throttled/edge-detected in Viewport.tsx via
   * `SketchHoverGate`). Only consulted when the derived context is 'empty'
   * — an explicit selection's dock always wins, so this is ignored entirely
   * the moment `selectedIds`/`selectedGuide` yield anything else. Swaps the
   * empty-selection draw-tool row for the 'sketch' verb set (Push/Pull
   * primary) as a preview of what a click there would do. */
  hoveringSketchRegion?: boolean
  /** Selection-dependent applicability for the structural verbs (Group /
   * Make Component) — derived in App.tsx from the same `menuGates` memo the
   * Edit menu uses. Omitted (tests, storybook-style mounts) = ungated. */
  gates?: DockGates
}

export function ContextualDock({
  selectedIds,
  selectedGuide,
  onRun,
  hidden = false,
  activeToolId,
  hoveringSketchRegion = false,
  gates,
}: ContextualDockProps) {
  const baseContext = deriveDockContext(selectedIds, selectedGuide)
  // Hover only ever promotes 'empty' -> 'sketch' — any other context (an
  // actual selection, or null for a selected guide) is left untouched.
  const hoverPreviewOnly = baseContext === 'empty' && hoveringSketchRegion
  const context = hoverPreviewOnly ? 'sketch' : baseContext
  if (context === null) return null

  const verbs = dockVerbsFor(context, gates)

  return (
    <div
      key={context}
      className="hew-dock"
      data-testid="contextual-dock"
      data-dock-context={context}
      data-hidden={hidden || undefined}
      style={{
        opacity: hidden ? 0 : 1,
        pointerEvents: hidden ? 'none' : undefined,
        position: 'absolute',
        bottom: '18px',
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        alignItems: 'stretch',
        gap: '3px',
        padding: '8px 10px',
        background: 'var(--surface-overlay)',
        border: '1px solid var(--border-strong)',
        borderRadius: 'var(--radius-dock, 15px)',
        boxShadow: 'var(--shadow-dock)',
        backdropFilter: 'blur(12px)',
      }}
    >
      {/* Context chip */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '4px',
          padding: '0 var(--space-5, 11px) 0 var(--space-3, 8px)',
          borderRight: '1px solid var(--border-hairline)',
          marginRight: '3px',
        }}
      >
        <span
          aria-hidden="true"
          style={{ width: '9px', height: '9px', borderRadius: '2px', background: CHIP_COLOR[context] }}
        />
        <span
          style={{
            fontFamily: 'var(--font-family-mono)',
            fontSize: 'var(--font-size-dock-chip, 9.5px)',
            fontWeight: 600,
            color: 'var(--text-section)',
            whiteSpace: 'nowrap',
          }}
        >
          {dockChipLabel(context)}
        </span>
      </div>

      {verbs.map((verb) => (
        <DockItem
          key={verb.id}
          verb={verb}
          selected={verb.id === activeToolId}
          disabled={!isDockVerbEnabled(verb, hoverPreviewOnly)}
          onRun={onRun}
        />
      ))}
    </div>
  )
}

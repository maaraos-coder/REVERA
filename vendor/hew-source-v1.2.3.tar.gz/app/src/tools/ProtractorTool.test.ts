import { describe, it, expect, vi } from 'vitest'
import * as THREE from 'three'
import { ProtractorTool } from './ProtractorTool'
import type { Snap } from './types'
import type { Scene as WasmScene } from '../wasm/loader'
import type { Ray } from '../viewport/math'
import { worldPerPixelPerspective, worldPerPixelOrtho } from '../viewport/math'
import { axisColorForDirection, axisColorsForTheme } from '../viewport/axisColors'
import { getResolvedTheme } from '../settings/theme'
import type { DrawingAxes } from './drawingAxes'

/** ~2° axis tolerance, matching ProtractorTool's own AXIS_SNAP_TOL_DOT. */
const TOL = Math.cos((2 * Math.PI) / 180)

const RAY: Ray = { origin: [0, 0, 0], direction: [0, 0, -1] }

function makeSnap(overrides: Partial<Snap> = {}): Snap {
  return { x: 0, y: 0, z: 0, kind: 'ground', ...overrides }
}

/**
 * Minimal KeyboardEvent-shaped fake — the vitest environment here is plain
 * Node (no DOM globals), and `onKey` only reads `.key`/`.repeat` and calls
 * `.preventDefault()`, so a plain object matching that surface is enough.
 */
function makeKeyEvent(key: string, opts: { repeat?: boolean } = {}): KeyboardEvent {
  let defaultPrevented = false
  return {
    key,
    repeat: opts.repeat ?? false,
    get defaultPrevented() {
      return defaultPrevented
    },
    preventDefault: () => {
      defaultPrevented = true
    },
  } as unknown as KeyboardEvent
}

/** World-identity drawing axes (tool-parity §4) — the default frame every
 *  test in this file exercises unless it explicitly overrides `frame`. */
const WORLD_FRAME_FLAT = [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1]

/** Minimal WasmScene stub — only the members ProtractorTool calls. `frame`
 *  is the flat 12-float buffer `Scene::axes()` would return — defaults to
 *  world identity so existing tests are unaffected; a moved-frame test
 *  overrides it to prove `axisDir` reads the CURRENT frame, not a literal
 *  world constant (mirrors MoveTool.test.ts / RotateTool.test.ts). */
function makeWasmScene(faceNormal?: [number, number, number], frame: number[] = WORLD_FRAME_FLAT): WasmScene {
  return {
    face_normal: vi.fn((..._args: unknown[]) => {
      if (faceNormal === undefined) throw new Error('not a live world-object face')
      return new Float64Array(faceNormal)
    }),
    add_guide_line: vi.fn(() => 1n),
    axes: vi.fn(() => new Float64Array(frame)),
  } as unknown as WasmScene
}

function makeTool(faceNormal?: [number, number, number], frame?: number[]) {
  const preview = new THREE.Group()
  const onGuideCreated = vi.fn()
  const onToast = vi.fn()
  const onMeasurement = vi.fn()
  const wasmScene = makeWasmScene(faceNormal, frame)
  const tool = new ProtractorTool(wasmScene, preview, onGuideCreated, onToast, onMeasurement)
  return { tool, preview, onGuideCreated, onToast, onMeasurement, wasmScene }
}

// ── disk inspection helpers ──────────────────────────────────────────────────

function diskGroup(preview: THREE.Group): THREE.Group {
  const g = preview.children.find((c) => c instanceof THREE.Group)
  expect(g, 'a protractor disk group should exist').toBeDefined()
  return g as THREE.Group
}

function ringColorHex(preview: THREE.Group): number {
  const ring = diskGroup(preview).children.find((c) => c instanceof THREE.LineLoop) as THREE.LineLoop
  expect(ring, 'the disk should have a ring (LineLoop)').toBeDefined()
  return (ring.material as THREE.LineBasicMaterial).color.getHex()
}

/** The color ProtractorTool assigns a ring whose normal points along `dir`
 * (against `frame`, defaulting to world identity — tool-parity §4), run
 * through a LineBasicMaterial so color-management matches the tool's own path. */
function axisColorHex(dir: [number, number, number], frame?: DrawingAxes): number {
  const match = axisColorForDirection(dir, TOL, axisColorsForTheme(getResolvedTheme()), frame)
  expect(match, `${dir} should map to an axis color`).not.toBeNull()
  return new THREE.LineBasicMaterial({ color: match!.color }).color.getHex()
}

describe('ProtractorTool — plane inference (hover phase)', () => {
  it('defaults to world up (blue) when hovering empty space / ground', () => {
    const { tool, preview } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 1, y: 2, z: 0 }), RAY)
    // One disk group should be in the preview, centered at the snap point.
    expect(preview.children).toHaveLength(1)
    const disk = preview.children[0]
    expect(disk.position.toArray()).toEqual([1, 2, 0])
  })

  it('uses the hovered face normal when the snap is a live world-Object face', () => {
    const { tool, preview } = makeTool([0, 0, 1])
    tool.onPointerMove(
      makeSnap({ kind: 'face', elementKind: 'face', object: 1n, element: 2n, x: 0, y: 0, z: 0 }),
      RAY,
    )
    expect(preview.children).toHaveLength(1)
  })

  it('falls back to world up if face_normal throws (instanced geometry)', () => {
    const { tool, preview, wasmScene } = makeTool(undefined)
    tool.onPointerMove(
      makeSnap({ kind: 'face', elementKind: 'face', object: 1n, element: 2n }),
      RAY,
    )
    expect(wasmScene.face_normal).toHaveBeenCalled()
    expect(preview.children).toHaveLength(1)
  })
})

describe('ProtractorTool — Shift lock toggle', () => {
  it('locks the candidate normal on Shift, unlocks on a second Shift', () => {
    const { tool, preview } = makeTool([1, 0, 0]) // east/west face -> X normal
    tool.onPointerMove(
      makeSnap({ kind: 'face', elementKind: 'face', object: 1n, element: 2n, x: 5, y: 5, z: 0 }),
      RAY,
    )
    tool.onKey(makeKeyEvent('Shift'))
    // Locked: apex click should adopt the locked normal even off a face.
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 5, y: 5, z: 0 }), RAY)
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 5, y: 5, z: 0 }), RAY)
    expect(preview.children.length).toBeGreaterThan(0)

    // Unlock again (back in idle after apex commit would need a baseline+sweep;
    // instead directly verify the toggle semantics via a fresh tool).
    const { tool: tool2 } = makeTool([1, 0, 0])
    tool2.onPointerMove(makeSnap({ kind: 'ground' }), RAY)
    tool2.onKey(makeKeyEvent('Shift'))
    tool2.onKey(makeKeyEvent('Shift'))
    // After locking then unlocking, apex should use the live candidate again
    // (world up, since this snap isn't a face) rather than a stale lock.
    tool2.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    // No exception, no leftover lock — sanity check passes if we reach here.
    expect(true).toBe(true)
  })

  it('ignores Shift keydown autorepeat (ev.repeat=true does not toggle)', () => {
    const { tool, preview } = makeTool([0, 1, 0])
    tool.onPointerMove(
      makeSnap({ kind: 'face', elementKind: 'face', object: 1n, element: 2n }),
      RAY,
    )
    const before = preview.children.length
    tool.onKey(makeKeyEvent('Shift', { repeat: true }))
    // A repeat event should not change lock state or redraw anything new.
    expect(preview.children.length).toBe(before)
  })

  it('lock persists across a commit (back to idle, still locked)', () => {
    const { tool } = makeTool([0, 0, 1])
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    tool.onKey(makeKeyEvent('Shift')) // lock to Z (world up candidate)

    // Apex
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    // Baseline
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 1, y: 0, z: 0 }), RAY)
    // Sweep
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 1, z: 0 }), RAY)
    // Commit
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 1, z: 0 }), RAY)

    // Now back in idle. A subsequent hover over a non-face point should still
    // render the disk using the locked normal (Z), not re-infer.
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 2, y: 2, z: 0 }), RAY)
    // No throw — and capturingInput should report idle again.
    expect(tool.capturingInput()).toBe(false)
  })

  it('Escape clears the lock entirely', () => {
    const { tool } = makeTool([0, 0, 1])
    tool.onPointerMove(makeSnap({ kind: 'ground' }), RAY)
    tool.onKey(makeKeyEvent('Shift'))
    tool.cancel()
    expect(tool.capturingInput()).toBe(false)
  })
})

describe('ProtractorTool — arrow-key axis lock', () => {
  it('ArrowRight locks to X, ArrowLeft locks to Y, ArrowUp/Down lock to Z', () => {
    const { tool } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground' }), RAY)

    const right = makeKeyEvent('ArrowRight')
    tool.onKey(right)
    expect(right.defaultPrevented).toBe(true)

    const left = makeKeyEvent('ArrowLeft')
    tool.onKey(left)
    expect(left.defaultPrevented).toBe(true)

    const up = makeKeyEvent('ArrowUp')
    tool.onKey(up)
    expect(up.defaultPrevented).toBe(true)
  })

  // ── Movable drawing axes (tool-parity §4) ──────────────────────────────
  it('ArrowRight locks the CURRENT frame\'s red axis, not literal world X, under a moved frame', () => {
    // Frame with red/green swapped relative to world: x=[0,1,0], y=[-1,0,0],
    // z=[0,0,1] — the same orthonormal, right-handed fixture
    // MoveTool.test.ts / RotateTool.test.ts use for their own moved-frame
    // arrow-key regressions.
    const frame = [0, 0, 0, 0, 1, 0, -1, 0, 0, 0, 0, 1]
    const frameObj: DrawingAxes = { origin: [0, 0, 0], x: [0, 1, 0], y: [-1, 0, 0], z: [0, 0, 1] }
    const { tool, wasmScene, preview } = makeTool(undefined, frame)

    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    tool.onKey(makeKeyEvent('ArrowRight')) // locks to the frame's red axis, [0,1,0]
    // The disk (Protractor's only axis-lock signal) must tint to the frame's
    // red — a primitive still comparing against literal world axes would
    // instead find [0,1,0] closest to world Y and render it green.
    expect(ringColorHex(preview)).toBe(axisColorHex([0, 1, 0], frameObj))
    expect(ringColorHex(preview)).not.toBe(axisColorHex([0, 1, 0]))

    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY) // apex at origin
    // The apex re-render (a second `_updatePreviewDisk` call site) must stay
    // frame-red too.
    expect(ringColorHex(preview)).toBe(axisColorHex([0, 1, 0], frameObj))
    // Baseline click at (1,1,1): projecting onto the plane ⊥ [0,1,0] removes
    // the y-component (v·n = 1), leaving normalize([1,0,1]) ≈ (0.707,0,0.707)
    // — the un-fixed bug (planeNormal = literal world X, [1,0,0]) would
    // instead remove the x-component and leave (0,0.707,0.707), a direction
    // with a NON-zero Y and a ZERO X — the discriminator this test checks.
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 1, y: 1, z: 1 }), RAY)
    // No sweep move — commit right at the baseline (0° swept angle), so the
    // committed direction IS the baseline direction, unmodified by any
    // axis-snap (45° off every axis, comfortably outside the 2° tolerance).
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 1, y: 1, z: 1 }), RAY)

    expect(wasmScene.add_guide_line).toHaveBeenCalledTimes(1)
    const args = (wasmScene.add_guide_line as ReturnType<typeof vi.fn>).mock.calls[0]
    expect(args[0]).toBeCloseTo(0) // apex x
    expect(args[1]).toBeCloseTo(0) // apex y
    expect(args[2]).toBeCloseTo(0) // apex z
    expect(args[3]).toBeCloseTo(Math.SQRT1_2) // dir x — nonzero only under the frame-aware fix
    expect(args[4]).toBeCloseTo(0) // dir y — zero only under the frame-aware fix
    expect(args[5]).toBeCloseTo(Math.SQRT1_2) // dir z
  })
})

describe('ProtractorTool — apex/baseline/sweep/commit with plane locking', () => {
  it('commits a guide line through the apex using the locked plane normal', () => {
    const { tool, wasmScene, onGuideCreated } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    tool.onKey(makeKeyEvent('Shift')) // lock to world-up (Z)

    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY) // apex
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 1, y: 0, z: 0 }), RAY) // baseline (+X)
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 1, z: 0 }), RAY) // sweep to +Y (90°)
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 1, z: 0 }), RAY) // commit

    expect(wasmScene.add_guide_line).toHaveBeenCalledTimes(1)
    expect(onGuideCreated).toHaveBeenCalledTimes(1)
    const args = (wasmScene.add_guide_line as ReturnType<typeof vi.fn>).mock.calls[0]
    // apex at origin
    expect(args[0]).toBeCloseTo(0)
    expect(args[1]).toBeCloseTo(0)
    expect(args[2]).toBeCloseTo(0)
    // swept to +Y, axis-snapped exactly
    expect(args[3]).toBeCloseTo(0)
    expect(args[4]).toBeCloseTo(1)
    expect(args[5]).toBeCloseTo(0)
  })

  it('reports the snapped-axis angle (exact), not the raw cursor angle, once axis-snapped', () => {
    const { tool, onMeasurement } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY) // apex (plane = world up)
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 1, y: 0, z: 0 }), RAY) // baseline (+X)

    // Sweep to a direction *near* +Y but not exactly on it (within the 2° axis-snap tolerance).
    const nearYDeg = 89.4
    const rad = (nearYDeg * Math.PI) / 180
    tool.onPointerMove(makeSnap({ kind: 'ground', x: Math.cos(rad), y: Math.sin(rad), z: 0 }), RAY)

    // The cursor is at 89.4°, but since it's within tolerance of +Y (90°), the
    // axis-snap kicks in and the reported angle should read exactly 90.0,
    // not the raw 89.4.
    const lastCall = onMeasurement.mock.calls.at(-1)
    expect(lastCall).toBeDefined()
    expect(lastCall![0]).toBe('90.0°')
  })

  it('reports the raw cursor angle when off-axis (no snap)', () => {
    const { tool, onMeasurement } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY) // apex
    tool.onPointerDown(makeSnap({ kind: 'ground', x: 1, y: 0, z: 0 }), RAY) // baseline (+X)

    // 45 degrees is comfortably off any axis.
    const rad = Math.PI / 4
    tool.onPointerMove(makeSnap({ kind: 'ground', x: Math.cos(rad), y: Math.sin(rad), z: 0 }), RAY)

    const lastCall = onMeasurement.mock.calls.at(-1)
    expect(lastCall).toBeDefined()
    expect(lastCall![0]).toBe('45.0°')
  })
})

describe('ProtractorTool — screen-constant disk scaling', () => {
  // The disk's screen size at the app's reference fov/viewport (45°, 720px
  // tall) — carried over from the old DISK_SCREEN_K = 0.03 constant so the
  // migration doesn't change how big the protractor looks at that baseline.
  // worldScale = desiredPixels * dist * tan(fov/2) / viewportHeight.
  const REF_FOV_DEG = 45
  const REF_VIEWPORT_H = 720
  const tanHalf = (fovDeg: number) => Math.tan((fovDeg * Math.PI) / 360)
  const expectedScale = (dist: number, fovDeg: number, viewportH: number) => {
    const desiredPixels = (0.03 * REF_VIEWPORT_H) / tanHalf(REF_FOV_DEG)
    return (desiredPixels * dist * tanHalf(fovDeg)) / viewportH
  }
  /** `updateDiskScale` now takes a `worldPerPixel` callback (the CameraRig
   * form, docs/design/camera.md §1) instead of a raw `(camera, viewportH)`
   * pair. */
  const wppPerspective = (fovDeg: number, viewportH: number) => (dist: number) =>
    worldPerPixelPerspective(dist, fovDeg, viewportH)

  it('updateDiskScale matches the old DISK_SCREEN_K * dist size at the reference fov/viewport', () => {
    const { tool, preview } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 1, y: 2, z: 0 }), RAY)

    const disk = preview.children[0]
    const camera = new THREE.PerspectiveCamera(REF_FOV_DEG)
    camera.position.set(1, 2, 10) // 10 m straight up from the disk center (1,2,0)

    tool.updateDiskScale(camera, wppPerspective(REF_FOV_DEG, REF_VIEWPORT_H))

    const dist = camera.position.distanceTo(disk.position)
    expect(dist).toBeCloseTo(10, 9)
    const expected = expectedScale(dist, REF_FOV_DEG, REF_VIEWPORT_H)
    // Old K * dist at the reference baseline, for a sanity cross-check.
    expect(expected).toBeCloseTo(0.03 * dist, 9)
    expect(disk.scale.x).toBeCloseTo(expected, 9)
    expect(disk.scale.y).toBeCloseTo(expected, 9)
    expect(disk.scale.z).toBeCloseTo(expected, 9)
  })

  it('holds its on-screen size across a FOV change, unlike the old K * dist form', () => {
    const { tool, preview } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    const disk = preview.children[0]

    for (const fov of [20, 45, 70, 100]) {
      const camera = new THREE.PerspectiveCamera(fov)
      camera.position.set(0, 0, 10)
      tool.updateDiskScale(camera, wppPerspective(fov, REF_VIEWPORT_H))
      const dist = camera.position.distanceTo(disk.position)
      const expected = expectedScale(dist, fov, REF_VIEWPORT_H)
      expect(disk.scale.x).toBeCloseTo(expected, 9)
    }
  })

  it('holds its on-screen size across a viewport resize, unlike the old K * dist form', () => {
    const { tool, preview } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    const disk = preview.children[0]
    const camera = new THREE.PerspectiveCamera(REF_FOV_DEG)
    camera.position.set(0, 0, 10)

    for (const viewportH of [400, 720, 1200]) {
      tool.updateDiskScale(camera, wppPerspective(REF_FOV_DEG, viewportH))
      const dist = camera.position.distanceTo(disk.position)
      const expected = expectedScale(dist, REF_FOV_DEG, viewportH)
      expect(disk.scale.x).toBeCloseTo(expected, 9)
    }
  })

  it('updateDiskScale is a no-op when no disk is currently shown', () => {
    const { tool } = makeTool()
    const camera = new THREE.PerspectiveCamera()
    camera.position.set(0, 0, 10)
    // No pointer move yet -> previewDisk is null. Should not throw.
    expect(() => tool.updateDiskScale(camera, wppPerspective(45, REF_VIEWPORT_H))).not.toThrow()
  })

  it('a degenerate (zero) worldPerPixel collapses the disk to a defined zero size, rather than leaving a stale scale', () => {
    const { tool, preview } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    const disk = preview.children[0]
    const camera = new THREE.PerspectiveCamera(REF_FOV_DEG)
    camera.position.set(0, 0, 10)
    tool.updateDiskScale(camera, wppPerspective(REF_FOV_DEG, 0))
    expect(disk.scale.x).toBe(0)
  })

  it('DESIGN CHANGE: works under an orthographic (parallel-projection) camera too — no longer silently hidden', () => {
    // Before Phase 1, an `instanceof PerspectiveCamera` guard made this a
    // no-op under ortho — the protractor disk would silently vanish the
    // moment the user toggled Parallel Projection.
    const { tool, preview } = makeTool()
    tool.onPointerMove(makeSnap({ kind: 'ground', x: 0, y: 0, z: 0 }), RAY)
    const disk = preview.children[0]

    const ortho = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 10)
    ortho.position.set(0, 0, 10)
    const wppOrtho = worldPerPixelOrtho(4, 1, REF_VIEWPORT_H)
    tool.updateDiskScale(ortho, () => wppOrtho)
    const expected = ((0.03 * REF_VIEWPORT_H) / tanHalf(REF_FOV_DEG)) * wppOrtho / 2
    expect(disk.scale.x).toBeCloseTo(expected, 9)
    expect(disk.scale.x).toBeGreaterThan(0)
  })
})


describe('ProtractorTool — a clicked angle is exactly the displayed angle', () => {
  const raw = (37.46 * Math.PI) / 180 // shows "37.5°"
  function sweep(kind: string, typed: string | null) {
    const { tool, wasmScene, onMeasurement } = makeTool()
    tool.onPointerDown(makeSnap({ x: 0, y: 0, z: 0 }), RAY) // apex
    tool.onPointerDown(makeSnap({ x: 1, y: 0, z: 0 }), RAY) // baseline
    const s = makeSnap({ x: Math.cos(raw), y: Math.sin(raw), z: 0, kind })
    tool.onPointerMove(s, RAY)
    if (typed === null) tool.onPointerDown(s, RAY)
    else {
      for (const ch of typed) tool.onKey(makeKeyEvent(ch))
      tool.onKey(makeKeyEvent('Enter'))
    }
    const args = (wasmScene.add_guide_line as ReturnType<typeof vi.fn>).mock.calls[0] as number[]
    return { dir: args.slice(3), onMeasurement }
  }

  it('a free click commits the same guide direction as typing the shown angle', () => {
    const clicked = sweep('ground', null)
    expect(clicked.onMeasurement).toHaveBeenCalledWith('37.5°')
    expect(clicked.dir).toEqual(sweep('ground', '37.5').dir)
    expect(clicked.dir[0]).toBeCloseTo(Math.cos((37.5 * Math.PI) / 180), 15)
  })

  it('a hard-snapped (endpoint) click keeps its exact direction', () => {
    const d = sweep('endpoint', null).dir
    expect(d[0]).toBeCloseTo(Math.cos(raw), 14)
    expect(d[1]).toBeCloseTo(Math.sin(raw), 14)
  })
})
